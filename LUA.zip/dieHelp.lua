-----------------------------------------------------------------------------------------
--
-- view1.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local common = require("common")
local scene = composer.newScene()

local function bkg2Toch( event )
	
	
	--common.lastLink = "bak2game"
	common.back2stag  = true
	
end

function scene:create( event )
	local sceneGroup = self.view
	
	-- Called when the scene's view does not exist.
	-- 
	-- INSERT code here to initialize the scene
	-- e.g. add display objects to 'sceneGroup', add touch listeners, etc.
	
	-- create a white background to fill screen
	--[[common.color1 = "ns"
common.color2 = "ns"
common.stra1 = "ns"
common.isgole = false
common.stra2 = "ns"
common.scor1 = "ns"
common.scor2 = "ns"--]]
	local background = display.newRect( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )
	background:setFillColor( 1 )	-- white
	
	local bk2g = display.newImage( "restart2game.png", display.contentCenterX, display.contentCenterY, true )
	bk2g:addEventListener( "touch", bkg2Toch )
	
	local rect1 = display.newRect( display.contentCenterX , (display.contentCenterY - bk2g.contentHeight) - (bk2g.contentHeight / 2), bk2g.contentWidth, bk2g.contentHeight )
	rect1:setFillColor( 1, 0, 0 )
	local text1 = display.newText( common.scor1, rect1.x, rect1.y, native.systemFont, 64  )

	local rect2 = display.newRect( display.contentCenterX , (display.contentCenterY + bk2g.contentHeight) + (bk2g.contentHeight / 2), bk2g.contentWidth, bk2g.contentHeight )
	rect2:setFillColor( 0, 0, 1 )
	local text2 = display.newText( common.scor2, rect2.x, rect2.y, native.systemFont, 64  )

	--local dspace = bk2g.contentHeight -- math.ceil(bk2g / 2)
	
	-- create some text
	--local title = display.newText( common.color1 .. ": " .. common.scor1 .. " - " .. common.color2 .. ": " .. common.scor2, display.contentCenterX, 125, native.systemFont, 132 )
	--title:setFillColor( 0 )	-- black
	
	--[[local newTextParams = { text = "Loaded by the first tab's\n\"onPress\" listener\nspecified in the 'tabButtons' table", 
						x = display.contentCenterX + 10, 
						y = title.y + 215, 
						width = 310, height = 310, 
						font = native.systemFont, fontSize = 14, 
						align = "center" }--]]
	--local summary = display.newText( newTextParams )
	--summary:setFillColor( 0 ) -- black

	
	-- all objects must be added to group (e.g. self.view)
	sceneGroup:insert( background )
	sceneGroup:insert( bk2g )
	sceneGroup:insert( rect1 )
	sceneGroup:insert( text1 )
	sceneGroup:insert( rect2 )
	sceneGroup:insert( text2 )
	--sceneGroup:insert( summary )
	--sceneGroup:toFront()
	
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene