
-----------------------------------------------------------------------------------------
--
-- view1.lua
--
-----------------------------------------------------------------------------------------
local require = require

require( "tilebg" ) --load the function
local bg = tileBG() --a
local common = require("common")
display.setStatusBar(display.HiddenStatusBar)

--------------------------------------------------------------------------------
-- Localize
--------------------------------------------------------------------------------

local perspective = require("perspective")

local aplisterect = {}
local aplistetext = {}
local aplistesprit = {}
local bplisterect = {}
local bplistetext = {}
local bplistesprit = {}


local function hasCollided(obj1, obj2)
if obj1 == nil then
return false
end
if obj2 == nil then
return false
end
local left = obj1.contentBounds.xMin <= obj2.contentBounds.xMin and obj1.contentBounds.xMax >= obj2.contentBounds.xMin
local right = obj1.contentBounds.xMin >= obj2.contentBounds.xMin and obj1.contentBounds.xMin <= obj2.contentBounds.xMax local up = obj1.contentBounds.yMin <= obj2.contentBounds.yMin and obj1.contentBounds.yMax >= obj2.contentBounds.yMin
local down = obj1.contentBounds.yMin >= obj2.contentBounds.yMin and obj1.contentBounds.yMin <= obj2.contentBounds.yMax return (left or right) and (up or down) end -- circle based local function hasCollidedCircle(obj1, obj2) if obj1 == nil then return false end if obj2 == nil then return false end local sqrt = math.sqrt local dx = obj1.x - obj2.x; local dy = obj1.y - obj2.y; local distance = sqrt(dx*dx + dy*dy); local objectSize = (obj2.contentWidth/2) + (obj1.contentWidth/2) if distance < objectSize then return true end return false end


local function forcesByAngle(totalForce, angle) local forces = {} local radians = -math.rad(angle) forces.x = math.cos(radians) * totalForce forces.y = math.sin(radians) * totalForce return forces end

--------------------------------------------------------------------------------
-- Build Camera
--------------------------------------------------------------------------------
local camera = perspective.createView()

local myRectangle = display.newRect( 0, 0, 5700,4275)--,5700 )
--myRectangle.strokeWidth = 3
--myRectangle:setFillColor( 0)
--myRectangle:setStrokeColor( 1, 0, 0 )
myRectangle:setStrokeColor(1,1,1)
myRectangle:setFillColor(255,255,255,0.1)
myRectangle.strokeWidth = 10
--myRectangle:setFillColor( 1, 0, 0.3 )

 --local star = display.newLine( display.contentCenterX - (4275 / 2), 0, display.contentCenterX + (4275 / 2), 0 )
--star:append( 305,165, 243,216, 265,290, 200,245, 135,290, 157,215, 95,165, 173,165, 200,90 )
--star:setStrokeColor( 1, 0, 0, 1 )
--star.strokeWidth = 8
--star.rotation = 90

camera:add(myRectangle,1)--, math.random(0, camera:layerCount()))
--camera:add(star,1)
--star:rotate(90)
--star.x = display.contentCenterX
--star.y = 0
-- Seed the pseudo-random number generator
math.randomseed( os.time() )

-- Create player sprite sheet
local sheetOptions = {
	width = 50,
	height = 50,
	numFrames = 64,
	sheetContentWidth = 800,
	sheetContentHeight = 1850
}
local characterSheet = graphics.newImageSheet( "SPRIT-Blue.png", sheetOptions )

local BLUEsheetOptions = {
	width = 50,
	height = 50,
	numFrames = 592,
	sheetContentWidth = 800,
	sheetContentHeight = 1850
}
local BLUEcharacterSheet = graphics.newImageSheet( "SPRIT-Blue.png", BLUEsheetOptions )
local REDsheetOptions = {
	width = 50,
	height = 50,
	numFrames = 592,
	sheetContentWidth = 800,
	sheetContentHeight = 1850
}
local REDcharacterSheet = graphics.newImageSheet( "SPRIT-Red.png", REDsheetOptions )
--272
local WHITEsheetOptions = {
	width = 50,
	height = 50,
	numFrames = 592,
	sheetContentWidth = 800,
	sheetContentHeight = 1850
}
local WHITEcharacterSheet = graphics.newImageSheet( "SPRIT-White.png", WHITEsheetOptions )

local GOLERsheetOptions = {
	width = 50,
	height = 50,
	numFrames = 16,
	sheetContentWidth = 800,
	sheetContentHeight = 50
}
local GOLERcharacterSheet = graphics.newImageSheet( "SPRIT-Goler.png", GOLERsheetOptions )


local ballsheetOptions = {
	width = 50,
	height = 50,
	numFrames = 16,
	sheetContentWidth = 800,
	sheetContentHeight = 50
}
local ballcharacterSheet = graphics.newImageSheet( "SPRIT-Ball.png", ballsheetOptions )

local JoyStigsheetOptions = {
	width = 200,
	height = 200,
	numFrames = 10,
	sheetContentWidth = 2000,
	sheetContentHeight = 200
}
local  JoyStigcharacterSheet = graphics.newImageSheet( "SPRIT-ControlBT.png", JoyStigsheetOptions )



-- Create display group for sprites
local group = display.newGroup()
--mainGroup:insert( group )

-- Calculate how many total rows and columns will fill screen
local tilesPerRow = math.ceil( display.actualContentWidth / 60 )
local totalRows = math.ceil( (display.actualContentHeight-30) / 60 )

-- Generate sprites
--for i = 1,totalRows do
	--for j = 1,tilesPerRow do

		--local rnd = math.random( 1,16 )

	--	local sequenceData = {
		--	name = "character",
		--	start = (rnd * 4) - 3,
		--	count = 4,
		--	time = 600
	--	}
	--	local sprite = display.newSprite( group, characterSheet, sequenceData )
	--	sprite.x = j * 60
	--	sprite.y = i * 60
	--	sprite:play()
	--end
--end

-- Re-position entire group on screen
group.anchorChildren = true
group.anchorY = 0
group.x = display.contentCenterX
group.y = 100--sampleUI.titleBarBottom + 8







local JoyStigsequenceData = {
			 -- first sequence (consecutive frames)
    {
        name = "beforestart",
        start = 1,
        count = 10,
        time = 800,
        loopCount = 0
    },
    -- next sequence (non-consecutive frames)
    {
        name = "beforestart2",
        frames = { 1,10 },
        time = 400,
        loopCount = 400
    },
	 {
        name = "frame10",
        start = 10,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame1",
        start = 1,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame2",
        start = 2,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame3",
        start = 3,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame4",
        start = 4,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame5",
        start = 5,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame6",
        start = 6,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame7",
        start = 7,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame8",
        start = 8,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame9",
        start = 9,
        count = 1,
        time = 800,
        loopCount = 0
    },
		}
		local JoyStig = display.newSprite( group, JoyStigcharacterSheet, JoyStigsequenceData )
		JoyStig.x = ( display.actualContentWidth / 2 ) - 100 --0--(display.contentWidth  / 2) - 100
		JoyStig:setSequence( "beforestart2" )
		--JoyStig.y =  0m.forward.y --display.contentHeight --- JoyStig.contentHeight - 10 -- 0 -- 200 -- 0 -- 210 -- ( display.actualContentHeight ) - 210 --0--display.contentHeight  - 200
		--player:scale( 4,4 )
		JoyStig:play()
	JoyStig.isVisible = false
--camera:add(JoyStig, math.random(0, camera:layerCount()))


------------------------------

local BLUEsequenceData = {
			{
        name = "character",
        start = 177 ,
			count = 16,
			time = 600,
        loopCount = 0
    },
	{
        name = "actif",
        start = ( 177 + 304 ),
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "runup",
        start = 1,
        count = 11,
        time = 800,
        loopCount = 0
    },
	{
        name = "runupright",
        start = 17,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runright",
        start = 33,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownright",
        start = 49,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundown",
        start = 55,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundowleft",
        start = 71,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runleft",
        start = 87,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runupleft",
        start = 103,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standup",
        start = 129,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupright",
        start =145,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standright",
        start = 161,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standrightdown",
        start = 177,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdown",
        start = 193,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownleft",
        start =209,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standleft",
        start =225,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupleft",
        start = 241,
        count = 10,
        time = 800,
        loopCount = 0
    },
		{
        name = "runupActif",
        start = 1 + 304 ,
        count = 11,
        time = 800,
        loopCount = 0
    },
	{
        name = "runuprightActif",
        start = 17 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runrightActif",
        start = 33 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownrightActif",
        start = 49 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownActif",
        start = 55 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundowleftActif",
        start = 369,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runleftActif",
        start = 385,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runupleftActif",
        start = 401,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupActif",
        start = 417,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standuprightActif",
        start =433,
        count = 1,
        time = 800,
        loopCount = 0
    },{
        name = "standrightActif",
        start = 449,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standrightdownActif",
        start = 465,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownActif",
        start = 481,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownleftActif",
        start =497,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standleftActif",
        start =513,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupleftActif",
        start = 529,
        count = 10,
        time = 800,
        loopCount = 0
    },
		}
		--local BLUEsprite = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
		--sprite:scale( 4,4 )
		--BLUEsprite.x = 1 * 60
		--BLUEsprite.y = 1 * 60
		--BLUEsprite:play()
--camera:add(BLUEsprite,1)--, math.random(0, camera:layerCount()))


local REDsequenceData  = {
			{
        name = "character",
        start = 177 ,
			count = 16,
			time = 600,
        loopCount = 0
    },
	{
        name = "actif",
        start = ( 177 + 304 ),
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "runup",
        start = 1,
        count = 11,
        time = 800,
        loopCount = 0
    },
	{
        name = "runupright",
        start = 17,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runright",
        start = 33,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownright",
        start = 49,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundown",
        start = 65,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundowleft",
        start = 81,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runleft",
        start = 97,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runupleft",
        start = 113,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standup",
        start = 129,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupright",
        start =145,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standright",
        start = 161,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standrightdown",
        start = 177,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdown",
        start = 193,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownleft",
        start =209,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standleft",
        start =225,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupleft",
        start = 241,
        count = 10,
        time = 800,
        loopCount = 0
    },
		{
        name = "runupActif",
        start = 289 ,
        count = 11,
        time = 800,
        loopCount = 0
    },
	{
        name = "runuprightActif",
        start = 305 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runrightActif",
        start = 321 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownrightActif",
        start = 337 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownActif",
        start = 353 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundowleftActif",
        start = 369,--385,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runleftActif",
        start = 385,--401,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runupleftActif",
        start = 401,--417,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupActif",
        start = 417,--433,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standuprightActif",
        start = 433,--449,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standrightActif",
        start = 449,--465,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standrightdownActif",
        start = 465,--481,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownActif",
        start = 481,--497,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownleftActif",
        start = 497,--513,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standleftActif",
        start = 513,--529,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupleftActif",
        start = 529,--544,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "taklup",
        start = 257,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklupright",
        start = 258,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklright",
        start = 259,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklrightdown",
        start = 260,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "takldown",
        start = 261,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "takldownleft",
        start = 262,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklleft",
        start = 263,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklleftup",
        start = 264,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "fallup",
        start = 273,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallupright",
        start = 275,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallright",
        start = 277,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallrightdown",
        start = 279,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "falldown",
        start = 281,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "falldownleft",
        start = 283,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallleft",
        start = 285,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallupleft",
        start = 287,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "taklupActif",
        start = 561,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "takluprightActif",
        start = 562,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklrightActif",
        start = 563,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklrightdownActif",
        start = 564,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "takldownActif",
        start = 565,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "takldownleftActif",
        start = 566,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklleftActif",
        start = 567,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "taklleftupActif",
        start = 568,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "fallupActif",
        start = 577,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "falluprightActif",
        start = 579,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallrightActif",
        start = 581,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallrightdownActif",
        start = 583,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "falldownActif",
        start = 585,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "falldownleftActif",
        start = 587,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallleftActif",
        start = 589,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "fallupleftActif",
        start = 591,
        count = 2,
        time = 800,
        loopCount = 1
    },
		}
		--local REDsprite = display.newSprite( group, REDcharacterSheet, REDsequenceData )
		--sprite:scale( 4,4 )
		--REDsprite.x = 2 * 60
		--REDsprite.y = 2 * 60
		--REDsprite:play()
--camera:add(REDsprite,1)--, math.random(0, camera:layerCount()))


local WHITEsequenceData  = {
			{
        name = "character",
        start = 177 ,
			count = 16,
			time = 600,
        loopCount = 0
    },
	{
        name = "actif",
        start = ( 177 + 304 ),
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "runup",
        start = 1,
        count = 11,
        time = 800,
        loopCount = 0
    },
	{
        name = "runupright",
        start = 17,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runright",
        start = 33,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownright",
        start = 49,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundown",
        start = 55,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundowleft",
        start = 71,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runleft",
        start = 87,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runupleft",
        start = 103,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standup",
        start = 129,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupright",
        start =145,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standright",
        start = 161,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standrightdown",
        start = 177,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdown",
        start = 193,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownleft",
        start =209,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standleft",
        start =225,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupleft",
        start = 241,
        count = 10,
        time = 800,
        loopCount = 0
    },
		{
        name = "runupActif",
        start = 1 + 304 ,
        count = 11,
        time = 800,
        loopCount = 0
    },
	{
        name = "runuprightActif",
        start = 17 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runrightActif",
        start = 33 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownrightActif",
        start = 49 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundownActif",
        start = 55 + 304 ,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "rundowleftActif",
        start = 71 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runleftActif",
        start = 87 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "runupleftActif",
        start = 103 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupActif",
        start = 119 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standuprightActif",
        start =135 + 304,
        count = 1,
        time = 800,
        loopCount = 0
    },{
        name = "standrightActif",
        start = 151 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standrightdownActif",
        start = 167 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownActif",
        start = 183 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standdownleftActif",
        start =199 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standleftActif",
        start =215 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },{
        name = "standupleftActif",
        start = 231 + 304,
        count = 10,
        time = 800,
        loopCount = 0
    },
		}
		--local WHITEsprite = display.newSprite( group, WHITEcharacterSheet, WHITEsequenceData )
		--sprite:scale( 4,4 )
		--WHITEsprite.x = 1 * 260
		--WHITEsprite.y = 1 * 260
		--WHITEsprite:play()
--camera:add(WHITEsprite,1)--, math.random(0, camera:layerCount()))


local GOLERsequenceData = {
			{
        name = "normal",
        start = 1,
        count = 1,
        time = 800,
        loopCount = 1
    },{
        name = "getup",
        start = 2,
        count = 5,
        time = 800,
        loopCount = 1
    },{
        name = "getright",
        start = 7,
        count = 2,
        time = 800,
        loopCount = 1
    },{
        name = "getleft",
        start = 9,
        count = 2,
        time = 800,
        loopCount = 1
    },
		}
		
		--local GOLERsprite = display.newSprite( group, GOLERcharacterSheet, GOLERsequenceData )
		--sprite:scale( 4,4 )
		--GOLERsprite.x = 1 * 200
		--GOLERsprite.y = 1 * 200
		--GOLERsprite:play()
--camera:add(GOLERsprite,1)--, math.random(0, camera:layerCount()))
--5700,4275
local function getPlayerX( plr )
	local seprator = ""
	------print("+++common.stra1 = " .. common.stra1)
	if string.match(plr, "A") then
  		seprator = common.stra1 .. "-" .. plr .. "="
	else
  		seprator = common.stra2 .. "-" .. plr .. "="
	end
	------print("++++pos find at: " .. string.find(common.dieposdb, seprator))
	indx1 = string.find(common.dieposdb, seprator)
	indx1 = indx1 + string.len(plr) + 1
	indx2 = string.find(common.dieposdb, ";" , indx1 )
	indx2 = indx2 - 1
	diesub = string.sub(common.dieposdb, indx1 , indx2 )
	------print( "+++++ diesub: " .. diesub )
	indx3 = string.find(diesub, "x")-- , indx1 )
	indx3 = indx3 - 1
	diesub2 = string.sub(diesub, 0 , indx3 )
	------print( "+++++ diesub X: " .. diesub2 )
	--for i in string.gmatch(common.dieposdb, seprator) do
   		------print( "************ new splirt: " .. i)
	--end
	
	--local diear1 = split(seprator , common.dieposdb)
	--local diear2 = split( diear1[1] , ";")
	--local diear3 = split( diear2[0] , "x")
	dieret = tonumber(diesub2) - (5700 / 2)
	
	
	
	return dieret
end
local function getPlayerY( plr )
	local seprator = ""
	------print("+++common.stra1 = " .. common.stra1)
	if string.match(plr, "A") then
  		seprator = common.stra1 .. "-" .. plr .. "="
	else
  		seprator = common.stra2 .. "-" .. plr .. "="
	end
	------print("++++pos find at: " .. string.find(common.dieposdb, seprator))
	indx1 = string.find(common.dieposdb, seprator)
	indx1 = indx1 + string.len(plr) + 1
	indx2 = string.find(common.dieposdb, ";" , indx1 )
	indx2 = indx2 - 1
	diesub = string.sub(common.dieposdb, indx1 , indx2 )
	------print( "+++++ diesub: " .. diesub )
	indx3 = string.find(diesub, "x")-- , indx1 )
	indx3 = indx3 + 1
	diesub2 = string.sub(diesub, indx3 )
	------print( "+++++ diesub Y: " .. diesub2 )
	--for i in string.gmatch(common.dieposdb, seprator) do
   		------print( "************ new splirt: " .. i)
	--end
	
	--local diear1 = split(seprator , common.dieposdb)
	--local diear2 = split( diear1[1] , ";")
	--local diear3 = split( diear2[0] , "x")
	dieret = tonumber(diesub2) - (4275 / 2)
	return dieret
end

local gola-- = display.newImage( "gola.png" )
local golb-- = display.newImage( "golb.png" )
local a1rect
local a2rect
local a3rect
local a4rect
local a5rect
local a6rect
local a7rect
local a8rect
local a9rect
local a10rect
local a11rect
local b1rect
local b2rect
local b3rect
local b4rect
local b5rect
local b6rect
local b7rect
local b8rect
local b9rect
local b10rect
local b11rect
local a1text
local a2text
local a3text
local a4text
local a5text
local a6text
local a7text
local a8text
local a9text
local a10text
local a11text
local b1text
local b2text
local b3text
local b4text
local b5text
local b6text
local b7text
local b8text
local b9text
local b10text
local b11text

local apcols = 3
		local acol1 = 0
		local acol2 = 0
		local acol3 = 0
		local acol4 = 0
		local bpcols = 3
		local bcol1 = 0
		local bcol2 = 0
		local bcol3 = 0
		local bcol4 = 0


local function getNextTextA( plc )
	if (plc == 2) then
		return a3text
	elseif plc == 3 then
		return a4text
	elseif plc == 4 then
		return a5text
	elseif plc == 5 then
		return a6text
	elseif plc == 6 then
		return a7text
	elseif plc == 7 then
		return a8text
	elseif plc == 8 then
		return a9text
	elseif plc == 9 then
		return a10text
	elseif plc == 10 then
		return a11text
	end	
end
local function getNextRectA( plc )
	if (plc == 2) then
		return a3rect
	elseif plc == 3 then
		return a4rect
	elseif plc == 4 then
		return a5rect
	elseif plc == 5 then
		return a6rect
	elseif plc == 6 then
		return a7rect
	elseif plc == 7 then
		return a8rect
	elseif plc == 8 then
		return a9rect
	elseif plc == 9 then
		return a10rect
	elseif plc == 10 then
		return a11rect
	end	
end

local function getNextTextB( plc )
	if (plc == 2) then
		return b3text
	elseif plc == 3 then
		return b4text
	elseif plc == 4 then
		return b5text
	elseif plc == 5 then
		return b6text
	elseif plc == 6 then
		return b7text
	elseif plc == 7 then
		return b8text
	elseif plc == 8 then
		return b9text
	elseif plc == 9 then
		return b10text
	elseif plc == 10 then
		return b11text
	end	
end
local function getNextRectB( plc )
	if (plc == 2) then
		return b3rect
	elseif plc == 3 then
		return b4rect
	elseif plc == 4 then
		return b5rect
	elseif plc == 5 then
		return b6rect
	elseif plc == 6 then
		return b7rect
	elseif plc == 7 then
		return b8rect
	elseif plc == 8 then
		return b9rect
	elseif plc == 9 then
		return b10rect
	elseif plc == 10 then
		return b11rect
	end	
end

---------------
local function setNextTextA( plc,txt )
----print("+++A" .. plc)
aplistetext[plc] = txt
end
local function setNextRectA( plc,rct )
aplisterect[plc] = rct
end

local function setNextTextB( plc,txt )
----print("+++B" .. plc)
bplistetext[plc] = txt
end
local function setNextRectB( plc,rct )
bplisterect[plc] = rct
end

--------------

local function pcreateposes()
		a1xpos = (-1 * ((5700 / 2) - (gola.contentWidth / 3)))-- + 
		a1rect = display.newRect( a1xpos, 0, 70, 70 )
		a1rect:setFillColor( 1, 0, 0 )
		a1text = display.newText( "A1", a1rect.x, a1rect.y, native.systemFont, 32  )
		camera:add(a1rect,1)
		camera:add(a1text,1)
		
		local apc = 1
		
		setNextRectA(apc , a1rect)
		setNextTextA(apc , a1text)
		
		
		--5700,4275
		
		
		
		
		
		
		
		acol1 = tonumber(string.sub(common.stra1,0,1))
		acol2 = tonumber(string.sub(common.stra1,3,3))
		acol3 = tonumber(string.sub(common.stra1,5,5))
		
		
		if string.len(common.stra1) > 5 then
			apcols = 4
			acol4 = tonumber(string.sub(common.stra1,7,7))
		end
		
		----print("===== common.stra1: " .. common.stra1)
		----print("=====acol1: " .. acol1)
		----print("=====acol2: " ..acol2)
		----print("===== acol3: " .. acol3)
		----print("===== acol4: " .. acol4)
		
		local apcolsW = math.abs(a1rect.x) / apcols
		
		
		local latestx = 0
		--for i=(apc + 1),acol1,1 do 
			
			if ((acol1 == 1) or (acol1 == 3) or (acol1 == 5)) then
						a2xpos = a1xpos +  (apcolsW - (apcolsW / 4))
						latestx = a2xpos
						a2rect = display.newRect( a2xpos, 0, 70, 70 )
						a2rect:setFillColor( 1, 0, 0 )
						a2text = display.newText( "A2", a2rect.x, a2rect.y, native.systemFont, 32  )
						setNextRectA(2 , a2rect)
						setNextTextA(2 , a2text)
						camera:add(a2rect,1)
						camera:add(a2text,1)
						if ((acol1 == 3)) then
							a3xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							latestx = a3xpos
							a3rect = display.newRect( a3xpos, a2rect.y - (4275 / 4), 70, 70 )
							a3rect:setFillColor( 1, 0, 0 )
							a3text = display.newText( "A3", a3rect.x, a3rect.y, native.systemFont, 32  )
							setNextRectA(3 , a3rect)
							setNextTextA(3 , a3text)
							camera:add(a3rect,1)
							camera:add(a3text,1)
							a4xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							a4rect = display.newRect( a4xpos, a2rect.y + (4275 / 4), 70, 70 )
							a4rect:setFillColor( 1, 0, 0 )
							a4text = display.newText( "A4", a4rect.x, a4rect.y, native.systemFont, 32  )
							setNextRectA(4 , a4rect)
							setNextTextA(4 , a4text)
							camera:add(a4rect,1)
							camera:add(a4text,1)	
						end
						if ((acol1 == 5)) then
							a3xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							latestx = a3xpos
							a3rect = display.newRect( a3xpos, a2rect.y - (4275 / 6), 70, 70 )
							a3rect:setFillColor( 1, 0, 0 )
							a3text = display.newText( "A3", a3rect.x, a3rect.y, native.systemFont, 32  )
							setNextRectA(3 , a3rect)
							setNextTextA(3 , a3text)
							camera:add(a3rect,1)
							camera:add(a3text,1)
							a4xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							a4rect = display.newRect( a4xpos, a2rect.y + (4275 / 6), 70, 70 )
							a4rect:setFillColor( 1, 0, 0 )
							a4text = display.newText( "A4", a4rect.x, a4rect.y, native.systemFont, 32  )
							setNextRectA(4 , a4rect)
							setNextTextA(4 , a4text)
							camera:add(a4rect,1)
							camera:add(a4text,1)	
							a5xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							a5rect = display.newRect( a5xpos, a3rect.y - (4275 / 6), 70, 70 )
							a5rect:setFillColor( 1, 0, 0 )
							a5text = display.newText( "A5", a5rect.x, a5rect.y, native.systemFont, 32  )
							setNextRectA(5 , a5rect)
							setNextTextA(5 , a5text)
							camera:add(a5rect,1)
							camera:add(a5text,1)
							a6xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							a6rect = display.newRect( a6xpos, a4rect.y + (4275 / 6), 70, 70 )
							a6rect:setFillColor( 1, 0, 0 )
							a6text = display.newText( "A6", a6rect.x, a6rect.y, native.systemFont, 32  )
							setNextRectA(6 , a6rect)
							setNextTextA(6 , a6text)
							camera:add(a6rect,1)
							camera:add(a6text,1)	
						end
			elseif true then
							a2xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							latestx = a2xpos
							a2rect = display.newRect( a2xpos, a1rect.y - (4275 / 6), 70, 70 )
							a2rect:setFillColor( 1, 0, 0 )
							a2text = display.newText( "A2", a2rect.x, a2rect.y, native.systemFont, 32  )
							setNextRectA(2 , a2rect)
							setNextTextA(2 , a2text)
							camera:add(a2rect,1)
							camera:add(a2text,1)
							a3xpos = a1xpos +  (apcolsW - (apcolsW / 4))
							a3rect = display.newRect( a3xpos, a1rect.y + (4275 / 6), 70, 70 )
							a3rect:setFillColor( 1, 0, 0 )
							a3text = display.newText( "A3", a3rect.x, a3rect.y, native.systemFont, 32  )
							setNextRectA(3 , a3rect)
							setNextTextA(3 , a3text)
							camera:add(a3rect,1)
							camera:add(a3text,1)
							if ((acol1 == 4)) then
								a4xpos = a1xpos +  (apcolsW - (apcolsW / 4))
								a4rect = display.newRect( a4xpos, a2rect.y - (4275 / 6), 70, 70 )
								a4rect:setFillColor( 1, 0, 0 )
								a4text = display.newText( "A4", a4rect.x, a4rect.y, native.systemFont, 32  )
								setNextRectA(4 , a4rect)
								setNextTextA(4 , a4text)
								camera:add(a4rect,1)
								camera:add(a4text,1)
								a5xpos = a1xpos +  (apcolsW - (apcolsW / 4))
								a5rect = display.newRect( a5xpos, a3rect.y + (4275 / 6), 70, 70 )
								a5rect:setFillColor( 1, 0, 0 )
								a5text = display.newText( "A5", a5rect.x, a5rect.y, native.systemFont, 32  )
								setNextRectA(5 , a5rect)
								setNextTextA(5 , a5text)
								camera:add(a5rect,1)
								camera:add(a5text,1)
							end
			end
			
			apc = apc + acol1
		--end
		
		------------------- a col 2
--		getNextRectA
--getNextTextA
--latestx = a2xpos
					if ((acol2 == 1) or (acol2 == 3) or (acol2 == 5)) then
						diexpos = latestx +  (apcolsW - (apcolsW / 4))
						latestx = diexpos
						dierect = getNextRectA( apc )
						dietext = getNextTextA( apc )
						
						apc = apc + 1
						dierect = display.newRect( diexpos, 0, 70, 70 )
						dierect:setFillColor( 1, 0, 0 )
						dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
						prevrect = dierect
						setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						
						camera:add(dierect,1)
						camera:add(dietext,1)
						if ((acol2 == 3)) then
						
							diexpos = latestx-- +  (apcolsW - (apcolsW / 4))
							latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 4), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx +  (apcolsW - (apcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 4), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
						
						end
						if ((acol2 == 5)) then
						
							diexpos = latestx-- +  (apcolsW - (apcolsW / 4))
							latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							prevrect2 = dierect
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
					--	apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx +  (apcolsW - (apcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 6), 70, 70 )
							prevrect3 = dierect
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
					--	apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
					
						end
			elseif true then
							diexpos = latestx +  (apcolsW - (apcolsW / 4))
							latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, a1rect.y - (4275 / 6), 70, 70 )
							prevrect2 = dierect
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
					--	apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							--diexpos = a1xpos +  (apcolsW - (apcolsW / 4))
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							dierect = display.newRect( diexpos, a1rect.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							prevrect3 = dierect
							apc = apc + 1
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
				--		apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							if ((acol2 == 4)) then
							
								dierect = getNextRectA( apc )
								dietext = getNextTextA( apc )
								dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
								dierect:setFillColor( 1, 0, 0 )
								apc = apc + 1
								dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
					--	apc = apc + 1
								camera:add(dierect,1)
								camera:add(dietext,1)
								
								dierect = getNextRectA( apc )
								dietext = getNextTextA( apc )
								dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
								dierect:setFillColor( 1, 0, 0 )
								apc = apc + 1
								dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
					--	apc = apc + 1
								camera:add(dierect,1)
								camera:add(dietext,1)
				
							end
			end
			
			--apc = apc + acol2
			
			
			------------------- a col 3
--		getNextRectA
--getNextTextA
--latestx = a2xpos
					if ((acol3 == 1) or (acol3 == 3) or (acol3 == 5)) then
						diexpos = latestx +  (apcolsW - (apcolsW / 4))
						latestx = diexpos
						dierect = getNextRectA( apc )
						dietext = getNextTextA( apc )
						apc = apc + 1
						dierect = display.newRect( diexpos, 0, 70, 70 )
						dierect:setFillColor( 1, 0, 0 )
						dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
						----print("---at : " .. apc)
						setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
					--	apc = apc + 1
						prevrect = dierect
						camera:add(dierect,1)
						camera:add(dietext,1)
						if ((acol3 == 3)) then
						
							diexpos = latestx-- +  (apcolsW - (apcolsW / 4))
							latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 4), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx +  (apcolsW - (apcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 4), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
					--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
						
						end
						if ((acol3 == 5)) then
						
							diexpos = latestx-- +  (apcolsW - (apcolsW / 4))
							latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							prevrect2 = dierect
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx +  (apcolsW - (apcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 6), 70, 70 )
							prevrect3 = dierect
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
					
						end
			elseif true then
							diexpos = latestx +  (apcolsW - (apcolsW / 4))
							latestx = diexpos
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							apc = apc + 1
							dierect = display.newRect( diexpos, a1rect.y - (4275 / 6), 70, 70 )
							prevrect2 = dierect
							dierect:setFillColor( 1, 0, 0 )
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							--diexpos = a1xpos +  (apcolsW - (apcolsW / 4))
							dierect = getNextRectA( apc )
							dietext = getNextTextA( apc )
							dierect = display.newRect( diexpos, a1rect.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 1, 0, 0 )
							prevrect3 = dierect
							apc = apc + 1
							dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
						--apc = apc + 1
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							if ((acol3 == 4)) then
							
								dierect = getNextRectA( apc )
								dietext = getNextTextA( apc )
								dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
								dierect:setFillColor( 1, 0, 0 )
								apc = apc + 1
								dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
								camera:add(dierect,1)
								camera:add(dietext,1)
								
								dierect = getNextRectA( apc )
								dietext = getNextTextA( apc )
								dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
								dierect:setFillColor( 1, 0, 0 )
								apc = apc + 1
								dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
								camera:add(dierect,1)
								camera:add(dietext,1)
				
							end
			end
			
		--	apc = apc + acol3
		
			if(acol4 > 0) then
									if ((acol4 == 1) or (acol4 == 3) or (acol4 == 5)) then
										diexpos = latestx +  (apcolsW - (apcolsW / 4))
										latestx = diexpos
										dierect = getNextRectA( apc )
										dietext = getNextTextA( apc )
										apc = apc + 1
										dierect = display.newRect( diexpos, 0, 70, 70 )
										dierect:setFillColor( 1, 0, 0 )
										dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
										setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
										prevrect = dierect
										camera:add(dierect,1)
										camera:add(dietext,1)
										if ((acol4 == 3)) then
										
											diexpos = latestx-- +  (apcolsW - (apcolsW / 4))
											latestx = diexpos
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											apc = apc + 1
											dierect = display.newRect( diexpos, prevrect.y - (4275 / 4), 70, 70 )
											dierect:setFillColor( 1, 0, 0 )
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											--diexpos = latestx +  (apcolsW - (apcolsW / 4))
											--latestx = diexpos
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											apc = apc + 1
											dierect = display.newRect( diexpos, prevrect.y + (4275 / 4), 70, 70 )
											dierect:setFillColor( 1, 0, 0 )
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
										
										end
										if ((acol4 == 5)) then
										
											diexpos = latestx-- +  (apcolsW - (apcolsW / 4))
											latestx = diexpos
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											apc = apc + 1
											dierect = display.newRect( diexpos, prevrect.y - (4275 / 6), 70, 70 )
											dierect:setFillColor( 1, 0, 0 )
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											prevrect2 = dierect
											camera:add(dierect,1)
											camera:add(dietext,1)
											--diexpos = latestx +  (apcolsW - (apcolsW / 4))
											--latestx = diexpos
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											apc = apc + 1
											dierect = display.newRect( diexpos, prevrect.y + (4275 / 6), 70, 70 )
											prevrect3 = dierect
											dierect:setFillColor( 1, 0, 0 )
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											apc = apc + 1
											dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
											dierect:setFillColor( 1, 0, 0 )
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											apc = apc + 1
											dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
											dierect:setFillColor( 1, 0, 0 )
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
									
										end
							elseif true then
											diexpos = latestx +  (apcolsW - (apcolsW / 4))
											latestx = diexpos
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											apc = apc + 1
											dierect = display.newRect( diexpos, a1rect.y - (4275 / 6), 70, 70 )
											prevrect2 = dierect
											dierect:setFillColor( 1, 0, 0 )
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											--diexpos = a1xpos +  (apcolsW - (apcolsW / 4))
											dierect = getNextRectA( apc )
											dietext = getNextTextA( apc )
											dierect = display.newRect( diexpos, a1rect.y + (4275 / 6), 70, 70 )
											dierect:setFillColor( 1, 0, 0 )
											prevrect3 = dierect
											apc = apc + 1
											dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											if ((acol4 == 4)) then
											
												dierect = getNextRectA( apc )
												dietext = getNextTextA( apc )
												dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
												dierect:setFillColor( 1, 0, 0 )
												apc = apc + 1
												dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
												setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
												camera:add(dierect,1)
												camera:add(dietext,1)
												
												dierect = getNextRectA( apc )
												dietext = getNextTextA( apc )
												dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
												dierect:setFillColor( 1, 0, 0 )
												apc = apc + 1
												dietext = display.newText( ("A" .. apc), dierect.x, dierect.y, native.systemFont, 32  )
												setNextRectA(apc , dierect)
						setNextTextA(apc , dietext)
												camera:add(dierect,1)
												camera:add(dietext,1)
								
											end
							end
			end
		
		--- b
		b1xpos = (1 * ((5700 / 2) - (golb.contentWidth / 3)))-- + 
		b1rect = display.newRect( b1xpos, 0, 70, 70 )
		b1rect:setFillColor( 0, 0, 1 )
		b1text = display.newText( "B1", b1rect.x, b1rect.y, native.systemFont, 32  )
		camera:add(b1rect,1)
		camera:add(b1text,1)
		
		setNextRectB(1 , b1rect)
		setNextTextB(1 , b1text)
		
		
		--5700,4275
		
		
		
		
		
		
		bcol1 = tonumber(string.sub(common.stra2,0,1))
		bcol2 = tonumber(string.sub(common.stra2,3,3))
		bcol3 = tonumber(string.sub(common.stra2,5,5))
		
		
		if string.len(common.stra2) > 5 then
			bpcols = 4
			bcol4 = tonumber(string.sub(common.stra2,7,7))
		end
		
		
		local bpcolsW = math.abs(b1rect.x) / bpcols
		
		local bpc = 1
		latestx = 0
		--for i=(apc + 1),acol1,1 do 
			
			if ((bcol1 == 1) or (bcol1 == 3) or (bcol1 == 5)) then
						b2xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
						latestx = b2xpos
						b2rect = display.newRect( b2xpos, 0, 70, 70 )
						b2rect:setFillColor( 0, 0, 1 )
						b2text = display.newText( "B2", b2rect.x, b2rect.y, native.systemFont, 32  )
						setNextRectB(2 , b2rect)
						setNextTextB(2 , b2text)
						camera:add(b2rect,1)
						camera:add(b2text,1)
						if ((bcol1 == 3)) then
							b3xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							latestx = b3xpos
							b3rect = display.newRect( b3xpos, b2rect.y - (4275 / 4), 70, 70 )
							b3rect:setFillColor( 0, 0, 1 )
							b3text = display.newText( "B3", b3rect.x, b3rect.y, native.systemFont, 32  )
							setNextRectB(3 , b3rect)
							setNextTextB(3 , b3text)
							camera:add(b3rect,1)
							camera:add(b3text,1)
							b4xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							b4rect = display.newRect( b4xpos, b2rect.y + (4275 / 4), 70, 70 )
							b4rect:setFillColor( 0, 0, 1 )
							b4text = display.newText( "B4", b4rect.x, b4rect.y, native.systemFont, 32  )
							setNextRectB(4 , b4rect)
							setNextTextB(4 , b4text)
							camera:add(b4rect,1)
							camera:add(b4text,1)	
						end
						if ((bcol1 == 5)) then
							b3xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							latestx = b3xpos
							b3rect = display.newRect( b3xpos, b2rect.y - (4275 / 6), 70, 70 )
							b3rect:setFillColor( 0, 0, 1 )
							b3text = display.newText( "B3", b3rect.x, b3rect.y, native.systemFont, 32  )
							setNextRectB(3 , b3rect)
							setNextTextB(3 , b3text)
							camera:add(b3rect,1)
							camera:add(b3text,1)
							b4xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							b4rect = display.newRect( b4xpos, b2rect.y + (4275 / 6), 70, 70 )
							b4rect:setFillColor( 0, 0, 1 )
							b4text = display.newText( "B4", b4rect.x, b4rect.y, native.systemFont, 32  )
							setNextRectB(4 , b4rect)
							setNextTextB(4 , b4text)
							camera:add(b4rect,1)
							camera:add(b4text,1)	
							b5xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							b5rect = display.newRect( b5xpos, b3rect.y - (4275 / 6), 70, 70 )
							b5rect:setFillColor( 0, 0, 1 )
							b5text = display.newText( "B5", b5rect.x, b5rect.y, native.systemFont, 32  )
							setNextRectB(5 , b5rect)
							setNextTextB(5 , b5text)
							camera:add(b5rect,1)
							camera:add(b5text,1)
							b6xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							b6rect = display.newRect( b6xpos, b4rect.y + (4275 / 6), 70, 70 )
							b6rect:setFillColor( 0, 0, 1 )
							b6text = display.newText( "B6", b6rect.x, b6rect.y, native.systemFont, 32  )
							setNextRectB(6 , b6rect)
							setNextTextB(6 , b6text)
							camera:add(b6rect,1)
							camera:add(b6text,1)	
						end
			elseif true then
							b2xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							latestx = b2xpos
							b2rect = display.newRect( b2xpos, b1rect.y - (4275 / 6), 70, 70 )
							b2rect:setFillColor( 0, 0, 1 )
							b2text = display.newText( "B2", b2rect.x, b2rect.y, native.systemFont, 32  )
							setNextRectB(2 , b2rect)
							setNextTextB(2 , b2text)
							camera:add(b2rect,1)
							camera:add(b2text,1)
							b3xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
							b3rect = display.newRect( b3xpos, b1rect.y + (4275 / 6), 70, 70 )
							b3rect:setFillColor( 0, 0, 1 )
							b3text = display.newText( "B3", b3rect.x, b3rect.y, native.systemFont, 32  )
							setNextRectB(3 , b3rect)
							setNextTextB(3 , b3text)
							camera:add(b3rect,1)
							camera:add(b3text,1)
							if ((bcol1 == 4)) then
								b4xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
								b4rect = display.newRect( b4xpos, b2rect.y - (4275 / 6), 70, 70 )
								b4rect:setFillColor( 0, 0, 1 )
								b4text = display.newText( "B4", b4rect.x, b4rect.y, native.systemFont, 32  )
								setNextRectB(4 , b4rect)
								setNextTextB(4 , b4text)
								camera:add(b4rect,1)
								camera:add(b4text,1)
								b5xpos = b1xpos -  (bpcolsW - (bpcolsW / 4))
								b5rect = display.newRect( b5xpos, b3rect.y + (4275 / 6), 70, 70 )
								b5rect:setFillColor( 0, 0, 1 )
								b5text = display.newText( "B5", b5rect.x, b5rect.y, native.systemFont, 32  )
								setNextRectB(5 , b5rect)
								setNextTextB(5 , b5text)
								camera:add(b5rect,1)
								camera:add(b5text,1)
							end
			end
			
			bpc = bpc + bcol1
		--end
		
		------------------- a col 2
--		getNextRectA
--getNextTextA
--latestx = a2xpos
			
		if ((bcol2 == 1) or (bcol2 == 3) or (bcol2 == 5)) then
						diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
						latestx = diexpos
						dierect = getNextRectB( bpc )
						dietext = getNextTextB( bpc )
						bpc = bpc + 1
						dierect = display.newRect( diexpos, 0, 70, 70 )
						dierect:setFillColor( 0, 0, 1 )
						dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
						setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
						prevrect = dierect
						camera:add(dierect,1)
						camera:add(dietext,1)
						if ((bcol2 == 3)) then
						
							diexpos = latestx-- +  (bpcolsW - (bpcolsW / 4))
							latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 4), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 4), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
						
						end
						if ((bcol2 == 5)) then
						
							diexpos = latestx-- +  (bpcolsW - (bpcolsW / 4))
							latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							prevrect2 = dierect
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 6), 70, 70 )
							prevrect3 = dierect
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
					
						end
			elseif true then
							diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
							latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, a1rect.y - (4275 / 6), 70, 70 )
							prevrect2 = dierect
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							--diexpos = a1xpos +  (bpcolsW - (bpcolsW / 4))
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							dierect = display.newRect( diexpos, a1rect.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							prevrect3 = dierect
							bpc = bpc + 1
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							if ((bcol2 == 4)) then
							
								dierect = getNextRectB( bpc )
								dietext = getNextTextB( bpc )
								dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
								dierect:setFillColor( 0, 0, 1 )
								bpc = bpc + 1
								dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
								camera:add(dierect,1)
								camera:add(dietext,1)
								
								dierect = getNextRectB( bpc )
								dietext = getNextTextB( bpc )
								dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
								dierect:setFillColor( 0, 0, 1 )
								bpc = bpc + 1
								dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
								camera:add(dierect,1)
								camera:add(dietext,1)
				
							end
			end
			
		--	bpc = bpc + bcol2
			
			
			------------------- a col 3
--		getNextRectB
--getNextTextB
--latestx = a2xpos
					if ((bcol3 == 1) or (bcol3 == 3) or (bcol3 == 5)) then
						diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
						latestx = diexpos
						dierect = getNextRectB( bpc )
						dietext = getNextTextB( bpc )
						bpc = bpc + 1
						dierect = display.newRect( diexpos, 0, 70, 70 )
						dierect:setFillColor( 0, 0, 1 )
						dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
						setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
						prevrect = dierect
						camera:add(dierect,1)
						camera:add(dietext,1)
						if ((bcol3 == 3)) then
						
							diexpos = latestx-- +  (bpcolsW - (bpcolsW / 4))
							latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 4), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 4), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
						
						end
						if ((bcol3 == 5)) then
						
							diexpos = latestx-- +  (bpcolsW - (bpcolsW / 4))
							latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							prevrect2 = dierect
							camera:add(dierect,1)
							camera:add(dietext,1)
							--diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
							--latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect.y + (4275 / 6), 70, 70 )
							prevrect3 = dierect
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
					
						end
			elseif true then
							diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
							latestx = diexpos
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							bpc = bpc + 1
							dierect = display.newRect( diexpos, a1rect.y - (4275 / 6), 70, 70 )
							prevrect2 = dierect
							dierect:setFillColor( 0, 0, 1 )
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							--diexpos = a1xpos +  (bpcolsW - (bpcolsW / 4))
							dierect = getNextRectB( bpc )
							dietext = getNextTextB( bpc )
							dierect = display.newRect( diexpos, a1rect.y + (4275 / 6), 70, 70 )
							dierect:setFillColor( 0, 0, 1 )
							prevrect3 = dierect
							bpc = bpc + 1
							dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
							setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
							camera:add(dierect,1)
							camera:add(dietext,1)
							
							if ((bcol3 == 4)) then
							
								dierect = getNextRectB( bpc )
								dietext = getNextTextB( bpc )
								dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
								dierect:setFillColor( 0, 0, 1 )
								bpc = bpc + 1
								dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
								camera:add(dierect,1)
								camera:add(dietext,1)
								
								dierect = getNextRectB( bpc )
								dietext = getNextTextB( bpc )
								dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
								dierect:setFillColor( 0, 0, 1 )
								bpc = bpc + 1
								dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
								setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
								camera:add(dierect,1)
								camera:add(dietext,1)
				
							end
			end
			
		--	bpc = bpc + bcol3
		
			if(bcol4 > 0) then
									if ((bcol4 == 1) or (bcol4 == 3) or (bcol4 == 5)) then
										diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
										latestx = diexpos
										dierect = getNextRectB( bpc )
										dietext = getNextTextB( bpc )
										bpc = bpc + 1
										dierect = display.newRect( diexpos, 0, 70, 70 )
										dierect:setFillColor( 0, 0, 1 )
										dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
										setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
										prevrect = dierect
										camera:add(dierect,1)
										camera:add(dietext,1)
										if ((bcol4 == 3)) then
										
											diexpos = latestx-- +  (bpcolsW - (bpcolsW / 4))
											latestx = diexpos
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											bpc = bpc + 1
											dierect = display.newRect( diexpos, prevrect.y - (4275 / 4), 70, 70 )
											dierect:setFillColor( 0, 0, 1 )
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											--diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
											--latestx = diexpos
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											bpc = bpc + 1
											dierect = display.newRect( diexpos, prevrect.y + (4275 / 4), 70, 70 )
											dierect:setFillColor( 0, 0, 1 )
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
										
										end
										if ((bcol4 == 5)) then
										
											diexpos = latestx-- +  (bpcolsW - (bpcolsW / 4))
											latestx = diexpos
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											bpc = bpc + 1
											dierect = display.newRect( diexpos, prevrect.y - (4275 / 6), 70, 70 )
											dierect:setFillColor( 0, 0, 1 )
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											prevrect2 = dierect
											camera:add(dierect,1)
											camera:add(dietext,1)
											--diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
											--latestx = diexpos
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											bpc = bpc + 1
											dierect = display.newRect( diexpos, prevrect.y + (4275 / 6), 70, 70 )
											prevrect3 = dierect
											dierect:setFillColor( 0, 0, 1 )
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											bpc = bpc + 1
											dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
											dierect:setFillColor( 0, 0, 1 )
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											bpc = bpc + 1
											dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
											dierect:setFillColor( 0, 0, 1 )
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
									
										end
							elseif true then
											diexpos = latestx -  (bpcolsW - (bpcolsW / 4))
											latestx = diexpos
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											bpc = bpc + 1
											dierect = display.newRect( diexpos, a1rect.y - (4275 / 6), 70, 70 )
											prevrect2 = dierect
											dierect:setFillColor( 0, 0, 1 )
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											--diexpos = a1xpos +  (bpcolsW - (bpcolsW / 4))
											dierect = getNextRectB( bpc )
											dietext = getNextTextB( bpc )
											dierect = display.newRect( diexpos, a1rect.y + (4275 / 6), 70, 70 )
											dierect:setFillColor( 0, 0, 1 )
											prevrect3 = dierect
											bpc = bpc + 1
											dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
											setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
											camera:add(dierect,1)
											camera:add(dietext,1)
											
											if ((bcol4 == 4)) then
											
												dierect = getNextRectB( bpc )
												dietext = getNextTextB( bpc )
												dierect = display.newRect( diexpos, prevrect2.y - (4275 / 6), 70, 70 )
												dierect:setFillColor( 0, 0, 1 )
												bpc = bpc + 1
												dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
												setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
												camera:add(dierect,1)
												camera:add(dietext,1)
												
												dierect = getNextRectB( bpc )
												dietext = getNextTextB( bpc )
												dierect = display.newRect( diexpos, prevrect3.y + (4275 / 6), 70, 70 )
												dierect:setFillColor( 0, 0, 1 )
												bpc = bpc + 1
												dietext = display.newText( ("B" .. bpc), dierect.x, dierect.y, native.systemFont, 32  )
												setNextRectB(bpc , dierect)
						setNextTextB(bpc , dietext)
												camera:add(dierect,1)
												camera:add(dietext,1)
								
											end
							end
			end
		
end



-- create players -----------------------------------------------------------------------


--camera:add(GOLERsprite,1)
--camera:add(WHITEsprite,1)
--camera:add(REDsprite,1)
--camera:add(BLUEsprite,1)

--getposdbar()

local centercor = display.newImage( "centercor.png" )
centercor:translate( 3, 0 )
camera:add(centercor,1)

local horl = display.newImage( "horl.png" )
horl:translate( -4, (-1) * ( centercor.contentHeight / 2) )
camera:add(horl,1)
local horl2 = display.newImage( "horl.png" )
horl2:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) + (horl.contentHeight * 4) )
camera:add(horl2,1)
local horl3 = display.newImage( "horl.png" )
horl3:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) + (horl.contentHeight * 3) )
camera:add(horl3,1)
local horl4 = display.newImage( "horl.png" )
horl4:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) + (horl.contentHeight * 2) )
camera:add(horl4,1)
local horl5 = display.newImage( "horl.png" )
horl5:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) + (horl.contentHeight * 1) )
camera:add(horl5,1)
local horl6 = display.newImage( "horl.png" )
horl6:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) + (0) )
camera:add(horl6,1)
local horl7 = display.newImage( "horl.png" )
horl7:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 1) )
camera:add(horl7,1)
local horl8 = display.newImage( "horl.png" )
horl8:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 2) )
camera:add(horl8,1)
local horl9 = display.newImage( "horl.png" )
horl9:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 3) )
camera:add(horl9,1)
local horl10 = display.newImage( "horl.png" )
horl10:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 4) )
camera:add(horl10,1)
local horl11 = display.newImage( "horl.png" )
horl11:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 5) )
camera:add(horl11,1)
local horl12 = display.newImage( "horl.png" )
horl12:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 6) )
camera:add(horl12,1)
local horl13 = display.newImage( "horl.png" )
horl13:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 7) )
camera:add(horl13,1)
local horl14 = display.newImage( "horl.png" )
horl14:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 8) )
camera:add(horl14,1)
local horl15 = display.newImage( "horl.png" )
horl15:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 9) )
camera:add(horl15,1)
local horl16 = display.newImage( "horl.png" )
horl16:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 10) )
camera:add(horl16,1)
local horl17 = display.newImage( "horl.png" )
horl17:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 11) )
camera:add(horl17,1)
local horl18 = display.newImage( "horl.png" )
horl18:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 12) )
camera:add(horl18,1)
local horl19 = display.newImage( "horl.png" )
horl19:translate( -4,  ((-1) * ( centercor.contentHeight / 1)) - (horl.contentHeight * 12) - 3 )
camera:add(horl19,1)


local horlb = display.newImage( "horl.png" )
horlb:translate( -4, (1) * ( centercor.contentHeight / 2) )
camera:add(horlb,1)
local horlb2 = display.newImage( "horl.png" )
horlb2:translate( -4,  ((1) * ( centercor.contentHeight / 1)) - (horlb.contentHeight * 4) )
camera:add(horlb2,1)
local horlb3 = display.newImage( "horl.png" )
horlb3:translate( -4,  ((1) * ( centercor.contentHeight / 1)) - (horlb.contentHeight * 3) )
camera:add(horlb3,1)
local horlb4 = display.newImage( "horl.png" )
horlb4:translate( -4,  ((1) * ( centercor.contentHeight / 1)) - (horlb.contentHeight * 2) )
camera:add(horlb4,1)
local horlb5 = display.newImage( "horl.png" )
horlb5:translate( -4,  ((1) * ( centercor.contentHeight / 1)) - (horlb.contentHeight * 1) )
camera:add(horlb5,1)
local horlb6 = display.newImage( "horl.png" )
horlb6:translate( -4,  ((1) * ( centercor.contentHeight / 1)) - (0) )
camera:add(horlb6,1)
local horlb7 = display.newImage( "horl.png" )
horlb7:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 1) )
camera:add(horlb7,1)
local horlb8 = display.newImage( "horl.png" )
horlb8:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 2) )
camera:add(horlb8,1)
local horlb9 = display.newImage( "horl.png" )
horlb9:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 3) )
camera:add(horlb9,1)
local horlb10 = display.newImage( "horl.png" )
horlb10:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 4) )
camera:add(horlb10,1)
local horlb11 = display.newImage( "horl.png" )
horlb11:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 5) )
camera:add(horlb11,1)
local horlb12 = display.newImage( "horl.png" )
horlb12:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 6) )
camera:add(horlb12,1)
local horlb13 = display.newImage( "horl.png" )
horlb13:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 7) )
camera:add(horlb13,1)
local horlb14 = display.newImage( "horl.png" )
horlb14:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 8) )
camera:add(horlb14,1)
local horlb15 = display.newImage( "horl.png" )
horlb15:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 9) )
camera:add(horlb15,1)
local horlb16 = display.newImage( "horl.png" )
horlb16:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 10) )
camera:add(horlb16,1)
local horlb17 = display.newImage( "horl.png" )
horlb17:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 11) )
camera:add(horlb17,1)
local horlb18 = display.newImage( "horl.png" )
horlb18:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 12) )
camera:add(horlb18,1)
local horlb19 = display.newImage( "horl.png" )
horlb19:translate( -4,  ((1) * ( centercor.contentHeight / 1)) + (horlb.contentHeight * 12) + 3 )
camera:add(horlb19,1)

--5700,4275
gola = display.newImage( "gola.png" )
gola:translate( -1 * ((5700 / 2) - (gola.contentWidth / 2)),  0 )
camera:add(gola,1)

golb = display.newImage( "golb.png" )
golb:translate( 1 * ((5700 / 2) - (golb.contentWidth / 2)),  0 )
camera:add(golb,1)

local corna1 = display.newImage( "corna1.png" )
corna1:translate( -1 * ((5700 / 2) - (corna1.contentWidth / 2)),  -1 * ((4275 / 2) - (corna1.contentHeight / 2)) )
camera:add(corna1,1)

local corna2 = display.newImage( "corna2.png" )
corna2:translate( -1 * ((5700 / 2) - (corna2.contentWidth / 2)),  1 * ((4275 / 2) - (corna2.contentHeight / 2)) )
camera:add(corna2,1)

local cornb1 = display.newImage( "cornb1.png" )
cornb1:translate( 1 * ((5700 / 2) - (cornb1.contentWidth / 2)),  -1 * ((4275 / 2) - (cornb1.contentHeight / 2)) )
camera:add(cornb1,1)

local cornb2 = display.newImage( "cornb2.png" )
cornb2:translate( 1 * ((5700 / 2) - (cornb2.contentWidth / 2)),  1 * ((4275 / 2) - (cornb2.contentHeight / 2)) )
camera:add(cornb2,1)


--- playesr
local paprevstat = {}
local pbprevstat = {}

local pa1 = display.newSprite( group, GOLERcharacterSheet, GOLERsequenceData )
pa1.x = getPlayerX( "A1" )
pa1.y = getPlayerY( "A1" )
camera:add(pa1,1)
local pa2 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa2.x = getPlayerX( "A2" )
pa2.y = getPlayerY( "A2" )
camera:add(pa2,1)
local pa3 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa3.x = getPlayerX( "A3" )
pa3.y = getPlayerY( "A3" )
camera:add(pa3,1)
local pa4 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa4.x = getPlayerX( "A4" )
pa4.y = getPlayerY( "A4" )
camera:add(pa4,1)
local pa5 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa5.x = getPlayerX( "A5" )
pa5.y = getPlayerY( "A5" )
camera:add(pa5,1)
local pa6 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa6.x = getPlayerX( "A6" )
pa6.y = getPlayerY( "A6" )
camera:add(pa6,1)
local pa7 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa7.x = getPlayerX( "A7" )
pa7.y = getPlayerY( "A7" )
camera:add(pa7,1)
local pa8 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa8.x = getPlayerX( "A8" )
pa8.y = getPlayerY( "A8" )
camera:add(pa8,1)
local pa9 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa9.x = getPlayerX( "A9" )
pa9.y = getPlayerY( "A9" )
camera:add(pa9,1)
local pa10 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa10.x = getPlayerX( "A10" )
pa10.y = getPlayerY( "A10" )
camera:add(pa10,1)
local pa11 = display.newSprite( group, REDcharacterSheet, REDsequenceData )
pa11.x = getPlayerX( "A11" )
pa11.y = getPlayerY( "A11" )
camera:add(pa11,1)

local pb1 = display.newSprite( group, GOLERcharacterSheet, GOLERsequenceData )
pb1.x = getPlayerX( "B1" )
pb1.y = getPlayerY( "B1" )
camera:add(pb1,1)
local pb2 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb2.x = getPlayerX( "B2" )
pb2.y = getPlayerY( "B2" )
camera:add(pb2,1)
local pb3 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb3.x = getPlayerX( "B3" )
pb3.y = getPlayerY( "B3" )
camera:add(pb3,1)
local pb4 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb4.x = getPlayerX( "B4" )
pb4.y = getPlayerY( "B4" )
camera:add(pb4,1)
local pb5 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb5.x = getPlayerX( "B5" )
pb5.y = getPlayerY( "B5" )
camera:add(pb5,1)
local pb6 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb6.x = getPlayerX( "B6" )
pb6.y = getPlayerY( "B6" )
camera:add(pb6,1)
local pb7 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb7.x = getPlayerX( "B7" )
pb7.y = getPlayerY( "B7" )
camera:add(pb7,1)
local pb8 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb8.x = getPlayerX( "B8" )
pb8.y = getPlayerY( "B8" )
camera:add(pb8,1)
local pb9 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb9.x = getPlayerX( "B9" )
pb9.y = getPlayerY( "B9" )
camera:add(pb9,1)
local pb10 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb10.x = getPlayerX( "B10" )
pb10.y = getPlayerY( "B10" )
camera:add(pb10,1)
local pb11 = display.newSprite( group, BLUEcharacterSheet, BLUEsequenceData )
pb11.x = getPlayerX( "B11" )
pb11.y = getPlayerY( "B11" )
camera:add(pb11,1)

-------------------------------------- add ball ---------------------------------------------------------


local ballsequenceData = {
			name = "character",
			start = (1 * 4) - 3,
			count = 8,
			time = 600
		}
		local player = display.newSprite( group, ballcharacterSheet, ballsequenceData )
		player.x = 0--1 * 160
		player.y = 0--1 * 160
		--player:scale( 4,4 )
		player:play()

--camera:add(player, math.random(0, camera:layerCount()))


--local actifPlayer = display.newImage( "actif-small.png" )

--local actifPlayer = display.newPolygon(0, 0, {0,0, 20,20, 30,0})
--actifPlayer.strokeWidth = 6
--actifPlayer:setFillColor(255, 0, 0, 0.60)
--actifPlayer.anchorX = 0.2 -- Slightly more "realistic" than center-point rotating
--camera:add(actifPlayer, 1) 

--------------------------------------------------------------------------------
-- Build Player
--------------------------------------------------------------------------------
--local player = display.newPolygon(0, 0, {-50,-30, -50,30, 50,0})
--player.strokeWidth = 6
--player:setFillColor(0, 0, 0, 0)
--player.anchorX = 0.2 -- Slightly more "realistic" than center-point rotating

-- Some various movement parameters
player.angularVelocity = 0           -- Speed at which player rotates
player.angularAcceleration = 1.05    -- Angular acceleration rate
player.angularDamping = 0.9          -- Angular damping rate
player.angularMax = 10               -- Max angular velocity
player.moveSpeed = 0                 -- Current movement speed
player.linearDamping = 0             -- Linear damping rate
player.linearAcceleration = 1.05     -- Linear acceleration rate
player.linearMax = 10                -- Max linear velocity

--camera:add(bg 0)
camera:add(player, 1) -- Add player to layer 1 of the camera


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

pcreateposes()
local numapha = 0--1--0.25
aplisterect[1].alpha = numapha
--aplisterect[1]:scale( 0.3,0.3 )
--aplistetext[1]:scale( 0.3,0.3 )
--aplistetext[1].y = aplistetext[1].y + 103
--aplisterect[1].y = aplisterect[1].y + 103
aplistetext[1].alpha = numapha
aplisterect[2].alpha = numapha
aplistetext[2].alpha = numapha
aplisterect[3].alpha = numapha
aplistetext[3].alpha = numapha
aplisterect[4].alpha = numapha
aplistetext[4].alpha = numapha
aplisterect[5].alpha = numapha
aplistetext[5].alpha = numapha
aplisterect[6].alpha = numapha
aplistetext[6].alpha = numapha
aplisterect[7].alpha = numapha
aplistetext[7].alpha = numapha
aplisterect[8].alpha = numapha
aplistetext[8].alpha = numapha
aplisterect[9].alpha = numapha
aplistetext[9].alpha = numapha
aplisterect[10].alpha = numapha
aplistetext[10].alpha = numapha
aplisterect[11].alpha = numapha
aplistetext[11].alpha = numapha

bplisterect[1].alpha = numapha
bplistetext[1].alpha = numapha
bplisterect[2].alpha = numapha
bplistetext[2].alpha = numapha
bplisterect[3].alpha = numapha
bplistetext[3].alpha = numapha
bplisterect[4].alpha = numapha
bplistetext[4].alpha = numapha
bplisterect[5].alpha = numapha
bplistetext[5].alpha = numapha
bplisterect[6].alpha = numapha
bplistetext[6].alpha = numapha
bplisterect[7].alpha = numapha
bplistetext[7].alpha = numapha
bplisterect[8].alpha = numapha
bplistetext[8].alpha = numapha
bplisterect[9].alpha = numapha
bplistetext[9].alpha = numapha
bplisterect[10].alpha = numapha
bplistetext[10].alpha = numapha
bplisterect[11].alpha = numapha
bplistetext[11].alpha = numapha

pa1.x = aplisterect[1].x
pa1.y = aplisterect[1].y
pa1:toFront()
aplistesprit[1] = pa1
pa2.x = aplisterect[2].x
pa2.y = aplisterect[2].y
pa2:toFront()
aplistesprit[2] = pa2
pa3.x = aplisterect[3].x
pa3.y = aplisterect[3].y
pa3:toFront()
aplistesprit[3] = pa3
pa4.x = aplisterect[4].x
pa4.y = aplisterect[4].y
pa4:toFront()
aplistesprit[4] = pa4
pa5.x = aplisterect[5].x
pa5.y = aplisterect[5].y
pa5:toFront()
aplistesprit[5] = pa5
pa6.x = aplisterect[6].x
pa6.y = aplisterect[6].y
pa6:toFront()
aplistesprit[6] = pa6
pa7.x = aplisterect[7].x
pa7.y = aplisterect[7].y
pa7:toFront()
aplistesprit[7] = pa7
pa8.x = aplisterect[8].x
pa8.y = aplisterect[8].y
pa8:toFront()
aplistesprit[8] = pa8
pa9.x = aplisterect[9].x
pa9.y = aplisterect[9].y
pa9:toFront()
aplistesprit[9] = pa9
pa10.x = aplisterect[10].x
pa10.y = aplisterect[10].y
pa10:toFront()
aplistesprit[10] = pa10
pa11.x = aplisterect[11].x
pa11.y = aplisterect[11].y
pa11:toFront()
aplistesprit[11] = pa11

pb1.x = bplisterect[1].x
pb1.y = bplisterect[1].y
pb1:toFront()
bplistesprit[1] = pb1
pb2.x = bplisterect[2].x
pb2.y = bplisterect[2].y
pb2:toFront()
bplistesprit[2] = pb2
pb3.x = bplisterect[3].x
pb3.y = bplisterect[3].y
pb3:toFront()
bplistesprit[3] = pb3
pb4.x = bplisterect[4].x
pb4.y = bplisterect[4].y
pb4:toFront()
bplistesprit[4] = pb4
pb5.x = bplisterect[5].x
pb5.y = bplisterect[5].y
pb5:toFront()
bplistesprit[5] = pb5
pb6.x = bplisterect[6].x
pb6.y = bplisterect[6].y
pb6:toFront()
bplistesprit[6] = pb6
pb7.x = bplisterect[7].x
pb7.y = bplisterect[7].y
pb7:toFront()
bplistesprit[7] = pb7
pb8.x = bplisterect[8].x
pb8.y = bplisterect[8].y
pb8:toFront()
bplistesprit[8] = pb8
pb9.x = bplisterect[9].x
pb9.y = bplisterect[9].y
pb9:toFront()
bplistesprit[9] = pb9
pb10.x = bplisterect[10].x
pb10.y = bplisterect[10].y
pb10:toFront()
bplistesprit[10] = pb10
pb11.x = bplisterect[11].x
pb11.y = bplisterect[11].y
pb11:toFront()
bplistesprit[11] = pb11

----------------------------------------------------------------------------------------------


camera:prependLayer()

------------


camera:setParallax(1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3) -- Here we set parallax for each layer in descending order

--------------------------------------------------------------------------------
-- Movement Buttons
--------------------------------------------------------------------------------
local m = {}
m.result = "none"
m.rotate = {}

m.rotate.left = display.newRect(0, 0, 60, 60)
	m.rotate.left.x = display.screenOriginX + m.rotate.left.contentWidth + 10
	m.rotate.left.y = display.contentHeight - m.rotate.left.contentHeight - 10
	m.rotate.left.result = "rotate:left"

m.rotate.right = display.newRect(0, 0, 60, 60)
	m.rotate.right.x = display.contentWidth - display.screenOriginX - m.rotate.right.contentWidth - 10
	m.rotate.right.y = display.contentHeight - m.rotate.right.contentHeight - 10
	m.rotate.right.result = "rotate:right"

m.forward = display.newRect(0, 0, display.contentWidth * 0.75, 60)
	m.forward.x = display.contentCenterX
	m.forward.y = display.contentHeight - m.forward.contentHeight - 10
	m.forward.result = "move"


m.rotate.left:toBack()
m.rotate.right:toBack()
m.forward:toBack()

----------------------------
common.lastLink = "inlinehelp"
--------------------------------------------------------------------------------
-- Touch Movement Buttons
--------------------------------------------------------------------------------
function m.touch(event)
	local t = event.target
	
	do return end
	------print( "local hit ****************" )

	if "began" == event.phase then
		display.getCurrentStage():setFocus(t)
		t.isFocus = true
		m.result = t.result

		if t.result == "rotate:left" then 
			player.angularVelocity = -2
		elseif t.result == "rotate:right" then
			player.angularVelocity = 2
		elseif t.result == "move" then
			player.moveSpeed = 2
		end
	elseif t.isFocus then
		if "moved" == event.phase then
		
		elseif "ended" == event.phase then
			display.getCurrentStage():setFocus(nil)
			t.isFocus = false
			m.result = "none"
		end
	end
end

m.rotate.left:addEventListener("touch", m.touch)
m.rotate.right:addEventListener("touch", m.touch)
m.forward:addEventListener("touch", m.touch)

--------------------------------------------------------------------------------
-- Runtime Loop
player.moveSpeed = 0
local fcx = 0
local fcy = 0
local fcs = 1
--------------------------------------------------------------------------------
local function getcanchange(num)
	local ret = true
	if common.myside == "a" then
		if  (num == 11) then 
			if (pa11.oncontrol == "user") then
				--pa11.oncontrol = "ns" 
				print ("*** yah false")
				--common.myplayactif = "ns"
				ret = true-- false
			end
		end
	end
	--[[
		if (((pa11.oncontrol == "user") and (num == 11)) or ((pa10.oncontrol == "user") and (num == 10)) or ((pa9.oncontrol == "user") and (num == 9)) or ((pa8.oncontrol == "user") and (num == 8)) or ((pa7.oncontrol == "user") and (num == 7)) or ((pa6.oncontrol == "user") and (num == 6)) or ((pa5.oncontrol == "user") and (num == 5)) or ((pa4.oncontrol == "user") and (num == 4)) or ((pa3.oncontrol == "user") and (num == 3)) or ((pa2.oncontrol == "user") and (num == 2)) or ((pa1.oncontrol == "user") and (num == 1))) then
			ret = false
			if  (num == 1) then pa1.oncontrol = "ns" end
			if  (num == 2) then pa2.oncontrol = "ns" end
			if  (num == 3) then pa3.oncontrol = "ns" end
			if  (num == 4) then pa4.oncontrol = "ns" end
			if  (num == 5) then pa5.oncontrol = "ns" end
			if  (num == 6) then pa6.oncontrol = "ns" end
			if  (num == 7) then pa7.oncontrol = "ns" end
			if  (num == 8) then pa8.oncontrol = "ns" end
			if  (num == 9) then pa9.oncontrol = "ns" end
			if  (num == 10) then pa10.oncontrol = "ns" end
			if  (num == 11) then pa11.oncontrol = "ns" end
		end
	end
	if common.myside == "b" then
		if (((pb11.oncontrol == "user") and (num == 11)) or ((pb10.oncontrol == "user") and (num == 10)) or ((pb9.oncontrol == "user") and (num == 9)) or ((pb8.oncontrol == "user") and (num == 8)) or ((pb7.oncontrol == "user") and (num == 7)) or ((pb6.oncontrol == "user") and (num == 6)) or ((pb5.oncontrol == "user") and (num == 5)) or ((pb4.oncontrol == "user") and (num == 4)) or ((pb3.oncontrol == "user") and (num == 3)) or ((pb2.oncontrol == "user") and (num == 2)) or ((pb1.oncontrol == "user") and (num == 1))) then
			ret = fblse
			if  (num == 1) then pb1.oncontrol = "ns" end
			if  (num == 2) then pb2.oncontrol = "ns" end
			if  (num == 3) then pb3.oncontrol = "ns" end
			if  (num == 4) then pb4.oncontrol = "ns" end
			if  (num == 5) then pb5.oncontrol = "ns" end
			if  (num == 6) then pb6.oncontrol = "ns" end
			if  (num == 7) then pb7.oncontrol = "ns" end
			if  (num == 8) then pb8.oncontrol = "ns" end
			if  (num == 9) then pb9.oncontrol = "ns" end
			if  (num == 10) then pb10.oncontrol = "ns" end
			if  (num == 11) then pb11.oncontrol = "ns" end
		end
	end
	--print("+++++++++++++== die ret is :: " .. string.format("%s", ret))
	--]]
	return ret
end
local trychangecont = 0
local function changemyplayer()
	trychangecont = trychangecont + 1
	if(trychangecont >= 2) then
	trychangecont = 0
	local mynumber = tonumber(string.sub(common.myplayactif,2))
		
	local numapha = 0.4
	aplistetext[mynumber].alpha = 0--numapha
	aplisterect[mynumber].alpha = 0--numapha
	----print("***table.getn(common.myplayers) = " .. table.getn(common.myplayers))
	
	--pa11.oncontrol = "user"
	if getcanchange(mynumber) == true then
		
		if (mynumber > 2) then
			local newmynumber = mynumber - 1
			local myindex = 0
			
			for i=1,table.getn(common.myplayers),1 do 
				----print("****comp me :: " .. common.myplayers[i] .. "===" .. (common.myside .. newmynumber))
				if (common.myplayers[i] == (common.myside .. newmynumber)) then
					myindex = i
				end
			end
			if myindex ~= 0 then
				mynumber = newmynumber
				aplistetext[mynumber].alpha = numapha
				aplisterect[mynumber].alpha = numapha
			end
		elseif true then
			common.myplayactif = common.myplayers[table.getn(common.myplayers)]
			mynumber = tonumber(string.sub(common.myplayactif,2))
			aplistetext[mynumber].alpha = numapha
			aplisterect[mynumber].alpha = numapha
		end
		common.myplayactif = common.myside .. mynumber
	end
	if common.myplayactif == "ns" then
		--common.myplayactif
	end
	end
end
local function showactifplayerme ( )
	--common.myplayactif = common.myplayers[table.getn(common.myplayers)]
	------print("******* common.myplayactif = " .. common.myplayactif)
	------print("******* string.sub(common.myplayactif,1) = " .. string.sub(common.myplayactif,2))
	 --= common.myplayactif.gsub(,2)
	local mynumber = tonumber(string.sub(common.myplayactif,2))
	local numapha = 0.4
	------print("mynumber = " .. mynumber)
	
	aplistetext[mynumber].alpha = numapha
	aplisterect[mynumber].alpha = numapha
	--common.myside = "ns"
	
	
end
local function startdiegame()
--	pa1.x = aplisterect[1].x
	--pa1.y = aplisterect[1].y
	--pa1:toFront()
	--aplistesprit[1] = pa1
	--pa1.x (centercor.contentWidth / 2)
	
	--local apcols = 3
		--local acol1 = 0
		--local acol2 = 0
		--local acol3 = 0
		--local acol4 = 0
		--local bpcols = 3
		--local bcol1 = 0
		--local bcol2 = 0
		--local bcol3 = 0
		--local bcol4 = 0
	----print("apcols = " .. display.contentWidth .. " - bpcols = " .. bpcols)
	
	local tacol = acol4
	if( tacol == 0) then
		tacol = acol3
	end
	if( tacol == 1 ) then
		pa11.x = (-1 * (display.contentWidth / 10))
		pa11.y = 0
	end
	if( tacol == 2 ) then
		pa11.x = (-1 * (display.contentWidth / 10))
		pa11.y = (-1 * (display.contentHeight / 30))
		pa10.x = (-1 * (display.contentWidth / 10))
		pa10.y = (1 * (display.contentHeight / 30))
	end
	if( tacol == 3 ) then
		pa11.x = (-1 * (display.contentWidth / 10))
		pa11.y = 0
		pa10.x = (-1 * (display.contentWidth / 10))
		pa10.y = (-1 * (display.contentHeight / 30))
		pa9.x = (-1 * (display.contentWidth / 10))
		pa9.y = (1 * (display.contentHeight / 30))
	end
	if( tacol == 4 ) then
		pa11.x = (-1 * (display.contentWidth / 10))
		pa11.y = (-1 * (display.contentHeight / 30))
		pa10.x = (-1 * (display.contentWidth / 10))
		pa10.y = (1 * (display.contentHeight / 30))
		
		pa9.x = (-1 * (display.contentWidth / 10))
		pa9.y = (-1 * (display.contentHeight / 5))
		
		pa8.x = (-1 * (display.contentWidth / 10))
		pa8.y = (1 * (display.contentHeight / 5))
	end
	if( tacol == 5 ) then
		pa11.x = (-1 * (display.contentWidth / 10))
		pa11.y = (-1 * (display.contentHeight / 30))
		pa10.x = (-1 * (display.contentWidth / 10))
		pa10.y = (1 * (display.contentHeight / 30))
		
		pa9.x = (-1 * (display.contentWidth / 10))
		pa9.y = (-1 * (display.contentHeight / 5))
		
		pa8.x = (-1 * (display.contentWidth / 10))
		pa8.y = (1 * (display.contentHeight / 5))
		
		pa7.x = (-1 * (display.contentWidth / 10))
		pa7.y = 0--(-1 * (display.contentWidth / 10))
	end
	
	---------------------------
	
	local tbcol = bcol4
	if( tbcol == 0) then
		tbcol = bcol3
	end
	if( tbcol == 1 ) then
		pb11.x = (1 * (display.contentWidth / 10))
		pb11.y = 0
	end
	if( tbcol == 2 ) then
		pb11.x = (1 * (display.contentWidth / 10))
		pb11.y = (-1 * (display.contentHeight / 30))
		pb10.x = (1 * (display.contentWidth / 10))
		pb10.y = (1 * (display.contentHeight / 30))
	end
	if( tbcol == 3 ) then
		pb11.x = (1 * (display.contentWidth / 10))
		pb11.y = 0
		pb10.x = (1 * (display.contentWidth / 10))
		pb10.y = (-1 * (display.contentHeight / 30))
		pb9.x = (1 * (display.contentWidth / 10))
		pb9.y = (1 * (display.contentHeight / 30))
	end
	if( tbcol == 4 ) then
		pb11.x = (1 * (display.contentWidth / 10))
		pb11.y = (-1 * (display.contentHeight / 30))
		pb10.x = (1 * (display.contentWidth / 10))
		pb10.y = (1 * (display.contentHeight / 30))
		
		pb9.x = (1 * (display.contentWidth / 10))
		pb9.y = (-1 * (display.contentHeight / 5))
		
		pb8.x = (1 * (display.contentWidth / 10))
		pb8.y = (1 * (display.contentHeight / 5))
	end
	if( tbcol == 5 ) then
		pb11.x = (1 * (display.contentWidth / 10))
		pb11.y = (-1 * (display.contentHeight / 30))
		pb10.x = (1 * (display.contentWidth / 10))
		pb10.y = (1 * (display.contentHeight / 30))
		
		pb9.x = (1 * (display.contentWidth / 10))
		pb9.y = (-1 * (display.contentHeight / 5))
		
		pb8.x = (1 * (display.contentWidth / 10))
		pb8.y = (1 * (display.contentHeight / 5))
		
		pb7.x = (1 * (display.contentWidth / 10))
		pb7.y = 0--(-1 * (display.contentWidth / 10))
	end
	
	pa1.oncontrol = "ns"
	pa2.oncontrol = "ns"
	pa3.oncontrol = "ns"
	pa4.oncontrol = "ns"
	pa5.oncontrol = "ns"
	pa6.oncontrol = "ns"
	pa7.oncontrol = "ns"
	pa8.oncontrol = "ns"
	pa9.oncontrol = "ns"
	pa10.oncontrol = "ns"
	pa11.oncontrol = "ns"
	
	pb1.oncontrol = "pc"
	pb2.oncontrol = "pc"
	pb3.oncontrol = "pc"
	pb4.oncontrol = "pc"
	pb5.oncontrol = "pc"
	pb6.oncontrol = "pc"
	pb7.oncontrol = "pc"
	pb8.oncontrol = "pc"
	pb9.oncontrol = "pc"
	pb10.oncontrol = "pc"
	pb11.oncontrol = "pc"
	
	
	
	
	showactifplayerme()
	
	
end
local function decidefortab()
	if common.start_time == 0 then
		common.start_time = os.time()
	end
	common.end_time = os.time()
	elapsed_time = (common.end_time - common.start_time)
	common.start_time = os.time()
	--print("***elapsed_time = " .. elapsed_time)
	--common.swiplog[table.getn(common.swiplog)] = common.jsk
	--common.gamestart = false
--common.swiplog = {} --common.swiplog[table.getn(common.swiplog)] = xxx
--common.handlelasttap = false
--common.myplayers = {}
--common.ballparent = ""
	--common.jsk = "0" "up""upright" "downleft""down" "downright""left""right" "1""upleft"
if(common.helpfinished == true) then
	if (common.gamestart == false) then
		startdiegame()
		common.gamestart = true
	elseif (common.ballonme == false) then
		if common.conrolonme == false then
			common.jaok = 0
		 	----print("table.getn(common.swiplog) = " .. table.getn(common.swiplog))
			--if table.getn(common.swiplog) < 2 then
				if( elapsed_time < 2) then
					
					changemyplayer()
					for k,v in pairs(common.swiplog) do common.swiplog[k]=nil end
					----print("clear tabs--------")
				end
			--end
		end
	elseif true then
		--print("***Ja ok....")
		common.jaok = common.jaok + 1
	end
	--common.myplayactif
	--common.myplayers[table.getn(common.myplayers)]
end

	--for k,v in pairs(common.swiplog) do common.swiplog[k]=nil end
end
--[[
local function getplayerstatGOLERA( dp )
-- "normal","getup","getright","getleft",
local ret = "auto"
local myx = dp.x
local myy = dp.y
local balx = player.x
local baly = player.y
if (myx < balx) then
	if (myy < baly) then
		ret = "standrightdown"
	end
	if (myy == baly) then
		ret = "standright"
	end
	if (myy > baly) then
		ret = "standupright"
	end
end
if (myx == balx) then
	if (myy < baly) then
		ret = "standdown"
	end
	if (myy == baly) then
		--ret = "standright"
	end
	if (myy > baly) then
		ret = "standup"
	end
end
if (myx > balx) then
	if (myy < baly) then
		ret = "standdownleft"
	end
	if (myy == baly) then
		ret = "standleft"
	end
	if (myy > baly) then
		ret = "standupleft"
	end
end

return ret
end
local function getplayerstatGOLERB( dp )

end
--]]
local function getplayerstat( dp )

--[[
	pa11.oncontrol = "ns"
	pb1.oncontrol = "pc"
	character
actif
runup
runupright
runright
rundownright
rundown
rundowleft
runleft
runupleft
standup
standupright
standright
standrightdown
standdown
standdownleft
standleft
standupleft
runupActif
runuprightActif
runrightActif
rundownrightActif
rundownActif
rundowleftActif
runleftActif
runupleftActif
standupActif
standuprightActif
standrightActif
standrightdownActif
standdownActif
standdownleftActif
standleftActif
standupleftActif
--]]
local ret = "auto"
local myx = dp.x
local myy = dp.y
local balx = player.x
local baly = player.y
if (myx < balx) then
	if (myy < baly) then
		ret = "standrightdown"
	end
	if (myy == baly) then
		ret = "standright"
	end
	if (myy > baly) then
		ret = "standupright"
	end
end
if (myx == balx) then
	if (myy < baly) then
		ret = "standdown"
	end
	if (myy == baly) then
		--ret = "standright"
	end
	if (myy > baly) then
		ret = "standup"
	end
end
if (myx > balx) then
	if (myy < baly) then
		ret = "standdownleft"
	end
	if (myy == baly) then
		ret = "standleft"
	end
	if (myy > baly) then
		ret = "standupleft"
	end
end

return ret

end

local function checkplayersface( )
	if(common.starttest == false) then
		common.starttest = true
		pa11:setSequence("runup")
		pa11:play()
	elseif true then
		if (( pa11.oncontrol == "ns" ) or ( pa11.oncontrol == "pc" )) then
			local custat = getplayerstat( pa11 )
			if (custat ~= "auto") then
				if ( paprevstat[11] ~= custat ) then
					paprevstat[11] = custat
					pa11:setSequence(custat)
					pa11:play()	
				end
			end
		end
	end
	if (( pa10.oncontrol == "ns" ) or ( pa10.oncontrol == "pc" )) then
		local custat = getplayerstat( pa10 )
		if (custat ~= "auto") then
			if ( paprevstat[10] ~= custat ) then
				paprevstat[10] = custat
				pa10:setSequence(custat)
				pa10:play()	
			end
		end
	end
	if (( pa9.oncontrol == "ns" ) or ( pa9.oncontrol == "pc" )) then
		local custat = getplayerstat( pa9 )
		if (custat ~= "auto") then
			if ( paprevstat[9] ~= custat ) then
				paprevstat[9] = custat
				pa9:setSequence(custat)
				pa9:play()	
			end
		end
	end
	if (( pa8.oncontrol == "ns" ) or ( pa8.oncontrol == "pc" )) then
		local custat = getplayerstat( pa8 )
		if (custat ~= "auto") then
			if ( paprevstat[8] ~= custat ) then
				paprevstat[8] = custat
				pa8:setSequence(custat)
				pa8:play()	
			end
		end
	end
	if (( pa7.oncontrol == "ns" ) or ( pa7.oncontrol == "pc" )) then
		local custat = getplayerstat( pa7 )
		if (custat ~= "auto") then
			if ( paprevstat[7] ~= custat ) then
				paprevstat[7] = custat
				pa7:setSequence(custat)
				pa7:play()	
			end
		end
	end
	if (( pa6.oncontrol == "ns" ) or ( pa6.oncontrol == "pc" )) then
		local custat = getplayerstat( pa6 )
		if (custat ~= "auto") then
			if ( paprevstat[6] ~= custat ) then
				paprevstat[6] = custat
				pa6:setSequence(custat)
				pa6:play()	
			end
		end
	end
	if (( pa5.oncontrol == "ns" ) or ( pa5.oncontrol == "pc" )) then
		local custat = getplayerstat( pa5 )
		if (custat ~= "auto") then
			if ( paprevstat[5] ~= custat ) then
				paprevstat[5] = custat
				pa5:setSequence(custat)
				pa5:play()	
			end
		end
	end
	if (( pa4.oncontrol == "ns" ) or ( pa4.oncontrol == "pc" )) then
		local custat = getplayerstat( pa4 )
		if (custat ~= "auto") then
			if ( paprevstat[4] ~= custat ) then
				paprevstat[4] = custat
				pa4:setSequence(custat)
				pa4:play()	
			end
		end
	end
	if (( pa3.oncontrol == "ns" ) or ( pa3.oncontrol == "pc" )) then
		local custat = getplayerstat( pa3 )
		if (custat ~= "auto") then
			if ( paprevstat[3] ~= custat ) then
				paprevstat[3] = custat
				pa3:setSequence(custat)
				pa3:play()	
			end
		end
	end
	if (( pa2.oncontrol == "ns" ) or ( pa2.oncontrol == "pc" )) then
		local custat = getplayerstat( pa2 )
		if (custat ~= "auto") then
			if ( paprevstat[2] ~= custat ) then
				paprevstat[2] = custat
				pa2:setSequence(custat)
				pa2:play()	
			end
		end
	end
	if (( pa1.oncontrol == "ns" ) or ( pa1.oncontrol == "pc" )) then
		local custat = "normal"--getplayerstatGOLERA( pa1 )
		if (custat ~= "auto") then
			if ( paprevstat[1] ~= custat ) then
				paprevstat[1] = custat
				pa1:setSequence(custat)
				pa1:play()	
			end
		end
	end
	
			if (( pb11.oncontrol == "ns" ) or ( pb11.oncontrol == "pc" )) then
		local custat = getplayerstat( pb11 )
		if (custat ~= "auto") then
			if ( pbprevstat[11] ~= custat ) then
				pbprevstat[11] = custat
				pb11:setSequence(custat)
				pb11:play()	
			end
		end
	end
	if (( pb10.oncontrol == "ns" ) or ( pb10.oncontrol == "pc" )) then
		local custat = getplayerstat( pb10 )
		if (custat ~= "auto") then
			if ( pbprevstat[10] ~= custat ) then
				pbprevstat[10] = custat
				pb10:setSequence(custat)
				pb10:play()	
			end
		end
	end
	if (( pb9.oncontrol == "ns" ) or ( pb9.oncontrol == "pc" )) then
		local custat = getplayerstat( pb9 )
		if (custat ~= "auto") then
			if ( pbprevstat[9] ~= custat ) then
				pbprevstat[9] = custat
				pb9:setSequence(custat)
				pb9:play()	
			end
		end
	end
	if (( pb8.oncontrol == "ns" ) or ( pb8.oncontrol == "pc" )) then
		local custat = getplayerstat( pb8 )
		if (custat ~= "auto") then
			if ( pbprevstat[8] ~= custat ) then
				pbprevstat[8] = custat
				pb8:setSequence(custat)
				pb8:play()	
			end
		end
	end
	if (( pb7.oncontrol == "ns" ) or ( pb7.oncontrol == "pc" )) then
		local custat = getplayerstat( pb7 )
		if (custat ~= "auto") then
			if ( pbprevstat[7] ~= custat ) then
				pbprevstat[7] = custat
				pb7:setSequence(custat)
				pb7:play()	
			end
		end
	end
	if (( pb6.oncontrol == "ns" ) or ( pb6.oncontrol == "pc" )) then
		local custat = getplayerstat( pb6 )
		if (custat ~= "auto") then
			if ( pbprevstat[6] ~= custat ) then
				pbprevstat[6] = custat
				pb6:setSequence(custat)
				pb6:play()	
			end
		end
	end
	if (( pb5.oncontrol == "ns" ) or ( pb5.oncontrol == "pc" )) then
		local custat = getplayerstat( pb5 )
		if (custat ~= "auto") then
			if ( pbprevstat[5] ~= custat ) then
				pbprevstat[5] = custat
				pb5:setSequence(custat)
				pb5:play()	
			end
		end
	end
	if (( pb4.oncontrol == "ns" ) or ( pb4.oncontrol == "pc" )) then
		local custat = getplayerstat( pb4 )
		if (custat ~= "auto") then
			if ( pbprevstat[4] ~= custat ) then
				pbprevstat[4] = custat
				pb4:setSequence(custat)
				pb4:play()	
			end
		end
	end
	if (( pb3.oncontrol == "ns" ) or ( pb3.oncontrol == "pc" )) then
		local custat = getplayerstat( pb3 )
		if (custat ~= "auto") then
			if ( pbprevstat[3] ~= custat ) then
				pbprevstat[3] = custat
				pb3:setSequence(custat)
				pb3:play()	
			end
		end
	end
	if (( pb2.oncontrol == "ns" ) or ( pb2.oncontrol == "pc" )) then
		local custat = getplayerstat( pb2 )
		if (custat ~= "auto") then
			if ( pbprevstat[2] ~= custat ) then
				pbprevstat[2] = custat
				pb2:setSequence(custat)
				pb2:play()	
			end
		end
	end
	if (( pb1.oncontrol == "ns" ) or ( pb1.oncontrol == "pc" )) then
		local custat = "normal"--getplayerstatGOLERB( pb1 )
		if (custat ~= "auto") then
			if ( pbprevstat[1] ~= custat ) then
				pbprevstat[1] = custat
				pb1:setSequence(custat)
				pb1:play()	
			end
		end
	end
	------print(pbprevstat[11])
	
	aplisterect[1].x = pa1.x
	aplistetext[1].x = pa1.x
	aplisterect[1].y = pa1.y
	aplistetext[1].y = pa1.y
	
	aplisterect[2].x = pa2.x
	aplistetext[2].x = pa2.x
	aplisterect[2].y = pa2.y
	aplistetext[2].y = pa2.y
	
	aplisterect[3].x = pa3.x
	aplistetext[3].x = pa3.x
	aplisterect[3].y = pa3.y
	aplistetext[3].y = pa3.y
	
	aplisterect[4].x = pa4.x
	aplistetext[4].x = pa4.x
	aplisterect[4].y = pa4.y
	aplistetext[4].y = pa4.y
	
	aplisterect[5].x = pa5.x
	aplistetext[5].x = pa5.x
	aplisterect[5].y = pa5.y
	aplistetext[5].y = pa5.y
	
	aplisterect[6].x = pa6.x
	aplistetext[6].x = pa6.x
	aplisterect[6].y = pa6.y
	aplistetext[6].y = pa6.y
	
	aplisterect[7].x = pa7.x
	aplistetext[7].x = pa7.x
	aplisterect[7].y = pa7.y
	aplistetext[7].y = pa7.y
	
	aplisterect[8].x = pa8.x
	aplistetext[8].x = pa8.x
	aplisterect[8].y = pa8.y
	aplistetext[8].y = pa8.y
	
	aplisterect[9].x = pa9.x
	aplistetext[9].x = pa9.x
	aplisterect[9].y = pa9.y
	aplistetext[9].y = pa9.y
	
	aplisterect[10].x = pa10.x
	aplistetext[10].x = pa10.x
	aplisterect[10].y = pa10.y
	aplistetext[10].y = pa10.y
	
	aplisterect[11].x = pa11.x
	aplistetext[11].x = pa11.x
	aplisterect[11].y = pa11.y
	aplistetext[11].y = pa11.y
	
	bplisterect[1].x = pb1.x
	bplistetext[1].x = pb1.x
	bplisterect[1].y = pb1.y
	bplistetext[1].y = pb1.y
	
	bplisterect[2].x = pb2.x
	bplistetext[2].x = pb2.x
	bplisterect[2].y = pb2.y
	bplistetext[2].y = pb2.y
	
	bplisterect[3].x = pb3.x
	bplistetext[3].x = pb3.x
	bplisterect[3].y = pb3.y
	bplistetext[3].y = pb3.y
	
	bplisterect[4].x = pb4.x
	bplistetext[4].x = pb4.x
	bplisterect[4].y = pb4.y
	bplistetext[4].y = pb4.y
	
	bplisterect[5].x = pb5.x
	bplistetext[5].x = pb5.x
	bplisterect[5].y = pb5.y
	bplistetext[5].y = pb5.y
	
	bplisterect[6].x = pb6.x
	bplistetext[6].x = pb6.x
	bplisterect[6].y = pb6.y
	bplistetext[6].y = pb6.y
	
	bplisterect[7].x = pb7.x
	bplistetext[7].x = pb7.x
	bplisterect[7].y = pb7.y
	bplistetext[7].y = pb7.y
	
	bplisterect[8].x = pb8.x
	bplistetext[8].x = pb8.x
	bplisterect[8].y = pb8.y
	bplistetext[8].y = pb8.y
	
	bplisterect[9].x = pb9.x
	bplistetext[9].x = pb9.x
	bplisterect[9].y = pb9.y
	bplistetext[9].y = pb9.y
	
	bplisterect[10].x = pb10.x
	bplistetext[10].x = pb10.x
	bplisterect[10].y = pb10.y
	bplistetext[10].y = pb10.y
	
	bplisterect[11].x = pb11.x
	bplistetext[11].x = pb11.x
	bplisterect[11].y = pb11.y
	bplistetext[11].y = pb11.y
	
	--[[
	--test
	if(common.starttest == false) then
		common.starttest = true
		pa11:setSequence("runup")
		pa11:play()
	end
	--]]
	
end


local function getplayerstatActif( dp,x2 ,y2 )

--[[
	pa11.oncontrol = "ns"
	pb1.oncontrol = "pc"
	character
actif
runup
runupright
runright
rundownright
rundown
rundowleft
runleft
runupleft
standup
standupright
standright
standrightdown
standdown
standdownleft
standleft
standupleft
runupActif
runuprightActif
runrightActif
rundownrightActif
rundownActif
rundowleftActif
runleftActif
runupleftActif
standupActif
standuprightActif
standrightActif
standrightdownActif
standdownActif
standdownleftActif
standleftActif
standupleftActif
--]]
local ret = "auto"
local myx = dp.x
local myy = dp.y
local balx = x2--player.x
local baly = y2--player.y
if (myx < balx) then
	if (myy < baly) then
		ret = "runrightdown"
	end
	if (myy == baly) then
		ret = "runright"
	end
	if (myy > baly) then
		ret = "runupright"
	end
end
if (myx == balx) then
	if (myy < baly) then
		ret = "rundown"
	end
	if (myy == baly) then
		--ret = "standright"
	end
	if (myy > baly) then
		ret = "runup"
	end
end
if (myx > balx) then
	if (myy < baly) then
		ret = "rundownleft"
	end
	if (myy == baly) then
		ret = "runleft"
	end
	if (myy > baly) then
		ret = "runupleft"
	end
end

if (myx == balx) then
	if (myy == baly) then
		ret = "auto"
	end
end

return ret

end


local function moveactifplayer(dx, dy)
--[[
if(common.starttest == true) then
	--print("move actif true")
	do return end
end
--]]
------print("is nil = " .. (a11rect ~= nil))
	--if ((common.helpfinished == true) and (a11rect ~= nil)) then
	--aplisterect[11].x = pa1.x
	--aplistetext[11].x = pa1.x
	--aplisterect[1].y = pa1.y
	--aplistetext[1].y = pa1.y
	----print("****dx = " .. dx .. " - dy = " .. dy .. " - common.myplayactif = " .. common.myplayactif )
	dx = (dx / 10)
	dy = (dy / 10)
		if hasCollided(myRectangle, player) then
			
			if(common.myplayactif == "a11") then
				pa11:translate(dx, dy)
				aplisterect[11]:translate(dx, dy)
				aplistetext[11]:translate(dx, dy)
				pa11.oncontrol = "user"
				local custat = getplayerstatActif(pa11,pa11.x + dx,pa11.y + dy)
				--[[
				local custat = "runup"
					local custat = "runupright"
					local custat = "runright"
					local custat = "rundownright"
					local custat = "rundown"
					local custat = "rundowleft"
					local custat = "runleft"
					local custat = "runupleft"
					local custat = "standup"
					local custat = "standupright"
					local custat = "standright"
					local custat = "standrightdown"
					local custat = "standdown"
					local custat = "standdownleft"
					local custat = "standleft"
					local custat = "standupleft"
					
					local custat = "taklup"
					local custat = "taklupright"
					local custat = "taklright"
					local custat = "taklrightdown"
					local custat = "takldown"
					local custat = "takldownleft"
					local custat = "taklleft"
					local custat = "taklleftup"
					local custat = "fallup"
					local custat = "fallupright"
					local custat = "fallright"
					local custat = "fallrightdown"
					local custat = "falldown"
					local custat = "falldownleft"
					local custat = "fallleft"
					local custat = "fallupleft"
					
					local custat = "runupActif"
					local custat = "runuprightActif"
					local custat = "runrightActif"
					local custat = "rundownrightActif"
					local custat = "rundownActif"
					local custat = "rundowleftActif"
					local custat = "runleftActif"
					local custat = "runupleftActif"
					local custat = "standupActif"
					local custat = "standuprightActif"
					local custat = "standrightActif"
					local custat = "standrightdownActif"
					local custat = "standdownActif"
					local custat = "standdownleftActif"
					local custat = "standleftActif"
					local custat = "standupleftActif"
					local custat = "fallupActif"
					local custat = "taklupActif"
					local custat = "takluprightActif"
					local custat = "taklrightActif"
					local custat = "taklrightdownActif"
					local custat = "takldownActif"
					local custat = "takldownleftActif"
					local custat = "taklleftActif"
					local custat = "taklleftupActif"
					local custat = "fallupActif"
					local custat = "falluprightActif"
					local custat = "fallrightActif"
					local custat = "fallrightdownActif"
					local custat = "falldownActif"
					local custat = "falldownleftActif"
					local custat = "fallleftActif"
					local custat = "fallupleftActif"
					--]]
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[11] ~= custat ) then
						paprevstat[11] = custat
						pa11:setSequence(custat)
						pa11:play()	
					end
				elseif true then
					custat = getplayerstat(pa11)
					if ( paprevstat[11] ~= custat ) then
						paprevstat[11] = custat
						pa11:setSequence(custat)
						pa11:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a10") then
				pa10:translate(dx, dy)
				aplisterect[10]:translate(dx, dy)
				aplistetext[10]:translate(dx, dy)
				pa10.oncontrol = "user"
				local custat = getplayerstatActif(pa10,pa10.x + dx,pa10.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[10] ~= custat ) then
						paprevstat[10] = custat
						pa10:setSequence(custat)
						pa10:play()	
					end
				elseif true then
					custat = getplayerstat(pa10)
					if ( paprevstat[10] ~= custat ) then
						paprevstat[10] = custat
						pa10:setSequence(custat)
						pa10:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a9") then
				pa9:translate(dx, dy)
				aplisterect[9]:translate(dx, dy)
				aplistetext[9]:translate(dx, dy)
				pa9.oncontrol = "user"
				local custat = getplayerstatActif(pa9,pa9.x + dx,pa9.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[9] ~= custat ) then
						paprevstat[9] = custat
						pa9:setSequence(custat)
						pa9:play()	
					end
				elseif true then
					custat = getplayerstat(pa9)
					if ( paprevstat[9] ~= custat ) then
						paprevstat[9] = custat
						pa9:setSequence(custat)
						pa9:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a8") then
				pa8:translate(dx, dy)
				aplisterect[8]:translate(dx, dy)
				aplistetext[8]:translate(dx, dy)
				pa8.oncontrol = "user"
				local custat = getplayerstatActif(pa8,pa8.x + dx,pa8.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[8] ~= custat ) then
						paprevstat[8] = custat
						pa8:setSequence(custat)
						pa8:play()	
					end
				elseif true then
					custat = getplayerstat(pa8)
					if ( paprevstat[8] ~= custat ) then
						paprevstat[8] = custat
						pa8:setSequence(custat)
						pa8:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a7") then
				pa7:translate(dx, dy)
				aplisterect[7]:translate(dx, dy)
				aplistetext[7]:translate(dx, dy)
				pa7.oncontrol = "user"
				local custat = getplayerstatActif(pa7,pa7.x + dx,pa7.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[7] ~= custat ) then
						paprevstat[7] = custat
						pa7:setSequence(custat)
						pa7:play()	
					end
				elseif true then
					custat = getplayerstat(pa7)
					if ( paprevstat[7] ~= custat ) then
						paprevstat[7] = custat
						pa7:setSequence(custat)
						pa7:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a6") then
				pa6:translate(dx, dy)
				aplisterect[6]:translate(dx, dy)
				aplistetext[6]:translate(dx, dy)
				pa6.oncontrol = "user"
				local custat = getplayerstatActif(pa6,pa6.x + dx,pa6.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[6] ~= custat ) then
						paprevstat[6] = custat
						pa6:setSequence(custat)
						pa6:play()	
					end
				elseif true then
					custat = getplayerstat(pa6)
					if ( paprevstat[6] ~= custat ) then
						paprevstat[6] = custat
						pa6:setSequence(custat)
						pa6:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a5") then
				pa5:translate(dx, dy)
				aplisterect[5]:translate(dx, dy)
				aplistetext[5]:translate(dx, dy)
				pa5.oncontrol = "user"
				local custat = getplayerstatActif(pa5,pa5.x + dx,pa5.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[5] ~= custat ) then
						paprevstat[5] = custat
						pa5:setSequence(custat)
						pa5:play()	
					end
				elseif true then
					custat = getplayerstat(pa5)
					if ( paprevstat[5] ~= custat ) then
						paprevstat[5] = custat
						pa5:setSequence(custat)
						pa5:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a4") then
				pa4:translate(dx, dy)
				aplisterect[4]:translate(dx, dy)
				aplistetext[4]:translate(dx, dy)
				pa4.oncontrol = "user"
				local custat = getplayerstatActif(pa4,pa4.x + dx,pa4.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[4] ~= custat ) then
						paprevstat[4] = custat
						pa4:setSequence(custat)
						pa4:play()	
					end
				elseif true then
					custat = getplayerstat(pa4)
					if ( paprevstat[4] ~= custat ) then
						paprevstat[4] = custat
						pa4:setSequence(custat)
						pa4:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a3") then
				pa3:translate(dx, dy)
				aplisterect[3]:translate(dx, dy)
				aplistetext[3]:translate(dx, dy)
				pa3.oncontrol = "user"
				local custat = getplayerstatActif(pa3,pa3.x + dx,pa3.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[3] ~= custat ) then
						paprevstat[3] = custat
						pa3:setSequence(custat)
						pa3:play()	
					end
				elseif true then
					custat = getplayerstat(pa3)
					if ( paprevstat[3] ~= custat ) then
						paprevstat[3] = custat
						pa3:setSequence(custat)
						pa3:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "a2") then
				pa2:translate(dx, dy)
				aplisterect[2]:translate(dx, dy)
				aplistetext[2]:translate(dx, dy)
				pa2.oncontrol = "user"
				local custat = getplayerstatActif(pa2,pa2.x + dx,pa2.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[2] ~= custat ) then
						paprevstat[2] = custat
						pa2:setSequence(custat)
						pa2:play()	
					end
				elseif true then
					custat = getplayerstat(pa2)
					if ( paprevstat[2] ~= custat ) then
						paprevstat[2] = custat
						pa2:setSequence(custat)
						pa2:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
		--[[	if(common.myplayactif == "a1") then
				pa1:translate(dx, dy)
				aplisterect[1]:translate(dx, dy)
				aplistetext[1]:translate(dx, dy)
				pa1.oncontrol = "user"
				local custat = getplayerstatActif(pa1,pa1.x + dx,pa1.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( paprevstat[1] ~= custat ) then
						paprevstat[1] = custat
						pa1:setSequence(custat)
						pa1:play()	
					end
				elseif true then
					custat = getplayerstat(pa1)
					if ( paprevstat[1] ~= custat ) then
						paprevstat[1] = custat
						pa1:setSequence(custat)
						pa1:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			--]]
				if(common.myplayactif == "b11") then
				pb11:translate(dx, dy)
				bplisterect[11]:translate(dx, dy)
				bplistetext[11]:translate(dx, dy)
				pb11.oncontrol = "user"
				local custat = getplayerstatActif(pb11,pb11.x + dx,pb11.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[11] ~= custat ) then
						pbprevstat[11] = custat
						pb11:setSequence(custat)
						pb11:play()	
					end
				elseif true then
					custat = getplayerstat(pb11)
					if ( pbprevstat[11] ~= custat ) then
						pbprevstat[11] = custat
						pb11:setSequence(custat)
						pb11:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b10") then
				pb10:translate(dx, dy)
				bplisterect[10]:translate(dx, dy)
				bplistetext[10]:translate(dx, dy)
				pb10.oncontrol = "user"
				local custat = getplayerstatActif(pb10,pb10.x + dx,pb10.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[10] ~= custat ) then
						pbprevstat[10] = custat
						pb10:setSequence(custat)
						pb10:play()	
					end
				elseif true then
					custat = getplayerstat(pb10)
					if ( pbprevstat[10] ~= custat ) then
						pbprevstat[10] = custat
						pb10:setSequence(custat)
						pb10:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b9") then
				pb9:translate(dx, dy)
				bplisterect[9]:translate(dx, dy)
				bplistetext[9]:translate(dx, dy)
				pb9.oncontrol = "user"
				local custat = getplayerstatActif(pb9,pb9.x + dx,pb9.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[9] ~= custat ) then
						pbprevstat[9] = custat
						pb9:setSequence(custat)
						pb9:play()	
					end
				elseif true then
					custat = getplayerstat(pb9)
					if ( pbprevstat[9] ~= custat ) then
						pbprevstat[9] = custat
						pb9:setSequence(custat)
						pb9:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b8") then
				pb8:translate(dx, dy)
				bplisterect[8]:translate(dx, dy)
				bplistetext[8]:translate(dx, dy)
				pb8.oncontrol = "user"
				local custat = getplayerstatActif(pb8,pb8.x + dx,pb8.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[8] ~= custat ) then
						pbprevstat[8] = custat
						pb8:setSequence(custat)
						pb8:play()	
					end
				elseif true then
					custat = getplayerstat(pb8)
					if ( pbprevstat[8] ~= custat ) then
						pbprevstat[8] = custat
						pb8:setSequence(custat)
						pb8:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b7") then
				pb7:translate(dx, dy)
				bplisterect[7]:translate(dx, dy)
				bplistetext[7]:translate(dx, dy)
				pb7.oncontrol = "user"
				local custat = getplayerstatActif(pb7,pb7.x + dx,pb7.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[7] ~= custat ) then
						pbprevstat[7] = custat
						pb7:setSequence(custat)
						pb7:play()	
					end
				elseif true then
					custat = getplayerstat(pb7)
					if ( pbprevstat[7] ~= custat ) then
						pbprevstat[7] = custat
						pb7:setSequence(custat)
						pb7:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b6") then
				pb6:translate(dx, dy)
				bplisterect[6]:translate(dx, dy)
				bplistetext[6]:translate(dx, dy)
				pb6.oncontrol = "user"
				local custat = getplayerstatActif(pb6,pb6.x + dx,pb6.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[6] ~= custat ) then
						pbprevstat[6] = custat
						pb6:setSequence(custat)
						pb6:play()	
					end
				elseif true then
					custat = getplayerstat(pb6)
					if ( pbprevstat[6] ~= custat ) then
						pbprevstat[6] = custat
						pb6:setSequence(custat)
						pb6:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b5") then
				pb5:translate(dx, dy)
				bplisterect[5]:translate(dx, dy)
				bplistetext[5]:translate(dx, dy)
				pb5.oncontrol = "user"
				local custat = getplayerstatActif(pb5,pb5.x + dx,pb5.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[5] ~= custat ) then
						pbprevstat[5] = custat
						pb5:setSequence(custat)
						pb5:play()	
					end
				elseif true then
					custat = getplayerstat(pb5)
					if ( pbprevstat[5] ~= custat ) then
						pbprevstat[5] = custat
						pb5:setSequence(custat)
						pb5:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b4") then
				pb4:translate(dx, dy)
				bplisterect[4]:translate(dx, dy)
				bplistetext[4]:translate(dx, dy)
				pb4.oncontrol = "user"
				local custat = getplayerstatActif(pb4,pb4.x + dx,pb4.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[4] ~= custat ) then
						pbprevstat[4] = custat
						pb4:setSequence(custat)
						pb4:play()	
					end
				elseif true then
					custat = getplayerstat(pb4)
					if ( pbprevstat[4] ~= custat ) then
						pbprevstat[4] = custat
						pb4:setSequence(custat)
						pb4:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b3") then
				pb3:translate(dx, dy)
				bplisterect[3]:translate(dx, dy)
				bplistetext[3]:translate(dx, dy)
				pb3.oncontrol = "user"
				local custat = getplayerstatActif(pb3,pb3.x + dx,pb3.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[3] ~= custat ) then
						pbprevstat[3] = custat
						pb3:setSequence(custat)
						pb3:play()	
					end
				elseif true then
					custat = getplayerstat(pb3)
					if ( pbprevstat[3] ~= custat ) then
						pbprevstat[3] = custat
						pb3:setSequence(custat)
						pb3:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			
			if(common.myplayactif == "b2") then
				pb2:translate(dx, dy)
				bplisterect[2]:translate(dx, dy)
				bplistetext[2]:translate(dx, dy)
				pb2.oncontrol = "user"
				local custat = getplayerstatActif(pb2,pb2.x + dx,pb2.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[2] ~= custat ) then
						pbprevstat[2] = custat
						pb2:setSequence(custat)
						pb2:play()	
					end
				elseif true then
					custat = getplayerstat(pb2)
					if ( pbprevstat[2] ~= custat ) then
						pbprevstat[2] = custat
						pb2:setSequence(custat)
						pb2:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			--[[
			if(common.myplayactif == "b1") then
				pb1:translate(dx, dy)
				bplisterect[1]:translate(dx, dy)
				bplistetext[1]:translate(dx, dy)
				pb1.oncontrol = "user"
				local custat = getplayerstatActif(pb1,pb1.x + dx,pb1.y + dy)
				if (custat ~= "auto") then
					--common.inautomod = 0
					common.conrolonme = true
					if ( pbprevstat[1] ~= custat ) then
						pbprevstat[1] = custat
						pb1:setSequence(custat)
						pb1:play()	
					end
				elseif true then
					custat = getplayerstat(pb1)
					if ( pbprevstat[1] ~= custat ) then
						pbprevstat[1] = custat
						pb1:setSequence(custat)
						pb1:play()	
					elseif true then
						common.inautomod = common.inautomod + 1
						if (common.inautomod >= 3 ) then
							common.conrolonme = false	
							common.inautomod = 0
						end
					end
				end
			end
			--]]
		else
		end
	--end
end

local function enterFrame(event)
	if m.result == "rotate:left" then
		player.angularVelocity = player.angularVelocity * player.angularAcceleration
		player.angularVelocity = math.max(player.angularVelocity, -player.angularMax)
		player.moveSpeed = player.moveSpeed * player.linearDamping
	elseif m.result == "rotate:right" then
		player.angularVelocity = player.angularVelocity * player.angularAcceleration
		player.angularVelocity = math.min(player.angularVelocity, player.angularMax)
		player.moveSpeed = player.moveSpeed * player.linearDamping
	elseif m.result == "move" then
		
		player.moveSpeed = player.moveSpeed * player.linearAcceleration
			player.moveSpeed = math.min(player.moveSpeed, player.linearMax)
			player.angularVelocity = player.angularVelocity * player.angularDamping
		
	--	if hasCollided(myRectangle, player) then
--	----print("************ COLLIII = " .. "true")
--else
	--player.moveSpeed = 0
--end

		
		if ((display.contentWidth) + player.x)  > 4275 then 
			--player.moveSpeed = 0--player.moveSpeed * player.linearAcceleration
			player.angularVelocity = player.angularVelocity * player.angularDamping
		--player.x = 4275 - display.contentWidth--player.x - (4275 - (display.contentWidth + player.x))
		elseif  (player.x < (-1 * (4275 - (display.contentWidth / 2))))  then 
			--player.moveSpeed = 0--player.moveSpeed * player.linearAcceleration
			player.angularVelocity = player.angularVelocity * player.angularDamping
		--player.x = (-1 * (4275 - display.contentWidth))-- - 300
		--player.x = (-1 * (4275 - (display.contentWidth / 2)))
		elseif (display.contentHeight + player.y)  > 5700 then 
		--	player.moveSpeed = 0--player.moveSpeed * player.linearAcceleration
			player.angularVelocity = player.angularVelocity * player.angularDamping
	--	player.y = 5700 - (display.contentHeight)
		elseif  (player.y < (-1 * (5700 - (display.contentHeight))))  then
			--player.moveSpeed = 0--player.moveSpeed * player.linearAcceleration
			player.angularVelocity = player.angularVelocity * player.angularDamping
		--	player.y = (-1 * (5700 - (display.contentHeight)))
		end

		--myRectangle
		------print("player..y = " .. player.y .. " - myRectangle.y = " .. myRectangle.y .. " - display.contentHeight: " .. display.contentHeight)
		------print("player..y = " .. player.y)
		
	elseif m.result == "none" then
		player.angularVelocity = player.angularVelocity * player.angularDamping
		player.moveSpeed = player.moveSpeed * player.linearDamping
	end

	--local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
	--player:translate(forces.x, forces.y)
	
	--player:rotate(player.angularVelocity)
	
	
	
	
	if	common.jsk == "0" then
		fcx =0 
		fcy = 0
	end

	if	common.jsk == "up" then
		--fcx =0 
		fcy = fcy - fcs
	end
	if	common.jsk == "upright" then
		fcx = fcx + fcs 
		fcy = fcy - fcs
	end
	if	common.jsk == "downleft" then
		fcx = fcx - fcs 
		fcy = fcy + fcs
	end
	if	common.jsk == "down" then
		fcy = fcy + fcs
	end
	if	common.jsk == "downright" then
		fcx = fcx + fcs
		fcy = fcy + fcs
	end
	if	common.jsk == "left" then
		fcx = fcx - fcs
	end
	if	common.jsk == "right" then
		fcx = fcx + fcs
	end
	
	if	common.jsk == "upleft" then
		fcy = fcy - fcs
		fcx = fcx - fcs
	end
	
	if	common.jsk == "1" then
			fcx =0 
			fcy = 0
	end
	--[[
	if hasCollided(myRectangle, player) then
	------print("************ COLLIII = " .. "true")
	player:translate(fcx, fcy)
else
	------print("************ COLLIII = " .. "false")	
	--player.moveSpeed = 0
	--player:translate(fcx, fcy)
end
--]]



	------print("---- fcx: " .. fcx .. " , fcy: " .. fcy .. " - common.jsk: " .. common.jsk)
	--player:translate(fcx, fcy)
	
	common.jsk = "0"
	
	if (common.cameradozoom == "in") then
		if( common.cameraprevzoom == "in" ) then
			common.cameracontzoom = common.cameracontzoom + 1
		elseif true then
			common.cameracontzoom = 1
		end
		common.cameraprevzoom = "in"
		common.cameradozoom = ""
		if(common.cameracontzoom < 3) then
			common.cameraScaleX = 4--common.cameraScaleX + 1
			camera:scale(common.cameraScaleX, common.cameraScaleX)
		end
		
	end
	if (common.cameradozoom == "out") then
		if( common.cameraprevzoom == "out" ) then
			common.cameracontzoom = common.cameracontzoom + 1
		elseif true then
			common.cameracontzoom = 1
		end
		common.cameraprevzoom = "out"
		common.cameradozoom = ""
		if(common.cameracontzoom < 3) then
			common.cameraScaleX = 0.3--common.cameraScaleX + 1
			camera:scale(common.cameraScaleX, common.cameraScaleX)
		end
		
	end

--common.gamestart = false
--common.swiplog = {} --common.swiplog[table.getn(common.swiplog)] = xxx
if common.handlelasttap == true then
	decidefortab()
	common.handlelasttap = false
end

checkplayersface ( )
moveactifplayer(fcx, fcy)

common.swiplog[table.getn(common.swiplog) + 1] = common.jsk

------------- get ball test -------

local dbalx = player.x
local dbaly = player.y
----print("--- dbalx = " .. dbalx .. " , dbaly = " .. dbaly)
local xdif = 0
local ydif = 0

local tx = 0
local ty = 0

tx = math.ceil(math.abs(pa11.x - dbalx))
ty = math.ceil(math.abs(pa11.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a11"
end
tx = math.ceil(math.abs(pa10.x - dbalx))
ty = math.ceil(math.abs(pa10.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a10"
end
tx = math.ceil(math.abs(pa9.x - dbalx))
ty = math.ceil(math.abs(pa9.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a9"
end
tx = math.ceil(math.abs(pa8.x - dbalx))
ty = math.ceil(math.abs(pa8.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a8"
end
tx = math.ceil(math.abs(pa7.x - dbalx))
ty = math.ceil(math.abs(pa7.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a7"
end
tx = math.ceil(math.abs(pa6.x - dbalx))
ty = math.ceil(math.abs(pa6.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a6"
end
tx = math.ceil(math.abs(pa5.x - dbalx))
ty = math.ceil(math.abs(pa5.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a5"
end
tx = math.ceil(math.abs(pa4.x - dbalx))
ty = math.ceil(math.abs(pa4.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a4"
end
tx = math.ceil(math.abs(pa3.x - dbalx))
ty = math.ceil(math.abs(pa3.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a3"
end
tx = math.ceil(math.abs(pa2.x - dbalx))
ty = math.ceil(math.abs(pa2.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a2"
end
tx = math.ceil(math.abs(pa1.x - dbalx))
ty = math.ceil(math.abs(pa1.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballparent = "a1"
end

tx = math.ceil(math.abs(pb11.x - dbalx))
ty = math.ceil(math.abs(pb11.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b11"
end
tx = math.ceil(math.abs(pb10.x - dbalx))
ty = math.ceil(math.abs(pb10.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b10"
end
tx = math.ceil(math.abs(pb9.x - dbalx))
ty = math.ceil(math.abs(pb9.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b9"
end
tx = math.ceil(math.abs(pb8.x - dbalx))
ty = math.ceil(math.abs(pb8.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b8"
end
tx = math.ceil(math.abs(pb7.x - dbalx))
ty = math.ceil(math.abs(pb7.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b7"
end
tx = math.ceil(math.abs(pb6.x - dbalx))
ty = math.ceil(math.abs(pb6.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b6"
end
tx = math.ceil(math.abs(pb5.x - dbalx))
ty = math.ceil(math.abs(pb5.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b5"
end
tx = math.ceil(math.abs(pb4.x - dbalx))
ty = math.ceil(math.abs(pb4.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b4"
end
tx = math.ceil(math.abs(pb3.x - dbalx))
ty = math.ceil(math.abs(pb3.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b3"
end
tx = math.ceil(math.abs(pb2.x - dbalx))
ty = math.ceil(math.abs(pb2.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b2"
end
tx = math.ceil(math.abs(pb1.x - dbalx))
ty = math.ceil(math.abs(pb1.y - dbaly))
if((30 >= tx) and (30 >= ty)) then
	common.ballpbrent = "b1"
end


--print("common.ballparent = " .. common.ballparent)
if (common.ballparent == common.myplayactif) then
	common.ballonme = true
	

	player:toFront()
	common.latestswip = common.jsk

elseif true then
	common.ballonme = false
end
	
	if(common.ballparent == "a11") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa11.x - 10
			player.y = pa11.y +10
		end
		if(common.jsk == "1") then
			player.x = pa11.x - 10
			player.y = pa11.y +10
		end
		if(common.jsk == "up") then
			player.x = pa11.x --- 10
			player.y = pa11.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa11.x + 20
			player.y = pa11.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa11.x - 20
			player.y = pa11.y +20
		end
		if(common.jsk == "down") then
			player.x = pa11.x-- - 10
			player.y = pa11.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa11.x + 20
			player.y = pa11.y +20
		end
		if(common.jsk == "left") then
			player.x = pa11.x - 20
			player.y = pa11.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa11.x + 30
			player.y = pa11.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa11.x - 20
			player.y = pa11.y -20
		end 
	end
	
	if(common.ballparent == "a10") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa10.x - 10
			player.y = pa10.y +10
		end
		if(common.jsk == "1") then
			player.x = pa10.x - 10
			player.y = pa10.y +10
		end
		if(common.jsk == "up") then
			player.x = pa10.x --- 10
			player.y = pa10.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa10.x + 20
			player.y = pa10.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa10.x - 20
			player.y = pa10.y +20
		end
		if(common.jsk == "down") then
			player.x = pa10.x-- - 10
			player.y = pa10.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa10.x + 20
			player.y = pa10.y +20
		end
		if(common.jsk == "left") then
			player.x = pa10.x - 20
			player.y = pa10.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa10.x + 30
			player.y = pa10.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa10.x - 20
			player.y = pa10.y -20
		end 
	end
	
	if(common.ballparent == "a9") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa9.x - 10
			player.y = pa9.y +10
		end
		if(common.jsk == "1") then
			player.x = pa9.x - 10
			player.y = pa9.y +10
		end
		if(common.jsk == "up") then
			player.x = pa9.x --- 10
			player.y = pa9.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa9.x + 20
			player.y = pa9.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa9.x - 20
			player.y = pa9.y +20
		end
		if(common.jsk == "down") then
			player.x = pa9.x-- - 10
			player.y = pa9.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa9.x + 20
			player.y = pa9.y +20
		end
		if(common.jsk == "left") then
			player.x = pa9.x - 20
			player.y = pa9.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa9.x + 30
			player.y = pa9.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa9.x - 20
			player.y = pa9.y -20
		end 
	end
	
	if(common.ballparent == "a8") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa8.x - 10
			player.y = pa8.y +10
		end
		if(common.jsk == "1") then
			player.x = pa8.x - 10
			player.y = pa8.y +10
		end
		if(common.jsk == "up") then
			player.x = pa8.x --- 10
			player.y = pa8.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa8.x + 20
			player.y = pa8.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa8.x - 20
			player.y = pa8.y +20
		end
		if(common.jsk == "down") then
			player.x = pa8.x-- - 10
			player.y = pa8.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa8.x + 20
			player.y = pa8.y +20
		end
		if(common.jsk == "left") then
			player.x = pa8.x - 20
			player.y = pa8.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa8.x + 30
			player.y = pa8.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa8.x - 20
			player.y = pa8.y -20
		end 
	end
	
	if(common.ballparent == "a7") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa7.x - 10
			player.y = pa7.y +10
		end
		if(common.jsk == "1") then
			player.x = pa7.x - 10
			player.y = pa7.y +10
		end
		if(common.jsk == "up") then
			player.x = pa7.x --- 10
			player.y = pa7.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa7.x + 20
			player.y = pa7.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa7.x - 20
			player.y = pa7.y +20
		end
		if(common.jsk == "down") then
			player.x = pa7.x-- - 10
			player.y = pa7.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa7.x + 20
			player.y = pa7.y +20
		end
		if(common.jsk == "left") then
			player.x = pa7.x - 20
			player.y = pa7.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa7.x + 30
			player.y = pa7.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa7.x - 20
			player.y = pa7.y -20
		end 
	end
	
	if(common.ballparent == "a6") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa6.x - 10
			player.y = pa6.y +10
		end
		if(common.jsk == "1") then
			player.x = pa6.x - 10
			player.y = pa6.y +10
		end
		if(common.jsk == "up") then
			player.x = pa6.x --- 10
			player.y = pa6.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa6.x + 20
			player.y = pa6.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa6.x - 20
			player.y = pa6.y +20
		end
		if(common.jsk == "down") then
			player.x = pa6.x-- - 10
			player.y = pa6.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa6.x + 20
			player.y = pa6.y +20
		end
		if(common.jsk == "left") then
			player.x = pa6.x - 20
			player.y = pa6.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa6.x + 30
			player.y = pa6.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa6.x - 20
			player.y = pa6.y -20
		end 
	end
	
	if(common.ballparent == "a5") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa5.x - 10
			player.y = pa5.y +10
		end
		if(common.jsk == "1") then
			player.x = pa5.x - 10
			player.y = pa5.y +10
		end
		if(common.jsk == "up") then
			player.x = pa5.x --- 10
			player.y = pa5.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa5.x + 20
			player.y = pa5.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa5.x - 20
			player.y = pa5.y +20
		end
		if(common.jsk == "down") then
			player.x = pa5.x-- - 10
			player.y = pa5.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa5.x + 20
			player.y = pa5.y +20
		end
		if(common.jsk == "left") then
			player.x = pa5.x - 20
			player.y = pa5.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa5.x + 30
			player.y = pa5.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa5.x - 20
			player.y = pa5.y -20
		end 
	end
	
	if(common.ballparent == "a4") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa4.x - 10
			player.y = pa4.y +10
		end
		if(common.jsk == "1") then
			player.x = pa4.x - 10
			player.y = pa4.y +10
		end
		if(common.jsk == "up") then
			player.x = pa4.x --- 10
			player.y = pa4.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa4.x + 20
			player.y = pa4.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa4.x - 20
			player.y = pa4.y +20
		end
		if(common.jsk == "down") then
			player.x = pa4.x-- - 10
			player.y = pa4.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa4.x + 20
			player.y = pa4.y +20
		end
		if(common.jsk == "left") then
			player.x = pa4.x - 20
			player.y = pa4.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa4.x + 30
			player.y = pa4.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa4.x - 20
			player.y = pa4.y -20
		end 
	end
	
	if(common.ballparent == "a3") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa3.x - 10
			player.y = pa3.y +10
		end
		if(common.jsk == "1") then
			player.x = pa3.x - 10
			player.y = pa3.y +10
		end
		if(common.jsk == "up") then
			player.x = pa3.x --- 10
			player.y = pa3.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa3.x + 20
			player.y = pa3.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa3.x - 20
			player.y = pa3.y +20
		end
		if(common.jsk == "down") then
			player.x = pa3.x-- - 10
			player.y = pa3.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa3.x + 20
			player.y = pa3.y +20
		end
		if(common.jsk == "left") then
			player.x = pa3.x - 20
			player.y = pa3.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa3.x + 30
			player.y = pa3.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa3.x - 20
			player.y = pa3.y -20
		end 
	end
	
	if(common.ballparent == "a2") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa2.x - 10
			player.y = pa2.y +10
		end
		if(common.jsk == "1") then
			player.x = pa2.x - 10
			player.y = pa2.y +10
		end
		if(common.jsk == "up") then
			player.x = pa2.x --- 10
			player.y = pa2.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa2.x + 20
			player.y = pa2.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa2.x - 20
			player.y = pa2.y +20
		end
		if(common.jsk == "down") then
			player.x = pa2.x-- - 10
			player.y = pa2.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa2.x + 20
			player.y = pa2.y +20
		end
		if(common.jsk == "left") then
			player.x = pa2.x - 20
			player.y = pa2.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa2.x + 30
			player.y = pa2.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa2.x - 20
			player.y = pa2.y -20
		end 
	end
	
	if(common.ballparent == "a1") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pa1.x - 10
			player.y = pa1.y +10
		end
		if(common.jsk == "1") then
			player.x = pa1.x - 10
			player.y = pa1.y +10
		end
		if(common.jsk == "up") then
			player.x = pa1.x --- 10
			player.y = pa1.y -20
		end
		if(common.jsk == "upright") then
			player.x = pa1.x + 20
			player.y = pa1.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pa1.x - 20
			player.y = pa1.y +20
		end
		if(common.jsk == "down") then
			player.x = pa1.x-- - 10
			player.y = pa1.y +20
		end
		if(common.jsk == "downright") then
			player.x = pa1.x + 20
			player.y = pa1.y +20
		end
		if(common.jsk == "left") then
			player.x = pa1.x - 20
			player.y = pa1.y --+10
		end
		if(common.jsk == "right") then
			player.x = pa1.x + 30
			player.y = pa1.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pa1.x - 20
			player.y = pa1.y -20
		end 
	end
	
	if(common.ballparent == "b11") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb11.x - 10
			player.y = pb11.y +10
		end
		if(common.jsk == "1") then
			player.x = pb11.x - 10
			player.y = pb11.y +10
		end
		if(common.jsk == "up") then
			player.x = pb11.x --- 10
			player.y = pb11.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb11.x + 20
			player.y = pb11.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb11.x - 20
			player.y = pb11.y +20
		end
		if(common.jsk == "down") then
			player.x = pb11.x-- - 10
			player.y = pb11.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb11.x + 20
			player.y = pb11.y +20
		end
		if(common.jsk == "left") then
			player.x = pb11.x - 20
			player.y = pb11.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb11.x + 30
			player.y = pb11.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb11.x - 20
			player.y = pb11.y -20
		end 
	end
	
	if(common.ballparent == "b10") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb10.x - 10
			player.y = pb10.y +10
		end
		if(common.jsk == "1") then
			player.x = pb10.x - 10
			player.y = pb10.y +10
		end
		if(common.jsk == "up") then
			player.x = pb10.x --- 10
			player.y = pb10.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb10.x + 20
			player.y = pb10.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb10.x - 20
			player.y = pb10.y +20
		end
		if(common.jsk == "down") then
			player.x = pb10.x-- - 10
			player.y = pb10.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb10.x + 20
			player.y = pb10.y +20
		end
		if(common.jsk == "left") then
			player.x = pb10.x - 20
			player.y = pb10.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb10.x + 30
			player.y = pb10.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb10.x - 20
			player.y = pb10.y -20
		end 
	end
	
	if(common.ballparent == "b9") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb9.x - 10
			player.y = pb9.y +10
		end
		if(common.jsk == "1") then
			player.x = pb9.x - 10
			player.y = pb9.y +10
		end
		if(common.jsk == "up") then
			player.x = pb9.x --- 10
			player.y = pb9.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb9.x + 20
			player.y = pb9.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb9.x - 20
			player.y = pb9.y +20
		end
		if(common.jsk == "down") then
			player.x = pb9.x-- - 10
			player.y = pb9.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb9.x + 20
			player.y = pb9.y +20
		end
		if(common.jsk == "left") then
			player.x = pb9.x - 20
			player.y = pb9.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb9.x + 30
			player.y = pb9.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb9.x - 20
			player.y = pb9.y -20
		end 
	end
	
	if(common.ballparent == "b8") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb8.x - 10
			player.y = pb8.y +10
		end
		if(common.jsk == "1") then
			player.x = pb8.x - 10
			player.y = pb8.y +10
		end
		if(common.jsk == "up") then
			player.x = pb8.x --- 10
			player.y = pb8.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb8.x + 20
			player.y = pb8.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb8.x - 20
			player.y = pb8.y +20
		end
		if(common.jsk == "down") then
			player.x = pb8.x-- - 10
			player.y = pb8.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb8.x + 20
			player.y = pb8.y +20
		end
		if(common.jsk == "left") then
			player.x = pb8.x - 20
			player.y = pb8.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb8.x + 30
			player.y = pb8.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb8.x - 20
			player.y = pb8.y -20
		end 
	end
	
	if(common.ballparent == "b7") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb7.x - 10
			player.y = pb7.y +10
		end
		if(common.jsk == "1") then
			player.x = pb7.x - 10
			player.y = pb7.y +10
		end
		if(common.jsk == "up") then
			player.x = pb7.x --- 10
			player.y = pb7.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb7.x + 20
			player.y = pb7.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb7.x - 20
			player.y = pb7.y +20
		end
		if(common.jsk == "down") then
			player.x = pb7.x-- - 10
			player.y = pb7.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb7.x + 20
			player.y = pb7.y +20
		end
		if(common.jsk == "left") then
			player.x = pb7.x - 20
			player.y = pb7.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb7.x + 30
			player.y = pb7.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb7.x - 20
			player.y = pb7.y -20
		end 
	end
	
	if(common.ballparent == "b6") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb6.x - 10
			player.y = pb6.y +10
		end
		if(common.jsk == "1") then
			player.x = pb6.x - 10
			player.y = pb6.y +10
		end
		if(common.jsk == "up") then
			player.x = pb6.x --- 10
			player.y = pb6.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb6.x + 20
			player.y = pb6.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb6.x - 20
			player.y = pb6.y +20
		end
		if(common.jsk == "down") then
			player.x = pb6.x-- - 10
			player.y = pb6.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb6.x + 20
			player.y = pb6.y +20
		end
		if(common.jsk == "left") then
			player.x = pb6.x - 20
			player.y = pb6.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb6.x + 30
			player.y = pb6.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb6.x - 20
			player.y = pb6.y -20
		end 
	end
	
	if(common.ballparent == "b5") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb5.x - 10
			player.y = pb5.y +10
		end
		if(common.jsk == "1") then
			player.x = pb5.x - 10
			player.y = pb5.y +10
		end
		if(common.jsk == "up") then
			player.x = pb5.x --- 10
			player.y = pb5.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb5.x + 20
			player.y = pb5.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb5.x - 20
			player.y = pb5.y +20
		end
		if(common.jsk == "down") then
			player.x = pb5.x-- - 10
			player.y = pb5.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb5.x + 20
			player.y = pb5.y +20
		end
		if(common.jsk == "left") then
			player.x = pb5.x - 20
			player.y = pb5.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb5.x + 30
			player.y = pb5.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb5.x - 20
			player.y = pb5.y -20
		end 
	end
	
	if(common.ballparent == "b4") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb4.x - 10
			player.y = pb4.y +10
		end
		if(common.jsk == "1") then
			player.x = pb4.x - 10
			player.y = pb4.y +10
		end
		if(common.jsk == "up") then
			player.x = pb4.x --- 10
			player.y = pb4.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb4.x + 20
			player.y = pb4.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb4.x - 20
			player.y = pb4.y +20
		end
		if(common.jsk == "down") then
			player.x = pb4.x-- - 10
			player.y = pb4.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb4.x + 20
			player.y = pb4.y +20
		end
		if(common.jsk == "left") then
			player.x = pb4.x - 20
			player.y = pb4.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb4.x + 30
			player.y = pb4.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb4.x - 20
			player.y = pb4.y -20
		end 
	end
	
	if(common.ballparent == "b3") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb3.x - 10
			player.y = pb3.y +10
		end
		if(common.jsk == "1") then
			player.x = pb3.x - 10
			player.y = pb3.y +10
		end
		if(common.jsk == "up") then
			player.x = pb3.x --- 10
			player.y = pb3.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb3.x + 20
			player.y = pb3.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb3.x - 20
			player.y = pb3.y +20
		end
		if(common.jsk == "down") then
			player.x = pb3.x-- - 10
			player.y = pb3.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb3.x + 20
			player.y = pb3.y +20
		end
		if(common.jsk == "left") then
			player.x = pb3.x - 20
			player.y = pb3.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb3.x + 30
			player.y = pb3.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb3.x - 20
			player.y = pb3.y -20
		end 
	end
	
	if(common.ballparent == "b2") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb2.x - 10
			player.y = pb2.y +10
		end
		if(common.jsk == "1") then
			player.x = pb2.x - 10
			player.y = pb2.y +10
		end
		if(common.jsk == "up") then
			player.x = pb2.x --- 10
			player.y = pb2.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb2.x + 20
			player.y = pb2.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb2.x - 20
			player.y = pb2.y +20
		end
		if(common.jsk == "down") then
			player.x = pb2.x-- - 10
			player.y = pb2.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb2.x + 20
			player.y = pb2.y +20
		end
		if(common.jsk == "left") then
			player.x = pb2.x - 20
			player.y = pb2.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb2.x + 30
			player.y = pb2.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb2.x - 20
			player.y = pb2.y -20
		end 
	end
	
	if(common.ballparent == "b1") then
		--0,up,upright,downleft,down,downright,left,right,upleft,1
		if(common.jsk == "0") then
			player.x = pb1.x - 10
			player.y = pb1.y +10
		end
		if(common.jsk == "1") then
			player.x = pb1.x - 10
			player.y = pb1.y +10
		end
		if(common.jsk == "up") then
			player.x = pb1.x --- 10
			player.y = pb1.y -20
		end
		if(common.jsk == "upright") then
			player.x = pb1.x + 20
			player.y = pb1.y -20
		end
		if(common.jsk == "downleft") then
			player.x = pb1.x - 20
			player.y = pb1.y +20
		end
		if(common.jsk == "down") then
			player.x = pb1.x-- - 10
			player.y = pb1.y +20
		end
		if(common.jsk == "downright") then
			player.x = pb1.x + 20
			player.y = pb1.y +20
		end
		if(common.jsk == "left") then
			player.x = pb1.x - 20
			player.y = pb1.y --+10
		end
		if(common.jsk == "right") then
			player.x = pb1.x + 30
			player.y = pb1.y-- +10
		end
		if(common.jsk == "upleft") then
			player.x = pb1.x - 20
			player.y = pb1.y -20
		end 
	end


		if(common.balevent == "float") then
			for i=table.getn(common.swiplog),0,-1 do 
				if(common.swiplog[i] ~= common.swiplog[table.getn(common.swiplog)]) then
					common.latestswip = common.swiplog[i] --.. " - " .. i
					break
				end
			end
			--print("common.swiplog[table.getn(common.swiplog) - 1] " .. common.latestswip)
			
					if(common.latestswip == "0") then
						player.x = player.x - 40
						player.y = player.y + 40
					end
					if(common.latestswip == "1") then
						player.x = player.x - 40
						player.y = player.y + 40
					end
					if(common.latestswip == "up") then
						player.x = player.x --- 10
						player.y = player.y - 60
					end
					if(common.latestswip == "upright") then
						player.x = player.x + 60
						player.y = player.y - 60
					end
					if(common.latestswip == "downleft") then
						player.x = player.x - 40
						player.y = player.y + 40
					end
					if(common.latestswip == "down") then
						player.x = player.x-- - 10
						player.y = player.y + 40
					end
					if(common.latestswip == "downright") then
						player.x = player.x + 60
						player.y = player.y + 60
					end
					if(common.latestswip == "left") then
						player.x = player.x - 40
						player.y = player.y --+10
					end
					if(common.latestswip == "right") then
						player.x = player.x + 60
						player.y = player.y-- +10
					end
					if(common.latestswip == "upleft") then
						player.x = player.x - 40
						player.y = player.y - 40
					end 
			
			common.jaok = 0
			common.balevent = ""
			--common.latestswip = ""
			common.ballparent = ""
		end
		if(common.balevent == "pass") then
			for i=table.getn(common.swiplog),0,-1 do 
				if(common.swiplog[i] ~= common.swiplog[table.getn(common.swiplog)]) then
					common.latestswip = common.swiplog[i] --.. " - " .. i
					break
				end
			end
			--print("common.swiplog[table.getn(common.swiplog) - 1] " .. common.latestswip)
			
					if(common.latestswip == "0") then
						player.x = player.x - 140
						player.y = player.y + 140
					end
					if(common.latestswip == "1") then
						player.x = player.x - 140
						player.y = player.y + 140
					end
					if(common.latestswip == "up") then
						player.x = player.x --- 10
						player.y = player.y - 160
					end
					if(common.latestswip == "upright") then
						player.x = player.x + 160
						player.y = player.y - 160
					end
					if(common.latestswip == "downleft") then
						player.x = player.x - 140
						player.y = player.y + 140
					end
					if(common.latestswip == "down") then
						player.x = player.x-- - 10
						player.y = player.y + 140
					end
					if(common.latestswip == "downright") then
						player.x = player.x + 160
						player.y = player.y + 160
					end
					if(common.latestswip == "left") then
						player.x = player.x - 140
						player.y = player.y --+10
					end
					if(common.latestswip == "right") then
						player.x = player.x + 160
						player.y = player.y-- +10
					end
					if(common.latestswip == "upleft") then
						player.x = player.x - 140
						player.y = player.y - 140
					end 
			
			common.jaok = 0
			common.balevent = ""
			--common.latestswip = ""
			common.ballparent = ""
		end
		if(common.balevent == "shot") then
						for i=table.getn(common.swiplog),0,-1 do 
				if(common.swiplog[i] ~= common.swiplog[table.getn(common.swiplog)]) then
					common.latestswip = common.swiplog[i] --.. " - " .. i
					break
				end
			end
			--print("common.swiplog[table.getn(common.swiplog) - 1] " .. common.latestswip)
			
					if(common.latestswip == "0") then
						player.x = player.x - 240
						player.y = player.y + 240
					end
					if(common.latestswip == "1") then
						player.x = player.x - 240
						player.y = player.y + 240
					end
					if(common.latestswip == "up") then
						player.x = player.x --- 10
						player.y = player.y - 260
					end
					if(common.latestswip == "upright") then
						player.x = player.x + 260
						player.y = player.y - 260
					end
					if(common.latestswip == "downleft") then
						player.x = player.x - 240
						player.y = player.y + 240
					end
					if(common.latestswip == "down") then
						player.x = player.x-- - 10
						player.y = player.y + 240
					end
					if(common.latestswip == "downright") then
						player.x = player.x + 260
						player.y = player.y + 260
					end
					if(common.latestswip == "left") then
						player.x = player.x - 240
						player.y = player.y --+10
					end
					if(common.latestswip == "right") then
						player.x = player.x + 260
						player.y = player.y-- +10
					end
					if(common.latestswip == "upleft") then
						player.x = player.x - 240
						player.y = player.y - 240
					end 
			
			common.jaok = 0
			common.balevent = ""
			--common.latestswip = ""
			common.ballparent = ""
		end
		if(common.balevent =="longshot") then
						for i=table.getn(common.swiplog),0,-1 do 
				if(common.swiplog[i] ~= common.swiplog[table.getn(common.swiplog)]) then
					common.latestswip = common.swiplog[i] --.. " - " .. i
					break
				end
			end
			--print("common.swiplog[table.getn(common.swiplog) - 1] " .. common.latestswip)
			
					if(common.latestswip == "0") then
						player.x = player.x - 640
						player.y = player.y + 640
					end
					if(common.latestswip == "1") then
						player.x = player.x - 640
						player.y = player.y + 640
					end
					if(common.latestswip == "up") then
						player.x = player.x --- 10
						player.y = player.y - 660
					end
					if(common.latestswip == "upright") then
						player.x = player.x + 660
						player.y = player.y - 660
					end
					if(common.latestswip == "downleft") then
						player.x = player.x - 640
						player.y = player.y + 640
					end
					if(common.latestswip == "down") then
						player.x = player.x-- - 10
						player.y = player.y + 640
					end
					if(common.latestswip == "downright") then
						player.x = player.x + 660
						player.y = player.y + 660
					end
					if(common.latestswip == "left") then
						player.x = player.x - 640
						player.y = player.y --+10
					end
					if(common.latestswip == "right") then
						player.x = player.x + 660
						player.y = player.y-- +10
					end
					if(common.latestswip == "upleft") then
						player.x = player.x - 640
						player.y = player.y - 640
					end 
			
			common.jaok = 0
			common.balevent = ""
			--common.latestswip = ""
			common.ballparent = ""
		end

-------------------------------------
dbalx = player.x
dbaly = player.y
maxballx = 1 * ((5700 / 2) - 72)
minballx = -1 * maxballx
minbally = -355
maxbally = 355
--print("if(((" .. dbalx .. " > " .. maxballx .. ") or (" .. dbalx .. " < " .. minballx .. ")) and ((" .. dbaly .. " > " .. minbally .. ") or (" .. dbaly .. " < " .. minbally .. "))) then")
-------  if(((2793.4025878906 > 4616) or (2793.4025878906 < -940)) and ((1.0006332397461 > -355) or (1.0006332397461 < -355))) then

if(((dbalx > maxballx) or (dbalx < minballx)) and ((dbaly > minbally) or (dbaly < minbally))) then
	print("ja gole *******!!!!!!!!!!:::::)))))))))------")
	if((dbalx > maxballx)) then
		common.scor1 = tonumber(common.scor1) + 1
	elseif (dbalx < minballx) then
		common.scor2 = tonumber(common.scor2) + 1
	end
	
	player.x = 0
	player.y = 0
	startdiegame()
	common.isgole = true
end

end

--------------------------------------------------------------------------------
-- Add Listeners



lastDst = 0
touchCont = 0
 
local function testCollisions()
--for i=1, #objects do
if hasCollided(myRectangle, player) then
	------print("************ COLLIII = " .. "true")
else
	------print("************ COLLIII = " .. "false")	
	player.moveSpeed = 0
end

-- ycSprit و WHITEsprite , BLUEsprite , REDsprite

if hasCollided(WHITEsprite, player) then
	
	------print( "colied 2 white player ***********" )
	
	display.getCurrentStage():setFocus(t)
		--t.isFocus = true
		--m.result = t.result
		
		
	--if t.result == "rotate:left" then 
			--player.angularVelocity = -2
		--elseif t.result == "rotate:right" then
			--player.angularVelocity = 2
		--elseif t.result == "move" then
			--player.moveSpeed = 2
	
	--display.getCurrentStage():setFocus(nil)
			--t.isFocus = false
			--m.result = "none"
			
			
			
			
			
	--			if m.result == "rotate:left" then
	--	player.angularVelocity = player.angularVelocity * player.angularAcceleration
	--	player.angularVelocity = math.max(player.angularVelocity, -player.angularMax)
	--	player.moveSpeed = player.moveSpeed * player.linearDamping
	--elseif m.result == "rotate:right" then
	--	player.angularVelocity = player.angularVelocity * player.angularAcceleration
	--	player.angularVelocity = math.min(player.angularVelocity, player.angularMax)
	--	player.moveSpeed = player.moveSpeed * player.linearDamping
	--elseif m.result == "move" then
		
	--	player.moveSpeed = player.moveSpeed * player.linearAcceleration
	--		player.moveSpeed = math.min(player.moveSpeed, player.linearMax)
	--		player.angularVelocity = player.angularVelocity * player.angularDamping
		

--elseif m.result == "none" then
	--	player.angularVelocity = player.angularVelocity * player.angularDamping
	--	player.moveSpeed = player.moveSpeed * player.linearDamping
	--end

	--local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
	--player:translate(WHITEsprite.x,WHITEsprite.y) --forces.x, forces.y)
	
	--player:rotate(player.angularVelocity)


------print( "**** last dst:: " .. lastDst )

	if lastDst == 2 then
		player.angularVelocity = 0
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(forces.y, ( -1 * forces.x ))
	    --player:rotate(player.angularVelocity)
	end
	if lastDst == 3 then
		player.angularVelocity = -2
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(( 1 * forces.x ), ( -1 * forces.x ))
	    --player:rotate(player.angularVelocity)
	end
	if lastDst == 4 then
		player.angularVelocity = 2
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(forces.x, forces.y)
	    player:rotate(player.angularVelocity)
	end
	if lastDst == 5 then
		player.angularVelocity = 2
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(forces.x, forces.y)
	    player:rotate(player.angularVelocity)
	end
	if lastDst == 6 then
		player.angularVelocity = 2
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(forces.x, forces.y)
	    player:rotate(player.angularVelocity)
	end
	if lastDst == 7 then
		player.angularVelocity = 2
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(forces.x, forces.y)
	    player:rotate(player.angularVelocity)
	end
	if lastDst == 8 then
		player.angularVelocity = 2
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(forces.x, forces.y)
	    player:rotate(player.angularVelocity)
	end
	if lastDst == 9 then
		player.angularVelocity = 2
		player.moveSpeed = 2
		local forces = forcesByAngle(player.moveSpeed, 360 - player.rotation)
		player:translate(forces.x, forces.y)
	    player:rotate(player.angularVelocity)
	end
			
			
			
	
end
if hasCollided(BLUEsprite, player) then
	
end
if hasCollided(REDsprite, player) then
	
end


--end
end

Runtime:addEventListener("enterFrame", testCollisions)

--------------------------------------------------------------------------------
Runtime:addEventListener("enterFrame", enterFrame)

camera.damping = 10 -- A bit more fluid tracking
camera:setFocus(player) -- Set the focus to the player
camera:track() -- Begin auto-tracking



--camera.scale(2, 2)
camera:scale( 4,4 )
--camera:scale( 0.1,0.1 )
--camera:scale( 0.5,0.5 )
--camera:scale( 0.3,0.3 )





--local object = display.newImage( "ball.png" )
--object.id = "ball object"

	
 
 actifplayn = "A1"
 prevTochResult = ""
 sameAsPrevToch = 0
 --ycSprit = WHITEsprite
 animateType = ""
 
 local holding = false
 
 
 	local function listener2( obj )
    ------print( "Transition 2 completed on object: " .. tostring( obj ) )
end
 
local function enterFrameListener()
    if holding then
       --	if ( sameAsPrevToch > 1 ) then
		--			ycSprit:setSequence( "runup" )
					--transition.to (ycSprit, {time=5000, x=ycSprit.x, y=ycSprit.y-1})
				
  
-- (1) move square to bottom right corner; subtract half side-length
--transition.to( ycSprit, { time=100, alpha=1, x=(ycSprit.x), y=(ycSprit.y-10), onComplete=listener2 } )
		--end
	--	ycSprit:play()
		--ycSprit.y = ycSprit.y - 1
		--ycSprit:setFrame( ycSprit.frame + 1 )
		
		if animateType == 2 then
			ycSprit.y = ycSprit.y - 1
		end
		if animateType == 3 then
			ycSprit.y = ycSprit.y - 1
			ycSprit.x = ycSprit.x + 1
		end
		if animateType == 4 then
			--ycSprit.y = ycSprit.y - 1
			ycSprit.x = ycSprit.x + 1
		end
		if animateType == 5 then
			ycSprit.y = ycSprit.y + 1
			ycSprit.x = ycSprit.x + 1
		end
		if animateType == 6 then
			ycSprit.y = ycSprit.y + 1
		end
		if animateType == 7 then
			ycSprit.y = ycSprit.y + 1
			ycSprit.x = ycSprit.x - 1
		end
		if animateType == 8 then
			--ycSprit.y = ycSprit.y - 1
			ycSprit.x = ycSprit.x - 1
		end
		if animateType == 9 then
			ycSprit.y = ycSprit.y - 1
			ycSprit.x = ycSprit.x - 1
		end
		
    else
        -- Not holding
        -- Code here
        -- Code here
        -- Code here
    end
end

local function onObjectTouch( event )

do return end

	if event.phase == "began" then
        display.getCurrentStage():setFocus( event.target )
        event.target.isFocus = true
        Runtime:addEventListener( "enterFrame", enterFrameListener )
        holding = true
    elseif event.target.isFocus then
        if event.phase == "moved" then
        elseif event.phase == "ended" then
            holding = false
            Runtime:removeEventListener( "enterFrame", enterFrameListener )
           display.getCurrentStage():setFocus( nil )
            event.target.isFocus = false
        end
    end


	touchCont = touchCont + 1

	x1 = JoyStig.x + 76 --( ( display.contentWidth / 2 ) - 200 ) + 63
	x2 = x1 + 43
	y1 = 200 - ( 22 ) --JoyStig.y + 62
	y2 = y1 + 43
	dx = event.x
	dy = event.y
	dst = 0
	if (  dx > x1 ) then
		if ( dx < x2 ) then
			if ( dy > y1 ) then
				if ( dy < y2 ) then
					dst = 1
					
				end
			end
		end
	end
	
	if ( lastDst > 0 ) then
		
		if (  dx > x1 ) then
			if ( dx < x2 ) then
				if ( dy > y1 ) then
					if ( dy < y2 ) then
						dst = 10
					end
				end
			end
		elseif (  dx < x1 ) then
			if ( dy < y1 ) then
				dst = 9
			end
			if ( dy > y1 ) then
				if ( dy < y2 ) then
					dst = 8
				elseif true then
				dst = 7
				end
			end
		elseif (  dx < x2 ) then
		
		dst = 6
			if ( dy > y1 ) then
				dst = 2
			end
			if ( dy < y2 ) then
				dst = 6
			end
			
		elseif true then
		
			if ( dy < y1 ) then
				dst = 3
			--end
			elseif ( dy > y2 ) then
				dst = 5
			elseif true then
				dst = 4
			end
			
		
			
		
		end
		
		
			if (  dx > x1 ) then
				if ( dx < x2 ) then
					if ( dy > y1 ) then
						if ( dy > y2 ) then
							dst = 6
						end
					elseif true then
						dst = 2
					end
				end
				if ( dx > x2 ) then
					if ( dy > y1 ) then
						if ( dy > y2 ) then
							dst = 5
						end
					elseif true then
						if ( dy > y2 ) then
							dst = 3
						elseif true then
						if ( dy > y1 ) then
							dst = 3
						elseif true then	
							dst = 4
							end
						end
						
					end
				end
			end
			
			if ( dx > x2 ) then
				if ( dy < 115 ) then
					dst = 3
				end	
			end 
		
		lastDst = dst
		
		if ( touchCont > 2 ) then
			if ( dst == 10 ) then
				JoyStig:setSequence( "frame10" )
				if ( touchCont % 2 ) == 0 then
				if ( actifplayn == "A1" ) then
					actifplayn = "A2"
					ycSprit = REDsprite
				elseif true then
					actifplayn = "A1"
					ycSprit = BLUEsprite
				end
				end
			end
			if ( dst == 1 ) then
				JoyStig:setSequence( "frame1" )
				
			end
			if ( dst == 2 ) then
				------print( "event.phase: " .. event.phase )
				JoyStig:setSequence( "frame2" )
				--ycSprit:setSequence( "standup" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "runup" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standup" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:play()
			end
			if ( dst == 3 ) then
				JoyStig:setSequence( "frame3" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "runupright" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standupright" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:setSequence( "standupright" )
				--ycSprit:play()
			end
			if ( dst == 4 ) then
				JoyStig:setSequence( "frame4" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "runright" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standright" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:setSequence( "standright" )
				--ycSprit:play()
			end
			if ( dst == 5 ) then
				JoyStig:setSequence( "frame5" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "runrightdown" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standrightdown" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:setSequence( "standrightdown" )
				--ycSprit:play()
			end
			if ( dst == 6 ) then
				JoyStig:setSequence( "frame6" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "rundown" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standdown" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:setSequence( "standdown" )
				--ycSprit:play()
			end
			if ( dst == 7 ) then
				JoyStig:setSequence( "frame7" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "rundownleft" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standdownleft" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:setSequence( "standdownleft" )
				--ycSprit:play()
			end
			if ( dst == 8 ) then
				JoyStig:setSequence( "frame8" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "runleft" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standleft" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:setSequence( "" )
				--ycSprit:play()
			end
			if ( dst == 9 ) then
				JoyStig:setSequence( "frame9" )
				if ( sameAsPrevToch == 2 ) then
					ycSprit:setSequence( "runupleft" )
					ycSprit:play()	
					
				elseif sameAsPrevToch == 1 then
					ycSprit:setSequence( "standupleft" )
					ycSprit:play()	
				elseif true then
					--ycSprit.y = ycSprit.y - 1
				 end
				--ycSprit:setSequence( "standupleft" )
				--ycSprit:play()
			end
			
			if ( dst == prevTochResult ) then
				sameAsPrevToch = sameAsPrevToch + 1
			elseif true then
				sameAsPrevToch = 0	
			end
			prevTochResult = dst
			animateType = dst
			
		end
		
	--end
	
	elseif ( dst == 1 ) then
		JoyStig:setSequence( "beforestart" )
		--JoyStig:stop()
		lastDst = 1
	end
	
	
	if ( actifplayn == "A1" ) then
		-- actifPlayer.x = BLUEsprite.x -- + 5
		-- actifPlayer.y = BLUEsprite.y -- - 10 -- - 65
		 
		 --BLUEsprite:setSequence( "actif" )
		 --REDsprite:setSequence( "character" )
	end
	if ( actifplayn == "A2" ) then
		-- actifPlayer.x = REDsprite.x -- + 5
		-- actifPlayer.y = REDsprite.y -- - 10 -- - 65
		 
		 --REDsprite:setSequence( "actif" )
		 --BLUEsprite:setSequence( "character" )
	end
		

        ------print( "Touch event began on: dst= " .. dst ) -- .. event.x .. " , " .. display.contentWidth)--  / 2)))-- .. " - " .. (event.y .. " , " .. player.y))-- .. " - " ..  event.xStart .. " sprite: " .. sprite.x .. "*" .. sprite.y .. " === " .. event.x .. "*" .. event.y)
		------print( "Touch event began on: x2= " .. x2 .. " - dx= " .. dx .. " - -JoyStig.x= " .. JoyStig.x )
		------print( "Touch event began on: y1= " .. y1 .. " - dy= " .. dy .. " - -JoyStig.y= " .. JoyStig.y )
		------print( "Touch event began on: y2= " .. y2 .. " - dy= " .. dy .. " - -JoyStig.y= " .. JoyStig.y )
--JoyStig.x = event.x - 2000 --(display.contentWidth  / 2) - 100
		--JoyStig.y = event.y - 100
    --if ( event.phase == "began" ) then
    --elseif ( event.phase == "ended" ) then
       -- ----print( "Touch event ended on: " .. event.target.id )
    --end
   -- return true
end
display.getCurrentStage():addEventListener( "touch", onObjectTouch )
--myRectangle:addEventListener( "touch", onObjectTouch )

local function onObjectTouch2( event )
--        ----print( "Touch event began on: " .. (event.x .. " , " .. event.y ))-- .. " - " ..  event.xStart .. " sprite: " .. sprite.x .. "*" .. sprite.y .. " === " .. event.x .. "*" .. event.y)
--JoyStig.x = event.x - 2000 --(display.contentWidth  / 2) - 100
		--JoyStig.y = event.y - 100
    --if ( event.phase == "began" ) then
    --elseif ( event.phase == "ended" ) then
       -- ----print( "Touch event ended on: " .. event.target.id )
    --end
   -- return true
end
JoyStig:addEventListener( "touch", onObjectTouch2 )

-- sprite listener function
local function spriteListener( event )
 
    local thisSprite = event.target  -- "event.target" references the sprite
 
    if ( event.phase == "ended" ) then 
        thisSprite:setSequence( "fastRun" )  -- switch to "fastRun" sequence
        thisSprite:play()  -- play the new sequence
    end
end
 
-- add the event listener to the sprite
--JoyStig:addEventListener( "sprite", spriteListener )
--ycSprit = WHITEsprite
 --BLUEsprite:setSequence( "character" )
 --REDsprite:setSequence( "character" )
		-- ycSprit:setSequence( "standup" )
			--	ycSprit:play()


local composer = require( "composer" )
local scene = composer.newScene()
local common = require("common")
	
local function webListenerG( event )
    if event.url then
        ------print( "You are visiting: " .. event.url )
		common.inPaus = false
    end
  
    if event.type then
        ------print( "The event.type is " .. event.type ) -- print the type of request
    end
  
    if event.errorCode then
        native.showAlert( "Error!", event.errorMessage, { "OK" } )
    end
end

--local webViewG = native.newWebView( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )
--webViewG:request( "login.html")-- , system.ResourceDirectory)--http://football.maxim.shop/Play/IntroLig2" )
--webViewG:addEventListener( "urlRequest", webListenerG )

function scene:create( event )
	local sceneGroup = self.view
	
	-- Called when the scene's view does not exist.
	-- 
	-- INSERT code here to initialize the scene
	-- e.g. add display objects to 'sceneGroup', add touch listeners, etc.
	
	-- create a white background to fill screen
	--local background = display.newRect( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )
	--background:setFillColor( 1 )	-- white
	
	-- create some text
	--local title = display.newText( "die Game", display.contentCenterX, 125, native.systemFont, 32 )
	--title:setFillColor( 0 )	-- black
	
	--local newTextParams = { text = "Loaded by the first tab's\n\"onPress\" listener\nspecified in the 'tabButtons' table", 
		--				x = display.contentCenterX + 10, 
			--			y = title.y + 215, 
				--		width = 310, height = 310, 
					--	font = native.systemFont, fontSize = 14, 
						--align = "center" }
	--local summary = display.newText( newTextParams )
	--summary:setFillColor( 0 ) -- black

	
		--webViewG:toBack()
		--webViewG.isVisible = false
		
	-- all objects must be added to group (e.g. self.view)
	sceneGroup:insert( camera )
	--sceneGroup:insert( title )
	--sceneGroup:insert( summary )
	--sceneGroup:toFront()
	
end

function save2db()
	-- Data (string) to write
local saveData = "My app state data"
 
-- Path for the file to write
local path = system.pathForFile( "db.txt", system.ResourceDirectory )
 
-- Open the file handle
local file, errorString = io.open( path, "w" )
 
if not file then
    -- Error occurred; output the cause
    ------print( "File error: " .. errorString )
else
    -- Write data to file
    file:write( saveData )
    -- Close the file handle
    io.close( file )
end
 
file = nil
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
		
		
		
		
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
		
	--	webViewG:toFront()
		--webViewG.isVisible = true
		
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------
--save2db ()

return scene

-------------------------------------------------------------------------------
-- Perspective Demo
--------------------------------------------------------------------------------


--------------------------------------------------------------------
-- "Scenery"
--------------------------------------------------------------------------------
--local scene = {}
--for i = 1, 100 do
	--scene[i] = display.newCircle(0, 0, 10)
	--scene[i].x = math.random(display.screenOriginX, display.contentWidth * 3)
	--scene[i].y = math.random(display.screenOriginY, display.contentHeight)
	--scene[i]:setFillColor(math.random(100) * 0.01, math.random(100) * 0.01, math.random(100) * 0.01)
	--camera:add(scene[i], math.random(0, camera:layerCount()))
--end


-- sprits

