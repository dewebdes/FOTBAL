-----------------------------------------------------------------------------------------
--
-- view1.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local scene = composer.newScene()

local centerX = display.contentCenterX
local centerY = display.contentCenterY
local _W = display.contentWidth
local _H = display.contentHeight


--------------------------------------------------------------------------------------------


-- Abstract: TimeAnimation
-- Version: 2.0
-- Sample code is MIT licensed; see https://www.coronalabs.com/links/code/license
---------------------------------------------------------------------------------------

display.setStatusBar( display.HiddenStatusBar )

------------------------------
-- RENDER THE SAMPLE CODE UI
------------------------------
--local sampleUI = require( "sampleUI.sampleUI" )
--sampleUI:newUI( { theme="darkgrey", title="Time Animation", showBuildNum=false } )

------------------------------
-- CONFIGURE STAGE
------------------------------
--display.getCurrentStage():insert( sampleUI.backGroup )
--local mainGroup = display.newGroup()
--display.getCurrentStage():insert( sampleUI.frontGroup )

----------------------
-- BEGIN SAMPLE CODE
----------------------

-- Set app font
--local appFont = sampleUI.appFont

-- Local variables and forward references
local screenW = display.contentWidth - display.screenOriginX
local screenH = display.contentHeight - display.screenOriginY
local friction1 = 0.8
local gravity1 = 0.098
local friction2 = 0.8
local gravity2 = 0.098
local friction3 = 0.8
local gravity3 = 0.098
local friction4 = 0.8
local gravity4 = 0.098
local friction5 = 0.8
local gravity5 = 0.098

local speedX1, speedY1, prevX1, prevY1, lastTime1, prevTime1 = 0, 0, 0, 0, 0, 0
local speedX2, speedY2, prevX2, prevY2, lastTime2, prevTime2 = 0, 0, 0, 0, 0, 0
local speedX3, speedY3, prevX3, prevY3, lastTime3, prevTime3 = 0, 0, 0, 0, 0, 0
local speedX4, speedY4, prevX4, prevY4, lastTime4, prevTime4 = 0, 0, 0, 0, 0, 0
local speedX5, speedY5, prevX5, prevY5, lastTime5, prevTime5 = 0, 0, 0, 0, 0, 0

--local msg = display.newText( mainGroup, "Drag or fling the ball to bounce", 0, 0, appFont, 13 )
--msg:setFillColor( 1, 0.4, 0.25 )

-- Create ball
--local ball = display.newCircle( mainGroup, 0, 0, 30 )
--ball:setFillColor( 0.95, 0.1, 0.3 )
--ball:toBack()
local ball1 = display.newImage( "ball-1.png")-- display.newCircle( mainGroup, 0, 0, 30 )
--local ball2 = display.newImage( "ball-2.png")
--local ball3 = display.newImage( "ball-3.png")
--local ball4 = display.newImage( "ball-4.png")
--local ball5 = display.newImage( "ball-5.png")
--ball:setFillColor( 0.95, 0.1, 0.3 )
ball1:toBack()
--ball2:toBack()
--ball3:toBack()
--ball4:toBack()
--ball5:toBack()
-- Set up orientation initially after the app starts
--onResizeEvent()




-- Function to update ball on every frame
local function onMoveBall1( event )

	local timePassed = event.time - lastTime1
	lastTime1 = lastTime1 + timePassed

	speedY1 = speedY1 + gravity1

	ball1.x = ball1.x + ( speedX1 * timePassed )
	ball1.y = ball1.y + ( speedY1 * timePassed )

	if ( ball1.x >= screenW - ( ball1.width * 0.5 ) ) then
		ball1.x = screenW - ( ball1.width * 0.5 )
		speedX1 = speedX1 * friction1
		speedX1 = speedX1 * -1  -- Change direction
	elseif ( ball1.x <= display.screenOriginX + ( ball1.width * 0.5 ) ) then
	    ball1.x = display.screenOriginX + ( ball1.width * 0.5 )
		speedX1 = speedX1 * friction1
		speedX1 = speedX1 * -1  -- Change direction
	end

	if ( ball1.y >= screenH - ( ball1.height * 0.5 ) ) then
		ball1.y = screenH - ( ball1.height * 0.5 )
		speedY1 = speedY1 * friction1
		speedX1 = speedX1 * friction1
		speedY1 = speedY1 * -1  -- Change direction
	elseif ( ball1.y <= display.screenOriginY + ( ball1.height * 0.5 ) ) then
		ball1.y = display.screenOriginY + ( ball1.height * 0.5 )
		speedY1 = speedY1 * friction1
		speedY1 = speedY1 * -1  -- Change direction
	end
end

-- Function to track velocity (for fling)
local function trackVelocity1( event )

	local timePassed = event.time - prevTime1
	prevTime1 = prevTime1 + timePassed
	speedX1 = ( ball1.x - prevX1 ) / timePassed
	speedY1 = ( ball1.y - prevY1 ) / timePassed
	prevX1 = ball1.x
	prevY1 = ball1.y
end

-- General function for dragging objects
local function startDrag1( event )

	local t = event.target
	local phase = event.phase

	if ( "began" == phase ) then

		-- Set touch focus on ball
		display.currentStage:setFocus( t )
		t.isFocus = true

		-- Store initial touch position
		t.x0 = event.x - t.x
		t.y0 = event.y - t.y

		-- Stop ball's current motion, if any
		Runtime:removeEventListener( "enterFrame", onMoveBall1 )
		-- Start tracking velocity
		Runtime:addEventListener( "enterFrame", trackVelocity1 )

	elseif ( t.isFocus ) then

		if ( "moved" == phase ) then

			t.x = event.x - t.x0
			t.y = event.y - t.y0

			-- Force pseudo-touch of "ended" if ball is dragged past any screen edge
			if ( ( t.x > screenW - ( t.width * 0.5 ) ) or
				 ( t.x < display.screenOriginX + ( t.width * 0.5 ) ) or
				 ( t.y > screenH - ( t.height * 0.5 ) ) or
				 ( t.y < display.screenOriginY + ( t.height * 0.5 ) )
			) then
				t:dispatchEvent( { name="touch", phase="ended", target=t, time=event.time } )
			end

		elseif ( "ended" == phase or "cancelled" == phase ) then

			lastTime = event.time

			-- Stop tracking velocity
			Runtime:removeEventListener( "enterFrame", trackVelocity1 )
			-- Start ball's motion
			Runtime:addEventListener( "enterFrame", onMoveBall1 )

			-- Release touch focus from ball
			display.currentStage:setFocus( nil )
			t.isFocus = false
		end
	end
	return true
end

-- Resize event handler
local function onResizeEvent1( event )

	screenW = display.contentWidth - display.screenOriginX
	screenH = display.contentHeight - display.screenOriginY

	--msg.x = display.contentCenterX
	--msg.y = 55 + display.screenOriginY

	-- Reset ball location to center of the screen
	ball1.x = display.contentCenterX
	ball1.y = display.contentCenterY
end





function scene:create( event )
	local sceneGroup = self.view
	
	-- Called when the scene's view does not exist.
	-- 
	-- INSERT code here to initialize the scene
	-- e.g. add display objects to 'sceneGroup', add touch listeners, etc.
	
	-- create a white background to fill screen
	--local background = display.newRect( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )
	--background:setFillColor( 1 )	-- white
	
	-- create some text
	--local title = display.newText( "First View", display.contentCenterX, 125, native.systemFont, 32 )
	--title:setFillColor( 0 )	-- black
	
	--local newTextParams = { text = "Loaded by the first tab's\n\"onPress\" listener\nspecified in the 'tabButtons' table", 
		--				x = display.contentCenterX + 10, 
			--			y = title.y + 215, 
				--		width = 310, height = 310, 
					--	font = native.systemFont, fontSize = 14, 
						--align = "center" }
	--local summary = display.newText( newTextParams )
	--summary:setFillColor( 0 ) -- black

	local bkg0 = display.newImage( "intro1.jpg", centerX, centerY, true )
	--local bkg = display.newImage( "BG-3-a.jpg", centerX, centerY, true )
	
	-- all objects must be added to group (e.g. self.view)
	--sceneGroup:insert( bkg )
	sceneGroup:insert( bkg0 )
	
	
	--sceneGroup:insert( title )
	--sceneGroup:insert( summary )
	
	Runtime:addEventListener( "resize", onResizeEvent1 )
Runtime:addEventListener( "enterFrame", onMoveBall1 )
ball1:addEventListener( "touch", startDrag1 )
sceneGroup:insert( ball1 )


--Runtime:addEventListener( "resize", onResizeEvent2 )
--Runtime:addEventListener( "enterFrame", onMoveBall2 )
--ball2:addEventListener( "touch", startDrag2 )



--Runtime:addEventListener( "resize", onResizeEvent3 )
--Runtime:addEventListener( "enterFrame", onMoveBall3 )
--ball3:addEventListener( "touch", startDrag3 )



--Runtime:addEventListener( "resize", onResizeEvent4 )
--Runtime:addEventListener( "enterFrame", onMoveBall4 )
--ball4:addEventListener( "touch", startDrag4 )




--Runtime:addEventListener( "resize", onResizeEvent5 )
--Runtime:addEventListener( "enterFrame", onMoveBall5 )
--ball5:addEventListener( "touch", startDrag5 )


--sceneGroup:insert( ball2 )
--sceneGroup:insert( ball3 )
--sceneGroup:insert( ball4 )
--sceneGroup:insert( ball5 )


end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene