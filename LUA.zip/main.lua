-----------------------------------------------------------------------------------------
--
-- main.lua
--
-----------------------------------------------------------------------------------------

-- show default status bar (iOS)
display.setStatusBar( display.DefaultStatusBar )

-- include Corona's "widget" library
local widget = require "widget"
local composer = require "composer"

local common = require("common")


-------------------------------------------------------------------------

local objpaus = display.newImage( "pause.png" )
objpaus.x = display.contentCenterX
objpaus.y = display.contentCenterY


	
local function webListener( event )
    if event.url then
        ----print( "You are visiting: " .. event.url )
		common.inPaus = false
    end
  
    if event.type then
        ----print( "The event.type is " .. event.type ) -- print the type of request
    end
  
    if event.errorCode then
        native.showAlert( "Error!", event.errorMessage, { "OK" } )
    end
end
local webView --= native.newWebView( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )
local webView2 --= native.newWebView( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )


------------------------------------------------------------------------

-- event listeners for tab buttons:
local function showContact( event )
	--composer.gotoScene( "view1" )
	common.lastLink = ""
	local options = {
    effect = "fade",
    time = 800,
    		params = { level="Level 1", score=currentScore }
	}
	composer.gotoScene( "dieHelp", options )
end
local function showGame( event )
	common.lastLink = ""
	--composer.gotoScene( "view1" )
	local options = {
    effect = "fade",
    time = 800,
    		params = { level="Level 1", score=currentScore }
	}
	composer.gotoScene( "fotbal", options )
end

local function showSupport( event )
	common.lastLink = ""
	--composer.gotoScene( "view1" )
	local options = {
    effect = "fade",
    time = 800,
    		params = { level="Level 1", score=currentScore }
	}
	composer.gotoScene( "dieSupport", options )
end

local function finishdiegame()
	showContact()
end

local function showStage( event )
	common.lastLink = ""
	--composer.gotoScene( "view2" )
	local options = {
    effect = "fade",
    time = 800,
    		params = { level="Level 1", score=currentScore }
	}
	composer.gotoScene( "dieStage", options )
end


-- create a tabBar widget with two buttons at the bottom of the screen

-- table to setup buttons
local tabButtons = {
	{ label="", defaultFile="button1.png", overFile="button1-down.png", width = 32, height = 32, onPress=showStage, selected=true },
	{ label="", defaultFile="button2.png", overFile="button2-down.png", width = 32, height = 32, onPress=showGame },
	{ label="", defaultFile="button2.png", overFile="button2-down.png", width = 32, height = 32, onPress=showSupport },
	{ label="", defaultFile="button2.png", overFile="button2-down.png", width = 32, height = 32, onPress=showContact },
}

-- create the actual tabBar widget
local tabBar = widget.newTabBar{
	top = display.contentHeight - 50,	-- 50 is default height for tabBar widget
	buttons = tabButtons
}

--local tabBar = widget.newTabBar(
   -- {
      --  left = 0,
        --top = display.contentHeight-120,
        --width = 580,
        --height = 120,
        --backgroundFile = "tabBarBack.png",
        --tabSelectedLeftFile = "tabBarSelL.png",
        --tabSelectedRightFile = "tabBarSelR.png",
        --tabSelectedMiddleFile = "tabBarSelM.png",
        --tabSelectedFrameWidth = 40,
        --tabSelectedFrameHeight = 120,
        --buttons = tabButtons
    --}
--)

--onFirstView()	-- invoke first tab button's onPress event manually
showStage()

local joystigpad


local JoyStigsheetOptions = {
	width = 200,
	height = 200,
	numFrames = 10,
	sheetContentWidth = 2000,
	sheetContentHeight = 200
}

local  JoyStigcharacterSheet = graphics.newImageSheet( "SPRIT-ControlBT.png", JoyStigsheetOptions )

local JoyStigsequenceData = {
			 -- first sequence (consecutive frames)
    {
        name = "beforestart",
        start = 1,
        count = 10,
        time = 800,
        loopCount = 0
    },
    -- next sequence (non-consecutive frames)
    {
        name = "beforestart2",
        frames = { 1,10 },
        time = 400,
        loopCount = 400
    },
	 {
        name = "frame10",
        start = 10,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame1",
        start = 1,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame2",
        start = 2,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame3",
        start = 3,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame4",
        start = 4,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame5",
        start = 5,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame6",
        start = 6,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame7",
        start = 7,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame8",
        start = 8,
        count = 1,
        time = 800,
        loopCount = 0
    },
	{
        name = "frame9",
        start = 9,
        count = 1,
        time = 800,
        loopCount = 0
    },
		}
		
		local secondsLeft = 1440
		local clockText
		local countDownTimer
		
		local function updateTime( event )
 
    -- Decrement the number of seconds
    secondsLeft = secondsLeft - 1
 
    -- Time is tracked in seconds; convert it to minutes and seconds
    local minutes = math.floor( secondsLeft / 60 )
    local seconds = secondsLeft % 60
 
    -- Make it a formatted string
    local timeDisplay = string.format( "%02d:%02d", minutes, seconds )
     
    -- Update the text object
    clockText.text = timeDisplay
	
	if(secondsLeft == 0) then
		finishdiegame()
	end
	
end
local arrowpads
local gameGroup
local jsk0
local jskup
local jskupright
local jskdownleft
local jskdown
local jskdownright
local jskleft
local jskright
local jsk1
local jskupleft
local lastswippad
local function onObjectTouch( event )
    if ( event.phase == "began" ) then
        --print( "Touch event began on: " .. event.target.id )
		if(event.target.id == "zoomin") then
			common.cameradozoom = "in"
		end
		if(event.target.id == "zoomout") then
			common.cameradozoom = "out"
		end
    elseif ( event.phase == "ended" ) then
        --print( "Touch event ended on: " .. event.target.id )
    end
    return true
end

local hilfegameGroup
local hife1
local hife2
local hife3
local cuhife = 0
local function exithelftoched ( event )
	if (event.phase == "ended") then
	----print( "+++ in pad .. " .. event.phase )
	common.helpfinished = true
	hilfegameGroup.isVisible = false
	--hife2.isVisible = false
	--hife3.isVisible = false
	end
end
local function helftoched ( event )
	if(common.helpfinished == false) then
	----print( "+++ in pad .. " .. event.phase )
	if (event.phase == "ended") then
	if (cuhife == 1) then
		hife1.isVisible = false
		hife2.isVisible = true
	end
	if (cuhife == 2) then
		hife2.isVisible = false
		hife3.isVisible = true
	end
	if (cuhife == 3) then
		hife3.isVisible = false
		hife1.isVisible = true
		cuhife = 0
	end
	
	cuhife = cuhife + 1
	end
	end
end
local function showinhelp()
	cuhife = 1
	hilfegameGroup = display.newGroup()
	hife1 = display.newImage( "hpm1.png" )
	hife1.isVisible = true
	hilfegameGroup:insert( hife1 )
	
	hife2 = display.newImage( "hpm2.png" )
	hife2.isVisible = false
	hilfegameGroup:insert( hife2 )
	
	hife3 = display.newImage( "hpm3.png" )
	hife3.isVisible = false
	hilfegameGroup:insert( hife3 )
	
	local rect = display.newRect(  ( hife1.contentWidth / 3), -1 * ( hife1.contentHeight / 3), 70, 70 )
	rect:setFillColor( 1, 0, 0 )
	rect:addEventListener("touch", exithelftoched)
	rect.alpha = 0.01
	hilfegameGroup:insert( rect )
	
	hilfegameGroup.x = display.contentCenterX-- - arrowpads.contentWidth
	if(display.pixelWidth > (hife1.contentWidth * 2)) then
		hilfegameGroup:scale(2,2)
	end
	hilfegameGroup.y = gameGroup.y - (jsk0.contentHeight * 2)
		
	hilfegameGroup:addEventListener("touch", helftoched)
	common.lastLink = ""
end

local text
local text2
local rects1
local rects2

local function showJoyStig( )
	
common.color1 = "red"
common.color2 = "blue"
common.stra1 = "4-4-2"
common.stra2 = "4-2-3-1"
common.scor1 = "0"
common.scor2 = "0"

	--local secondsLeft = 600  -- 10 minutes * 60 seconds
 
clockText = display.newText( "24:00", display.contentCenterX - (display.contentWidth / 3), 40, native.systemFont, 32 )
clockText:setFillColor( 1,1, 1 )
	
countDownTimer = timer.performWithDelay( 1000, updateTime, secondsLeft )

--local c1Circle = display.newCircle( display.contentCenterX + (display.contentWidth / 3), 60, 30 )
--c1Circle:setFillColor( 0.5 )
--c1Text = display.newText( c1Circle,"0", 10, 10, native.systemFont, 32 )


rects1 = display.newRect( display.contentCenterX + (display.contentWidth / 3), 40, 70, 70 )
rects1:setFillColor( 1, 0, 0 )
text = display.newText( "0", rects1.x, rects1.y, native.systemFont, 32  )
--while( (text.width < rect.width) and ( text.height < rect.height) ) do
    --text.size = text.size + 1
--end
rects2 = display.newRect( display.contentCenterX + (display.contentWidth / 6), 40, 70, 70 )
rects2:setFillColor( 0, 0, 1 )
text2 = display.newText( "0", rects2.x, rects2.y, native.systemFont, 32  )


 text.isVisible = true
 text2.isVisible = true
rects1.isVisible = true
rects2.isVisible = true

local zoominobject = display.newImage( "zoomin.png" )
zoominobject.id = "zoomin"
 zoominobject.x = display.contentCenterX - 70
 zoominobject.y = 70
zoominobject:addEventListener( "touch", onObjectTouch )

local zoomoutobject = display.newImage( "zoomout.png" )
zoomoutobject.id = "zoomout"
 zoomoutobject.x = display.contentCenterX + 70
 zoomoutobject.y = 70
zoomoutobject:addEventListener( "touch", onObjectTouch )


	joystigpad = display.newRect(0, 0, display.contentWidth * 1, 120)
	joystigpad.x = display.contentCenterX
	joystigpad.y = display.contentHeight - joystigpad.contentHeight --- 120
	joystigpad:setFillColor( 0, 0, 0 )
	joystigpad.alpha = 0.0
	
	gameGroup = display.newGroup()
	
	
	--arrowpads = display.newImage( "jsk-0.png" )
	--rect2.isVisible = false
	--gameGroup:insert( arrowpads )
	jsk0 = display.newImage( "jsk-0.png" )
	lastswippad = jsk0
	jsk0.isVisible = true
	gameGroup:insert( jsk0 )
	 jskup = display.newImage( "jsk-up.png" )
	jskup.isVisible = false
	gameGroup:insert( jskup )
	 jskupright = display.newImage( "jsk-up-right.png" )
	jskupright.isVisible = false
	gameGroup:insert( jskupright )
	 jskdownleft = display.newImage( "jsk-down-left.png" )
	jskdownleft.isVisible = false
	gameGroup:insert( jskdownleft )
	 jskdown = display.newImage( "jsk-down.png" )
	jskdown.isVisible = false
	gameGroup:insert( jskdown )
	 jskdownright = display.newImage( "jsk-down-right.png" )
	jskdownright.isVisible = false
	gameGroup:insert( jskdownright )
	 jskleft = display.newImage( "jsk-left.png" )
	jskleft.isVisible = false
	gameGroup:insert( jskleft )
	 jskright = display.newImage( "jsk-right.png" )
	jskright.isVisible = false
	gameGroup:insert( jskright )
	 jsk1 = display.newImage( "jsk-1.png" )
	jsk1.isVisible = false
	gameGroup:insert( jsk1 )
	 jskupleft = display.newImage( "jsk-up-left.png" )
	jskupleft.isVisible = false
	gameGroup:insert( jskupleft )

	
	
	
	gameGroup.x = display.contentCenterX-- - arrowpads.contentWidth
	gameGroup.y = joystigpad.y + 0
		
	gameGroup:addEventListener("touch", padtoched)
	
	local group = display.newGroup()
group.anchorChildren = true
group.anchorY = 0
group.x = display.contentCenterX
group.y = 100--sampleUI.titleBarBottom + 8

	
--	local JoyStig = display.newSprite( gameGroup, JoyStigcharacterSheet, JoyStigsequenceData )
	--JoyStig.x = ( display.actualContentWidth / 2 ) - 100 --0--(display.contentWidth  / 2) - 100
	--JoyStig:setSequence( "beforestart2" )
	--JoyStig.y =  0m.forward.y --display.contentHeight --- JoyStig.contentHeight - 10 -- 0 -- 200 -- 0 -- 210 -- ( display.actualContentHeight ) - 210 --0--display.contentHeight  - 200
	--player:scale( 4,4 )
	--JoyStig.y = 300
	--JoyStig:play()

--gameGroup:insert( JoyStig )
	
end
local lastwipalign = ""
local tochcount = 0

function padtoched ( event )
	----print( "+++ in pad .. " .. event.phase )
	
	local cuswippad = lastswippad

	--if lastwipalign == "" then
		lastwipalign = "1"
		lastswippad = jsk1
	--end

common.jsk = "1"
	
	
	if lastswippad ~= cuswippad then
		cuswippad.isVisible = false
		lastswippad.isVisible = true
		cuswippad = lastswippad
	end

tochcount = tochcount + 1
	
end

menuSwipe = {}
Runtime:addEventListener("touch", menuSwipe)


 local pposdb = ""
 local function loadssposes()
	 	-- Path for the file to read
	local path = system.pathForFile( "posdb.txt")--, system.DocumentsDirectory )
	 
	-- Open the file handle
	local file, errorString = io.open( path, "r" )
	 
	if not file then
	    -- Error occurred; output the cause
	    ----print( "File error: " .. errorString )
	else
	    -- Read data from file
	    local contents = file:read( "*a" )
	    -- Output the file contents
	    ----print( "Contents of " .. path .. "\n" .. contents )
		pposdb = contents
		common.dieposdb = pposdb
	    -- Close the file handle
	    io.close( file )
	end
	 
	file = nil
	common.color1 = "red"
	common.color2 = "blue"
	common.stra1 = "4-4-2"
	common.stra2 = "3-5-2"
	common.scor1 = "0"
	common.scor2 = "0"
	--common.swiplog = {} --common.swiplog[table.getn(common.swiplog)] = xxx
	--common.handlelasttap = false
	common.myplayers[table.getn(common.myplayers) + 1] = "a1"
	common.myplayers[table.getn(common.myplayers) + 1] = "a2"
	common.myplayers[table.getn(common.myplayers) + 1] = "a3"
	common.myplayers[table.getn(common.myplayers) + 1] = "a4"
	common.myplayers[table.getn(common.myplayers) + 1] = "a5"
	common.myplayers[table.getn(common.myplayers) + 1] = "a6"
	common.myplayers[table.getn(common.myplayers) + 1] = "a7"
	common.myplayers[table.getn(common.myplayers) + 1] = "a8"
	common.myplayers[table.getn(common.myplayers) + 1] = "a9"
	common.myplayers[table.getn(common.myplayers) + 1] = "a10"
	common.myplayers[table.getn(common.myplayers) + 1] = "a11"
	--common.ballparent = ""
	common.myplayactif = common.myplayers[table.getn(common.myplayers)]
	common.myside = "a"
	common.ballonme = false
	
	--print("***table.getn(common.myplayers) 0000 = " .. table.getn(common.myplayers))

 end
 	
function menuSwipe:touch( event )	
	local cuswippad = lastswippad
	
	--print( "=================toch occurd - " .. event.phase )
	
	--if tochcount < 3 then
	--do return end
	--end 
	
	if(event.phase == "began") then
		
	end
	if(event.phase == "ended") then
		lastwipalign = "0"
		lastswippad = jsk0
		common.jsk = "0"
		if lastswippad ~= cuswippad then
			cuswippad.isVisible = false
			lastswippad.isVisible = true
			cuswippad = lastswippad
		end
		--common.gamestart = false
		--common.swiplog = {} --common.swiplog[table.getn(common.swiplog)] = xxx
		common.handlelasttap = true
	end
	if(event.phase == "moved") then
	
	if event.xStart < event.x then		
		lastwipalign = "-right"
		lastswippad = jskright
		if event.yStart < event.y then		
			lastwipalign = "-down-right"
			lastswippad = jskdownright
		elseif event.yStart > event.y then		
			lastwipalign = "-up-right"
			lastswippad = jskupright
		end
	elseif event.xStart > event.x then		
		lastwipalign = "-left"
		lastswippad = jskleft
		if event.yStart < event.y then		
			lastwipalign = "-down-left"
			lastswippad = jskdownleft
		elseif event.yStart > event.y then		
			lastwipalign = "-up-left"
			lastswippad = jskupleft
		end
	elseif event.xStart == event.x then
		if event.yStart < event.y then		
			lastwipalign = "-down"
			lastswippad = jskright
		elseif event.yStart > event.y then		
			lastwipalign = "-up"
			lastswippad = jskup
		end
	end
	
	
	local xdef = event.xStart - event.x
	local ydef = event.yStart - event.y
	
	if (xdef > 0) then
		if(math.abs(ydef)<50) then
			--if xdef < 50 then
				lastswippad = jskleft
			--end 
		end	
	end
	if (xdef < 0) then
		if(math.abs(ydef)<50) then
			--if xdef < 50 then
				lastswippad = jskright
			--end 
		end
	end
	
	if (ydef > 0) then
		if(math.abs(xdef)<50) then
			--if xdef < 50 then
				lastswippad = jskup
			--end 
		end	
	end
	if (ydef < 0) then
		if(math.abs(xdef)<50) then
			--if xdef < 50 then
				lastswippad = jskdown
			--end 
		end
	end
	
	----print("***lastwipalign = " .. lastwipalign)
	if lastswippad ~= cuswippad then
		cuswippad.isVisible = false
		lastswippad.isVisible = true
		cuswippad = lastswippad
	end
	
	
	if( cuswippad ==  jsk0) then
		common.jsk = "0"
	end
	
	
if( cuswippad == jskup) then
		common.jsk = "up"
	end
if( cuswippad == jskupright) then
		common.jsk = "upright"
	end
if( cuswippad == jskdownleft) then
		common.jsk = "downleft"
	end
if( cuswippad == jskdown) then
		common.jsk = "down"
	end
if( cuswippad == jskdownright) then
		common.jsk = "downright"
	end
if( cuswippad ==  jskleft) then
		common.jsk = "left"
	end
if( cuswippad == jskright) then
		common.jsk = "right"
	end
if( cuswippad == jsk1) then
		common.jsk = "1"
	end
if( cuswippad == jskupleft) then
		common.jsk = "upleft"
	end
	
	common.swiplog[table.getn(common.swiplog)] = common.jsk
	
end
	
end


local function tab2front(  )
	tabBar:toBack()
	
	if( common.inGame == true ) then
		
	end
if ( common.lastLink == "inlinehelp" ) then
	showinhelp()
end
	----print( "tab********* " .. common.totalTreasures )
	if ( common.lastLink == "game" ) then
		loadssposes()
		showGame()
		common.inGame = true
		showJoyStig( )
		tochcount = 0
		
	end
	if ( common.lastLink == "help" ) then
		--showContact()
	end
	if ( common.lastLink == "support" ) then
		--showSupport()
	end
	if ( common.lastLink == "stage" ) then
		showStage()
	end
	if ( common.inPaus == true ) then
		objpaus:toFront()
	elseif true then
		objpaus:toBack()
	end
	
	if ( common.webView == "wb1" ) then
		common.webView = ""
		local webView = native.newWebView( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )
		webView:request( "http://fotbal.party" )
		webView:addEventListener( "urlRequest", webListener )
		webView:toBack()
		webView.isVisible = false
	end
	if ( common.webView == "wb2" ) then
		common.webView = ""
		local webView2 = native.newWebView( display.contentCenterX, display.contentCenterY, display.contentWidth, display.contentHeight )
		webView2:request( "http://maxim.shop" )  
		webView2:addEventListener( "urlRequest", webListener )
		webView2:toBack()
		webView2.isVisible = false	
	end

	if (common.jaok > 0) then
	
		if(common.jaok == 1) then
			common.balevent = "float"
		end
		if(common.jaok == 2) then
			common.balevent = "pass"
		end
		if(common.jaok == 3) then
			common.balevent = "shot"
		end
		if(common.jaok == 4) then
			common.balevent = "longshot"
		end
		
	end
	
	if(common.isgole == true) then
		gameGroup.isVisible = false
		--JoyStigcharacterSheet.isVisible = false
		common.isgole = false
		timer.pause( countDownTimer )
--timer.resume( countDownTimer )
		showSupport()
		text.text = common.scor1
		text2.text = common.scor2
	end

	if(common.back2game == true) then
		gameGroup.isVisible = true
		--JoyStigcharacterSheet.isVisible = true
		common.back2game = false
		showGame()
		--timer.pause( countDownTimer )
		timer.resume( countDownTimer )
		--showSupport()
	end
	
	if(common.back2stag == true) then
		common.back2stag = false
				
		 text:removeSelf()-- = false
		 text2:removeSelf()--.isVisible = false
		 rects1:removeSelf()--.isVisible = false
		 rects2:removeSelf()--.isVisible = false
		 clockText:removeSelf()
		 secondsLeft = 1440
		  
		showStage()
	end
	
end
tabBar.isVisible = false	
timer.performWithDelay(400, tab2front, -1) 


