-----------------------------------------------------------------------------------------
--
-- view2.lua
--
-----------------------------------------------------------------------------------------

local composer = require( "composer" )
local common = require("common")
local scene = composer.newScene()

require( "tilebg" ) --load the function
local bg = tileBG() --a

local maxH = math.ceil ( display.contentHeight / 4 )
local maxW = math.ceil ( display.contentWidth / 5 )
local ySpace = math.ceil ( maxH / 3 )
--local bkg0 = display.newImage( "FotbalParty.png", centerX, centerY, true )
--bkg0.x = display.contentCenterX
--bkg0.y = bkg0.height / 2--display.contentCenterY
--rect1.width . height , x , y
--object:scale( xScale, yScale )

local lastY = ySpace --* 2

local bkg1 = display.newImage( "game-fa-1.png", centerX, centerY, true )
local bkg2 = display.newImage( "support-fa-1.png", centerX, centerY, true )
local bkg3 = display.newImage( "help-fa-1.png", centerX, centerY, true )
local bkg2B = display.newImage( "support-fa-2.png", centerX, centerY, true )
local bkg1B = display.newImage( "game-fa-2.png", centerX, centerY, true )
local bkg3B = display.newImage( "help-fa-2.png", centerX, centerY, true )
	
if ( bkg1.height > maxH ) then
	bkg1.width = maxH
	bkg1.height = maxH
end
bkg1.x = display.contentCenterX
bkg1.y =  ySpace * 2
lastY = lastY + math.ceil ( bkg1.height / 2 ) + ( ySpace * 2 )
bkg1B.x = bkg1.x
bkg1B.y = bkg1.y
bkg1B.width = bkg1.width
bkg1B.height = bkg1.height
	


if ( bkg2.height > maxH ) then
	bkg2.width = maxH
	bkg2.height = maxH
end
bkg2.x = display.contentCenterX
bkg2.y = lastY + ySpace
lastY = lastY + math.ceil ( bkg2.height / 2 ) + ( ySpace * 2 )
bkg2B.x = bkg2.x
	bkg2B.y = bkg2.y
	bkg2B.width = bkg2.width
	bkg2B.height = bkg2.height
	

if ( bkg3.height > maxH ) then
	bkg3.width = maxH
	bkg3.height = maxH
end
bkg3.x = display.contentCenterX
bkg3.y = lastY + ySpace
lastY = lastY + math.ceil ( bkg3.height / 2 ) + ( ySpace * 2 )
	bkg3B.x = bkg3.x
	bkg3B.y = bkg3.y
	bkg3B.width = bkg3.width
	bkg3B.height = bkg3.height



local centerX = display.contentCenterX
local centerY = display.contentCenterY
local _W = display.contentWidth
local _H = display.contentHeight


local screenW = display.contentWidth - display.screenOriginX
local screenH = display.contentHeight - display.screenOriginY
local friction1 = 0.8
local gravity1 = 0.098


local speedX1, speedY1, prevX1, prevY1, lastTime1, prevTime1 = 0, 0, 0, 0, 0, 0


local ball1 = display.newImage( "ball-1.png")
if ( ball1.width > maxW ) then
	ball1.width = maxW
	ball1.height = maxW
end

ball1:toBack()


local function onMoveBall1( event )

	local timePassed = event.time - lastTime1
	lastTime1 = lastTime1 + timePassed

	speedY1 = speedY1 + gravity1

	ball1.x = ball1.x + ( speedX1 * timePassed )
	ball1.y = ball1.y + ( speedY1 * timePassed )

	if ( ball1.x >= screenW - ( ball1.width * 0.5 ) ) then
		ball1.x = screenW - ( ball1.width * 0.5 )
		speedX1 = speedX1 * friction1
		speedX1 = speedX1 * -1  -- Change direction
	elseif ( ball1.x <= display.screenOriginX + ( ball1.width * 0.5 ) ) then
	    ball1.x = display.screenOriginX + ( ball1.width * 0.5 )
		speedX1 = speedX1 * friction1
		speedX1 = speedX1 * -1  -- Change direction
	end

	if ( ball1.y >= screenH - ( ball1.height * 0.5 ) ) then
		ball1.y = screenH - ( ball1.height * 0.5 )
		speedY1 = speedY1 * friction1
		speedX1 = speedX1 * friction1
		speedY1 = speedY1 * -1  -- Change direction
	elseif ( ball1.y <= display.screenOriginY + ( ball1.height * 0.5 ) ) then
		ball1.y = display.screenOriginY + ( ball1.height * 0.5 )
		speedY1 = speedY1 * friction1
		speedY1 = speedY1 * -1  -- Change direction
	end
end

-- Function to track velocity (for fling)
local function trackVelocity1( event )

	local timePassed = event.time - prevTime1
	prevTime1 = prevTime1 + timePassed
	speedX1 = ( ball1.x - prevX1 ) / timePassed
	speedY1 = ( ball1.y - prevY1 ) / timePassed
	prevX1 = ball1.x
	prevY1 = ball1.y
end

local function bkg1Toch( event )
	
	bkg1B.isVisible = true
	bkg1.isVisible = false
	common.lastLink = "game"
	
end
local function bkg2Toch( event )

	bkg2B.isVisible = true
	bkg2.isVisible = false
	common.lastLink = "support"
	
end
local function bkg3Toch( event )
	
	bkg3B.isVisible = true
	bkg3.isVisible = false
common.lastLink = "help"

	
end

-- General function for dragging objects
local function startDrag1( event )

	local t = event.target
	local phase = event.phase

	if ( "began" == phase ) then

		-- Set touch focus on ball
		display.currentStage:setFocus( t )
		t.isFocus = true

		-- Store initial touch position
		t.x0 = event.x - t.x
		t.y0 = event.y - t.y

		-- Stop ball's current motion, if any
		Runtime:removeEventListener( "enterFrame", onMoveBall1 )
		-- Start tracking velocity
		Runtime:addEventListener( "enterFrame", trackVelocity1 )

	elseif ( t.isFocus ) then

		if ( "moved" == phase ) then

			t.x = event.x - t.x0
			t.y = event.y - t.y0

			-- Force pseudo-touch of "ended" if ball is dragged past any screen edge
			if ( ( t.x > screenW - ( t.width * 0.5 ) ) or
				 ( t.x < display.screenOriginX + ( t.width * 0.5 ) ) or
				 ( t.y > screenH - ( t.height * 0.5 ) ) or
				 ( t.y < display.screenOriginY + ( t.height * 0.5 ) )
			) then
				t:dispatchEvent( { name="touch", phase="ended", target=t, time=event.time } )
			end

		elseif ( "ended" == phase or "cancelled" == phase ) then

			lastTime = event.time

			-- Stop tracking velocity
			Runtime:removeEventListener( "enterFrame", trackVelocity1 )
			-- Start ball's motion
			Runtime:addEventListener( "enterFrame", onMoveBall1 )

			-- Release touch focus from ball
			display.currentStage:setFocus( nil )
			t.isFocus = false
		end
	end
	return true
end

-- Resize event handler
local function onResizeEvent1( event )

	screenW = display.contentWidth - display.screenOriginX
	screenH = display.contentHeight - display.screenOriginY

	--msg.x = display.contentCenterX
	--msg.y = 55 + display.screenOriginY

	-- Reset ball location to center of the screen
	ball1.x = display.contentCenterX
	ball1.y = display.contentCenterY
end






function scene:create( event )
	local sceneGroup = self.view
	
	print( "****** " .. display.contentWidth )
--	local images = {"a1","a2","a3"}

	--
	bkg1:addEventListener( "touch", bkg1Toch )
	bkg2:addEventListener( "touch", bkg2Toch )
	bkg3:addEventListener( "touch", bkg3Toch )
	--sceneGroup:insert( bkg0 )
	sceneGroup:insert( bkg1 )
	sceneGroup:insert( bkg2 )
	sceneGroup:insert( bkg3 )
	
	
	
Runtime:addEventListener( "resize", onResizeEvent1 )
Runtime:addEventListener( "enterFrame", onMoveBall1 )
ball1:addEventListener( "touch", startDrag1 )
sceneGroup:insert( ball1 )


	
end

function scene:show( event )
	local sceneGroup = self.view
	local phase = event.phase
	
	bkg1B.isVisible = false
	bkg1.isVisible = true

	bkg2B.isVisible = false
	bkg2.isVisible = true

	bkg3B.isVisible = false
	bkg3.isVisible = true
	
	ball1:toFront()

	if phase == "will" then
		-- Called when the scene is still off screen and is about to move on screen
	elseif phase == "did" then
		-- Called when the scene is now on screen
		-- 
		-- INSERT code here to make the scene come alive
		-- e.g. start timers, begin animation, play audio, etc.
	end	
end

function scene:hide( event )
	local sceneGroup = self.view
	local phase = event.phase
	

	
	if event.phase == "will" then
		-- Called when the scene is on screen and is about to move off screen
		--
		-- INSERT code here to pause the scene
		-- e.g. stop timers, stop animation, unload sounds, etc.)
	elseif phase == "did" then
		-- Called when the scene is now off screen
			bkg1B.isVisible = false
	bkg1.isVisible = false

	bkg2B.isVisible = false
	bkg2.isVisible = false

	bkg3B.isVisible = false
	bkg3.isVisible = false
	end
end

function scene:destroy( event )
	local sceneGroup = self.view
	
	-- Called prior to the removal of scene's "view" (sceneGroup)
	-- 
	-- INSERT code here to cleanup the scene
	-- e.g. remove display objects, remove touch listeners, save state, etc.
end

---------------------------------------------------------------------------------

-- Listener setup
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

-----------------------------------------------------------------------------------------

return scene
