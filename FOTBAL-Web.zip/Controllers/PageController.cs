﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MXFootBall.Controllers
{
    public class PageController : Controller
    {
        // GET: Page
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Start()
        {
            return View();
        }
        public ActionResult Game()
        {
            return View();
        }
        public ActionResult Intro()
        {
            return View();
        }
        public ActionResult appFa()
        {
            return View();
        }
        public ActionResult appEn()
        {
            return View();
        }
        public ActionResult Intro2()
        {
            return View();
        }
        public ActionResult Recorder()
        {
            return View();
        }
        public ActionResult Intro3()
        {
            return View();
        }
        public ActionResult IranAir()
        {
            return View();
        }
    }
}