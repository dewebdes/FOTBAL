﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using PagedList;

namespace MXFootBall.Controllers
{
    [ActionFilters]
    public class ShellController : Controller
    {
        public Dictionary<string, string> nc = new Dictionary<string, string>();
        public string query = "";
        public string qret = "";
        public string resell = System.Configuration.ConfigurationManager.AppSettings["resell"].ToString();
        public string BaseHost = System.Configuration.ConfigurationManager.AppSettings["BaseHost"].ToString();
        public string AdminSecret = System.Configuration.ConfigurationManager.AppSettings["AdminSecret"].ToString();
        public AppHelper aph = new AppHelper();
        public BST_PublicHelper.PubFuncs pf = new BST_PublicHelper.PubFuncs();



        public ActionResult reset()
        {
            return View();
        }

        void runSetup(string[] rp)
        {
            ////pf.cleanLog();
            var csec = rp[0].Trim();
            ////pf.SaveLog("runsetup");
            if (csec == AdminSecret)
            {
                //cmd="setup"
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "setup");
                ////pf.SaveLog("send form");
                ViewBag.outp = aph.sendForm(nc);
                ////pf.SaveLog(ViewBag.outp);
            }
        }
        void runSetup2(string[] rp)
        {
            ////pf.cleanLog();
            var csec = rp[0].Trim();
            ////pf.SaveLog("runsetup2");
            if (csec == AdminSecret)
            {
                //cmd="setup"
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "setup2");
                ////pf.SaveLog("send form");
                ViewBag.outp = aph.sendForm(nc);
                ////pf.SaveLog(ViewBag.outp);
            }
        }
        void doAddUser(string[] rp)
        {
            //////pf.cleanLog();
            var usn = rp[0].Trim().ToLower();
            var pss = rp[1].Trim();
            var mail = rp[2].Trim();
            var fname = rp[3].Trim();
            var lname = rp[4].Trim();
            var mob = rp[5].Trim();
            var cdate = DateTime.Now.ToString();

            var usl = aph.getUsersList();
            var exi = aph.canAddUser(usn);
            //if (pf.canSeekL<MaxReseller.Models.user>(usl))
            //{
            //    exi = usl.Where(a => (a.usn.ToLower() == usn.ToLower()) || (a.mail.ToLower() == mail.ToLower())).Any();
            //}
            if (exi == false)
            {
                ViewBag.outp = "userExist";
            }
            else
            {
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                //nc.Add("sid", "0");
                query = "";
                query = "insert into wp_Users (usn,pss,mail,fname,lname,mob,cdate) values(#sq#" + usn + "#sq#,#sq#" + pss + "#sq#,#sq#" + mail + "#sq#,#sq#" + fname + "#sq#,#sq#" + lname + "#sq#,#sq#" + mob + "#sq#,#sq#" + cdate + "#sq#)";

                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ////////pf.SaveLog(qret);
                ViewBag.outp = "userAdd";
            }

        }
        void doAddSite(string[] rp)
        {
            //////pf.cleanLog();
            var sub = rp[0].Trim().ToLower();
            var dm = rp[1].Trim().ToLower();
            var usr = rp[2].Trim().ToLower();
            var pak = rp[3].Trim().ToLower();
            var cdate2 = DateTime.Now.ToString();

            var ssl = aph.getSitesList();
            var exi2 = false;
            if (pf.canSeekL<MaxReseller.Models.site>(ssl))
            {
                exi2 = ssl.Where(a => (a.sub.ToLower() == sub.ToLower()) || ((!String.IsNullOrEmpty(dm)) && (a.dm.ToLower() == dm.ToLower()))).Any();
            }
            if (exi2 == true)
            {
                ViewBag.outp = "siteExist";
            }
            else
            {
                var dieUs = aph.getSingleUser(usr);

                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                ////nc.Add("sid", "0");
                query = "";
                query = "insert into wp_Sites (sub,dm,usr,cdate,pak) values(#sq#" + sub + "#sq#,#sq#" + dm + "#sq#,#sq#" + usr + "#sq#,#sq#" + cdate2 + "#sq#,#sq#" + pak + "#sq#)";

                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ////////pf.SaveLog(qret);

                //---- add site admin
                var dieSite = aph.getSingleSite(sub, dm);
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                ////nc.Add("sid", "0");
                query = "";
                query = "insert into wp_SiteAdmins (sid,usid,usn,pss,rol,cdate,fullname,mail,mob) values("
                    + sid + "," + dieUs.id + ",#sq#" + usr + "#sq#"
                    + ",#sq#" + "" + "#sq#,#sq#" + "superAdmin" + "#sq#"
                    + ",#sq#" + cdate2 + "#sq#,#sq##sq#,#sq##sq#,#sq##sq#)";


                nc.Add("query", query);
                qret += Environment.NewLine + aph.sendForm(nc);
                //--=---

                //---------------HOST--
                System.IO.Directory.CreateDirectory(BaseHost + sid);
                System.IO.Directory.CreateDirectory(BaseHost + sid + @"\" + "up");

                //---------------

                ViewBag.outp = "siteAdd";
            }

        }
        void doLoginResell(string[] rp)
        {
            //////pf.cleanLog();
            var usn1 = rp[0].Trim();
            var pss1 = rp[1].Trim();

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            //nc.Add("sid", "0");
            query = "";
            query = "select * from wp_Users where (usn=#sq#" + usn1 + "#sq#) and (pss=#sq#" + pss1 + "#sq#)";

            nc.Add("query", query);
            qret = aph.sendForm(nc);
            ////////pf.SaveLog("a : "+qret);
            if (qret == "bug")
            {
                ////////pf.SaveLog("err 1");
                ViewBag.outp = "badInfo";
            }
            else
            {
                try
                {
                    var tus = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.user>>(qret).First();
                    if (tus != null)
                    {
                        ViewBag.outp = "loginOk";
                        Session["user"] = usn1;
                    }
                    else
                    {
                        ////////pf.SaveLog("err 2");
                        ViewBag.outp = "badInfo";
                    }
                }
                catch
                {
                    ////////pf.SaveLog("err 3");
                    ViewBag.outp = "badInfo";
                }
            }

        }
        void doLoginPanel(string[] rp)
        {
            //////pf.cleanLog();
            var usn2 = rp[0].Trim().ToLower();
            var pss2 = rp[1].Trim();
            var sdm = rp[2].Trim().ToLower();

            var dieSite = new MaxReseller.Models.site();

            Int64? sid = 0;
            try
            {
                var tsub = "";
                var tdm = "";
                if (sdm.ToLower().Contains(resell.ToLower()))
                {
                    tsub = sdm.ToLower().Replace(resell.ToLower(), "").Replace(".", "");
                }
                else
                {
                    tsub = sdm.ToLower();
                    tdm = sdm.ToLower();
                }
                //////pf.SaveLog("tdm : " + tdm + " , tsub : " + tsub);
                dieSite = aph.getSingleSite(tsub, tdm);
                sid = Convert.ToInt64(sid);
                if (sid == null)
                {
                    sid = 0;
                }
            }
            catch
            {
                sid = 0;
            }
            if (sid > 0)
            {

                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                //nc.Add("sid", "0");
                query = "";
                query = "select * from wp_SiteAdmins where (usn=N#sq#" + usn2 + "#sq#) and (sid=" + sid + ")";

                nc.Add("query", query);
                qret = aph.sendForm(nc);
                ////////pf.SaveLog(qret);
                if (qret == "bug")
                {
                    //////pf.SaveLog("err 1");

                    ViewBag.outp = "badInfo";
                }
                else
                {
                    try
                    {
                        var tadmin = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.siteAdmin>>(qret).First();
                        if (tadmin != null)
                        {
                            ViewBag.outp = "loginOk";
                            var dieAdmin = new MaxReseller.Models.admin();

                            dieAdmin.DieAdmin = tadmin;
                            dieAdmin.DieSite = dieSite;

                            if (tadmin.usid == "0")
                            {
                                if (tadmin.pss == pss2)
                                {
                                    dieAdmin.DieUser = null;
                                }
                                else
                                {
                                    ViewBag.outp = "badInfo";
                                    //////pf.SaveLog("err 2");

                                }
                            }
                            else
                            {
                                var dieUser = aph.getSingleUser(usn2);
                                if (dieUser.pss == pss2)
                                {
                                    dieAdmin.DieUser = dieUser;
                                }
                                else
                                {
                                    ViewBag.outp = "badInfo";
                                    //////pf.SaveLog("err 3");

                                }
                            }

                            if (ViewBag.outp == "loginOk")
                            {
                                Session["cuAdmin"] = dieAdmin;
                            }
                        }
                        else
                        {
                            ViewBag.outp = "badInfo";
                            //////pf.SaveLog("err 4");

                        }
                    }
                    catch
                    {
                        ViewBag.outp = "badInfo";
                        //////pf.SaveLog("err 5");

                    }
                }
            }
            else
            {
                ViewBag.outp = "badInfo";
                //////pf.SaveLog("err 6");

            }
        }

        void doAddPak(string[] rp)
        {
            var csec = rp[0].Trim();
            //////pf.SaveLog("runsetup");
            if (csec == AdminSecret)
            {

                //////pf.cleanLog();
                var name = rp[1].Trim();
                var bsid = rp[2].Trim();
                var cdate = DateTime.Now.ToString();

                var usl = aph.getPaksList();
                var exi = false;
                var tpak = new MaxReseller.Models.pak();
                if (pf.canSeekL<MaxReseller.Models.pak>(usl))
                {
                    var tpk = usl.Where(a => (a.name.ToLower() == name.ToLower()));//.Any();
                    exi = tpk.Any();
                    try
                    {
                        tpak = tpk.First();
                    }
                    catch { }
                }
                if (exi == true)
                {
                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    //nc.Add("sid", "0");
                    query = "";
                    query = "update wp_Paks set name=#sq#" + name + "#sq#,bsid=" + bsid + ",Date=#sq#" + cdate + "#sq# where id=" + tpak.id;

                    nc.Add("query", query);
                    qret = aph.sendForm(nc);
                    ////////pf.SaveLog(qret);
                    ViewBag.outp = "pakUpdate";
                }
                else
                {
                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    //nc.Add("sid", "0");
                    query = "";
                    query = "insert into wp_Paks (name,bsid,Date) values(#sq#" + name + "#sq#," + bsid + ",#sq#" + cdate + "#sq#)";

                    nc.Add("query", query);
                    qret = aph.sendForm(nc);
                    ////////pf.SaveLog(qret);
                    ViewBag.outp = "pakAdd";
                }
            }
        }

        void doRegisterRequest(string[] rp)
        {
            var usn = rp[0].Trim().ToLower();
            var pss = rp[1].Trim();
            var fname = rp[2].Trim();
            var lname = rp[3].Trim();
            var mob = rp[4].Trim();

            var startSiteId = System.Configuration.ConfigurationManager.AppSettings["startSiteId"].ToString();


            query = "";
            query = "select * from wp_RegisterRequestsTbl where (sid=" + startSiteId + ") and (dieUserName=#sq#" + usn + "#sq#)";
            nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            nc.Add("query", query);
            qret = aph.sendForm(nc);
            if (qret == "bug")
            {
                ViewBag.outp = "badInfo";
            }
            else
            {
                var tus = new List<MaxReseller.Models.unknown>();

                try
                {
                    tus = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.unknown>>(qret);//.First();
                }
                catch { }
                if (tus.Count()>0)
                {
                    pf.SaveLog("**************** us1: " + tus[0].id);
                    ViewBag.outp = "exist";
                }
                else
                {
                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "RunQuery");
                    query = "";
                    query = "insert into wp_RegisterRequestsTbl (sid,dieDate,dieUserAgent,dieUserName,diePassword,dieFullName,dieMobile,dieStatus) values(";
                    query += startSiteId + ",";
                    query += "#sq#" + DateTime.Now.ToString() + "#sq#,";
                    var userAgent = Request.UserAgent + Environment.NewLine + Newtonsoft.Json.JsonConvert.SerializeObject(Request.Browser);
                    //userAgent
                    query += "#sq#" + pf.js_scape(userAgent) + "#sq#,";
                    query += "#sq#" + usn + "#sq#,";
                    query += "#sq#" + pss + "#sq#,";
                    query += "#sq#" + fname + " " + lname + "#sq#,";
                    query += "#sq#" + mob + "#sq#,";
                    query += "1)";
                    //////pf.SaveLog("qw : " + query);
                    nc.Add("query", query);
                    qret = aph.sendForm(nc);
                    //////pf.SaveLog("qret : " + qret);
                    if (qret == "bug")
                    {
                        ViewBag.outp = "badInfo";
                    }
                    else
                    {
                        Session["canEditRegister"] = "y";
                        ViewBag.outp = "Add";
                    }
                }
            }

        }



        //---------------------------------- ads ------------------------------

        void updateAdsVisit(string[] rp)
        {

            var id = rp[0];

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");

            query = "update wp_AdsTbl set dieVisitCount=dieVisitCount+1 where id=" + id;

            nc.Add("query", query);
            qret = aph.sendForm(nc);
            ViewBag.outp = "updateOk";

        }

        void updateAdsScore(string[] rp)
        {
            var id = rp[0];
            var score = rp[1];

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            query = "update wp_AdsTbl set dieVisitTicks=dieVisitTicks+" + score + " where id=" + id;

            nc.Add("query", query);
            qret = aph.sendForm(nc);
            ViewBag.outp = "updateOk";


        }
        void testExternalAjax()
        {

            ViewBag.outp = Request.UrlReferrer.AbsolutePath + " call external ajax Ok";


        }

        void saveConfigs(string[] rp)
        {
            //myConf.color + "#newitem#" + myConf.room;
            var myConf_color = rp[0];
            var myConf_room = rp[1];

            Session["myConf_color"] = myConf_color;
            Session["myConf_room"] = myConf_room;


            ViewBag.outp = "updateOk";
        }
        void getConfigs(string[] rp)
        {

            var myConf_cmd = rp[0];
            Session["myConf_cmd"] = myConf_cmd;

            var cnf = new MaxFotBal.Models.config();
            cnf.color = Session["myConf_color"].ToString();
            cnf.room = Session["myConf_room"].ToString();


            cnf.dieBallX = Convert.ToInt32(HttpContext.Application["dieBallX"]);
            cnf.dieBallY = Convert.ToInt32(HttpContext.Application["dieBallY"]);


            var outp = Newtonsoft.Json.JsonConvert.SerializeObject(cnf);

            ViewBag.outp = outp;
        }

        void getuscommandlist(string[] rp)
        {
            var res0 = "";
            var res3 = "";
            var stat = 0;
            try
            {
                /*
                 $('#gm4html5_div_id').scrollLeft(2128 - (parseInt(ww / 2)));$('#gm4html5_div_id').scrollTop(2850 - (parseInt(wh / 2)));
                 */
                stat = 1;

                var apbpos = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"];
                var ballPos = (MaxFotBal.Models.posConfig)apbpos;

                stat = 2;

                ViewBag.gid = Session["myConf_GID"].ToString();
                ViewBag.ballX = ballPos.x;
                ViewBag.ballY = ballPos.y;
                ViewBag.outp = "setballpos";// "$('#gm4html5_div_id').scrollLeft(" + ballPos.x + " - (parseInt(ww / 2)));$('#gm4html5_div_id').scrollTop(" + ballPos.y + " - (parseInt(wh / 2)));";

                stat = 3;

                ViewBag.gres = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_result"].ToString();
                stat = 4;
                ViewBag.fin = "n";

                try
                {
                    var rem = 0;
                    var startt = (DateTime)System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_startDateTime"];
                    stat = 5;

                    rem = (DateTime.Now - startt).Seconds;
                    ViewBag.fin = "n";
                    stat = 6;

                    if (rem >= 15)
                    {
                        ViewBag.fin = "y";
                    }

                    stat = 7;
                }
                catch { }

                res0 = ViewBag.gid + "," + ViewBag.ballX + "," + ViewBag.ballY + "," + ViewBag.gres + "," + ViewBag.fin;

            }
            catch {
                //pf.SaveLog("******************* EROOR : " + stat);
                res0 = "nullx";
            }
            ////pf.SaveLog("***** start");

            ////pf.SaveLog("***** res0: " + res0);
            try
            {
                var res2 = "";
                var cupls = (List<MaxFotBal.Models.playerConfig>)HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];
                foreach (var i in cupls)
                {
                    var xpos = Convert.ToInt32(i.pos.x);
                    var ypos = Convert.ToInt32(i.pos.y);

                    var basX = 4275;
                    var basY = 5700;

                    var newX = 320;
                    var newY = 569;

                    var newx = Convert.ToInt32((xpos * 320) / 4275);
                    var newy = Convert.ToInt32((ypos * 569) / 5700);

                    var newxBall = Convert.ToInt32((Convert.ToInt32(ViewBag.ballX) * 320) / 4275);
                    var newyBall = Convert.ToInt32((Convert.ToInt32(ViewBag.ballY) * 569) / 5700);
                    //res3 = (newxBall + "," + newyBall);
                    res3 = (ViewBag.ballX + "," + ViewBag.ballY);

                    //res2 += i.color + "," + newx + "," + newy + "," + i.number + "-";
                    res2 += i.color + "," + i.pos.x + "," + i.pos.y + "," + i.number + "," + i.pos.f + "," + i.speedPowwer + "," + i.showMod + "#";

                    if ((i.color == Session["myConf_color"].ToString()) && (i.number == Session["myConf_number"].ToString()))
                    {
                        //pf.SaveLog("+++++++++++++++++++++++" + newx + "," + newy);
                    }

                }

                //pf.SaveLog("***** res2: " + res2);
                //Session["myConf_ballParent"]
                //System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"];
                var ballparent = HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"].ToString();//.tos

                var newCommandor = "";
                var indx = Convert.ToInt32(Session["lastCommandorIndex"]);
                var commandors = (List<string>)HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_Commandor"];
                for(var i = indx; i <= commandors.Count() - 1; i++)
                {
                    newCommandor += commandors[i] + "#";
                }
                Session["lastCommandorIndex"] = commandors.Count().ToString();

                var resF = res0 + "nnpp" + res2 + "nnpp" + res3 + "nnpp" + ballparent + "nnpp" + newCommandor;
                //pf.SaveLog("***** resF: " + resF);
                ViewBag.resF = resF;
            }
            catch
            {
                ViewBag.resF = "";
            }
        }
        void getuscommandlistRecord(string[] rp)
        {
            //insert into wp_fprRecorder (sid,gid,dieSecond,playerListStr,ballPos,dieResult,dieEvent,dieActor,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,6,10,#sq#playersStatus#sq#,#sq#200*300#sq#,#sq#resultStatus#sq#,#sq#eventsStatus#sq#,#sq#actorsStatus#sq#,0,0,1,0,0)
            //PlayBackGame.html
            //Play/DieGamePlayBack?id=gid

            var res0 = "";
            var stat = 0;
            try
            {
                /*
                 $('#gm4html5_div_id').scrollLeft(2128 - (parseInt(ww / 2)));$('#gm4html5_div_id').scrollTop(2850 - (parseInt(wh / 2)));
                 */
                stat = 1;

                var apbpos = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"];
                var ballPos = (MaxFotBal.Models.posConfig)apbpos;

                stat = 2;

                ViewBag.gid = Session["myConf_GID"].ToString();
                ViewBag.ballX = ballPos.x;
                ViewBag.ballY = ballPos.y;
                ViewBag.outp = "setballpos";// "$('#gm4html5_div_id').scrollLeft(" + ballPos.x + " - (parseInt(ww / 2)));$('#gm4html5_div_id').scrollTop(" + ballPos.y + " - (parseInt(wh / 2)));";

                stat = 3;

                ViewBag.gres = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_result"].ToString();
                stat = 4;
                ViewBag.fin = "n";

                try
                {
                    var rem = 0;
                    var startt = (DateTime)System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_startDateTime"];
                    stat = 5;

                    rem = (DateTime.Now - startt).Seconds;
                    ViewBag.fin = "n";
                    stat = 6;

                    if (rem >= 15)
                    {
                        ViewBag.fin = "y";
                    }

                    stat = 7;
                }
                catch { }

                res0 = ViewBag.gid + "," + ViewBag.ballX + "," + ViewBag.ballY + "," + ViewBag.gres + "," + ViewBag.fin;

            }
            catch
            {
                //pf.SaveLog("******************* EROOR : " + stat);
                res0 = "nullx";
            }
            ////pf.SaveLog("***** start");

            ////pf.SaveLog("***** res0: " + res0);
            try
            {
                var res2 = "";
                var cupls = (List<MaxFotBal.Models.playerConfig>)HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];
                foreach (var i in cupls)
                {
                    var xpos = Convert.ToInt32(i.pos.x);
                    var ypos = Convert.ToInt32(i.pos.y);

                    var basX = 4275;
                    var basY = 5700;

                    var newX = 320;
                    var newY = 569;

                    var newx = Convert.ToInt32((xpos * 320) / 4275);
                    var newy = Convert.ToInt32((ypos * 569) / 5700);

                    res2 += i.color + "," + newx + "," + newy + "," + i.number + "-";

                    if ((i.color == Session["myConf_color"].ToString()) && (i.number == Session["myConf_number"].ToString()))
                    {
                        //pf.SaveLog("+++++++++++++++++++++++" + newx + "," + newy);
                    }

                }
                //pf.SaveLog("***** res2: " + res2);

                var resF = res0 + "nnpp" + res2;
                //pf.SaveLog("***** resF: " + resF);
                ViewBag.resF = resF;
            }
            catch
            {
                ViewBag.resF = "";
            }
        }
        //-----------------------------------------------Register and Login-------------------------
        public string sid = "19";
        void startLogin(string[] rp)
        {

            ViewBag.outp = "LoginOk";
            //////pf.cleanLog();
            try
            {

                var dieUsName = rp[0].Trim().ToLower();
                var diePass = rp[1];//.Trim().ToLower();

                //var dieSite = (MaxReseller.Models.site)Session["dieSite"];

                var nc = new Dictionary<string, string>();
                var tblN = "fprt_Users";


                //-----------------------------------------------

                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                var query = "select * from wp_" + tblN + " where ((sid=" + sid + ") and ((dieEmail=#sq#" + dieUsName + "#sq#) or (dieUser=#sq#" + dieUsName + "#sq#) or (dieMobile=#sq#" + dieUsName + "#sq#)) and (diePass=#sq#" + diePass + "#sq#))";

                nc.Add("query", query);
                //////pf.SaveLog("login:: " + query);

                try
                {
                    // ////pf.SaveLog("login:: try");
                    var outp = aph.sendForm(nc);
                    //////pf.SaveLog("outp:: " + outp);
                    var unL = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
                    //////pf.SaveLog("unL:: " + unL.Count());
                    if (unL.Count() > 0)
                    {
                        Session["userId"] = unL.First().id;
                        // ////pf.SaveLog("userId:: " + unL.First().id);
                        ViewBag.outp = "LoginOk";
                        Session["user"] = dieUsName;

                        ViewBag.cuscor = unL.First().props["dieScore"];

                        ////pf.SaveLog("user:: " + dieUsName);

                        // aph.mapTemp2RealUser();

                        //////pf.SaveLog("user:: " + dieUsName);
                    }
                    else
                    {
                        ViewBag.outp = "LoginNotOk";
                        Session["user"] = "ns";
                        ////pf.SaveLog("login:: else-1");
                    }
                }
                catch
                {
                    ViewBag.outp = "LoginNotOk";
                    Session["user"] = "ns";
                    ////pf.SaveLog("login:: catch-1");
                }

            }
            catch
            {
                ViewBag.outp = "LoginNotOk";
                ////pf.SaveLog("login:: catch-2");
            }

        }
        void startForget(string[] rp)
        {

            ViewBag.outp = "ForgetOk";

            try
            {
                Session["user"] = "ns";

                var dieUsName = rp[0].Trim().ToLower();

                //var dieSite = (MaxReseller.Models.site)Session["dieSite"];

                var nc = new Dictionary<string, string>();
                var tblN = "adsp_UserItem";


                //-----------------------------------------------

                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                var query = "select * from wp_" + tblN + " where (sid=" + sid + ") and (dieEmail=#sq#" + dieUsName + "#sq#)";
                nc.Add("query", query);

                try
                {
                    var outp = aph.sendForm(nc);
                    var unL = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
                    if (unL.Count() > 0)
                    {
                        var subj = "بازیابی رمز عبور";
                        var bod = "رمز عبور شما : " + unL[0].props["diePass"];
                        var rec = dieUsName;
                        try
                        {
                            aph.sendMail(subj, bod, rec);
                            ViewBag.outp = "ForgetOk";
                        }
                        catch
                        {
                            ViewBag.outp = "ActionError";
                        }

                    }
                    else
                    {
                        ViewBag.outp = "ForgetNotOk";
                    }
                }
                catch
                {
                    ViewBag.outp = "ForgetNotOk";
                    Session["user"] = "ns";
                }

            }
            catch
            {
                ViewBag.outp = "ForgetNotOk";
            }

        }
        void startRegister(string[] rp)
        {

            //////pf.cleanLog();
            //startLogin(rp);
            //if (ViewBag.outp == "LoginNotOk")
            //{
            var dieUsName = rp[0].Trim().ToLower();
            var diePass = rp[1];//.Trim().ToLower();
            var name_first = rp[2].Trim().ToLower();
            var name_last = rp[3].Trim().ToLower();
            var dieSex = rp[4].Trim().ToLower();
            var dieIDCode = rp[5].Trim().ToLower();
            var dieBirthDay = rp[6].Trim().ToLower();
            var dieProfImg = rp[7].Trim().ToLower();
            var dieTelegramNo = rp[8].Trim().ToLower();
            var dieGmail = rp[9].Trim().ToLower();
            var dieBankName = rp[10].Trim().ToLower();
            var dieCartNo = rp[11].Trim().ToLower();
            var dieHesabName = rp[12].Trim().ToLower();
            var dieHesabNo = rp[13].Trim().ToLower();
            var dieSheba = rp[14].Trim().ToLower();
            var dieCountry = rp[15].Trim().ToLower();
            var dieCity = rp[16].Trim().ToLower();
            var dieAddress = rp[17].Trim().ToLower();
            var dieAgree = rp[18].Trim().ToLower();

            //if ((pf.IsValidEmail(dieGmail) == true) && (diePass.Length > 0))
            if ((diePass.Length > 0))
            {
                //var dieSite = (MaxReseller.Models.site)Session["dieSite"];
                nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                var q0 = "select * from  wp_fprt_Users where ((sid=" + sid + ") and ((dieUser=#sq#" + dieUsName + "#sq#) or (dieEmail=#sq#" + dieGmail + "#sq#) or (dieMobile=#sq#" + dieTelegramNo + "#sq#)))";

                if (String.IsNullOrWhiteSpace(dieGmail) || String.IsNullOrWhiteSpace(dieTelegramNo))
                {
                    q0 = "select * from  wp_fprt_Users where ((sid=" + sid + ") and ((dieUser=#sq#" + dieUsName + "#sq#))";// or (dieEmail=#sq#" + dieGmail + "#sq#) or (dieMobile=#sq#" + dieTelegramNo + "#sq#)))";
                }

                ////pf.SaveLog("q0:: " + q0);
                nc.Add("query", q0);

                try
                {
                    // ////pf.SaveLog("login:: try");
                    var outp = aph.sendForm(nc);
                    ////pf.SaveLog("outp:: " + outp);
                    var unL = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
                    ////pf.SaveLog("unL:: " + unL.Count());
                    if (unL.Count() > 0)
                    {
                        ViewBag.outp = "userExist";
                    }
                    else
                    {


                        //var tblN = "fprt_Users";
                        var nc = new Dictionary<string, string>();
                        nc.Add("cmd", "RunQuery");
                        var query = "";// "insert into wp_" + tblN + " (sid,dieUsName,dieDate,dieMobile,dieEmail,dieFamily,dieName,diePass,inNews) values(";

                        //var q0 = "select count(*) as lvl from wp_fprt_Users where sid=" + sid;
                        //var nc0 = new Dictionary<string, string>();
                        //nc0.Add("cmd", "SelectTable");
                        //nc0.Add("query", q0);
                        //var outp0 = aph.sendForm(nc0);
                        //var usc = aph.get_sigleResult(outp0);

                        //var countstr = (Convert.ToInt32(usc) + 1).ToString();
                        //var ttik = DateTime.Now.Ticks.ToString().Substring(0, (6 - countstr.Length));

                        //var usident = "Arna" + ttik + countstr;

                        query = "insert into wp_fprt_Users (sid, dieAgree, dieUser, dieEmail, dieBank, dieCardNumber, inDieName, dieAccountNum, dieSheba, dieCountry, dieCity, dieAddress, dieRegDate, diePass, dieName, dieFamily, dieSex, dieICod, dieBirthDate, dieImg, dieMobile, ownerTbl, ownerRec, isSingle, isExist, isNew) values(";
                        //query += "dieEmail,newIdentity,diePass,dieFullName,dieTel,dieMobile,diePostAdr,dieFax,dieImage,dieBanner,";
                        //query += "dieLike,dieScore,dieCreditPrice,dieGiftPrice,dieScont1,dieScont2,dieScont3,dieScont4,dieScont5,dieScont6,dieScont7,";
                        //query += "dieFreeAdsLimit,dieScontCode,ownerTbl,ownerRec,isSingle,isExist,isNew) ";
                        //query += "values(#sid,#sq##oldid#sq#,#sq##oldad#sq#,#sq##lastLogin#sq#,#sq##newad#sq#,#sq##regdate#sq#,";
                        //query += "#sq##email#sq#,#sq##identity#sq#,#sq##pass#sq#,#sq##fullname#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,";
                        //query += "#sq##sq#,#sq##sq#,0,0,0,0,0,0,0,0,0,0,0,0,#sq##porsantcod#sq#,0,0,1,0,0)";

                        query += sid + ",";
                        query += "#sq#" + dieAgree + "#sq#,";
                        query += "#sq#" + dieUsName + "#sq#,";
                        query += "#sq#" + dieGmail + "#sq#,";
                        query += "#sq#" + dieBankName + "#sq#,";
                        query += "#sq#" + dieCartNo + "#sq#,";
                        query += "#sq#" + dieHesabName + "#sq#,";
                        query += "#sq#" + dieHesabNo + "#sq#,";
                        query += "#sq#" + dieSheba + "#sq#,";
                        query += "#sq#" + dieCountry + "#sq#,";
                        query += "#sq#" + dieCity + "#sq#,";
                        query += "#sq#" + dieAddress + "#sq#,";
                        query += "#sq#" + DateTime.Now.ToString() + "#sq#,";
                        query += "#sq#" + diePass + "#sq#,";
                        query += "#sq#" + name_first + "#sq#,";
                        query += "#sq#" + name_last + "#sq#,";
                        query += "#sq#" + dieSex + "#sq#,";
                        query += "#sq#" + dieIDCode + "#sq#,";
                        query += "#sq#" + dieBirthDay + "#sq#,";
                        query += "#sq#" + dieProfImg + "#sq#,";
                        query += "#sq#" + dieTelegramNo + "#sq#,";
                        query += "0,0,1,0,0)";


                        nc.Add("query", query);
                        try
                        {
                            var qret = aph.sendForm(nc);
                            ViewBag.outp = "regOK";
                            Session["pmInWait"] = "FirstLogin";
                        }
                        catch (Exception ex)
                        {
                            ViewBag.outp = "badInfo";
                            pf.SaveErr(ex, "insert user");
                        }
                    }

                }
                catch
                {
                    ViewBag.outp = "userExist";

                    ////pf.SaveLog("login:: catch-1");
                }
            }
            else
            {
                ViewBag.outp = "badInfo";
            }

            //}
            //else
            //{
            //    ViewBag.outp = "userExist";
            //}


        }
        void enterUsAcc(string[] rp)
        {

            //////pf.cleanLog();
            //startLogin(rp);
            //if (ViewBag.outp == "LoginNotOk")
            //{
            var dieUsName = rp[0].Trim().ToLower();
            var diePass = rp[1];//.Trim().ToLower();
            var notreg = rp[2].Trim().ToLower();
            if (notreg == "false")
            {
                startLogin(rp);
                if (ViewBag.outp == "LoginNotOk")
                {
                    ViewBag.outp = "enterUsAccWrong";
                }
                else
                {
                    ViewBag.outp = "enterUsAccOK";
                }
            }
            else
            {

                //}
                //var name_last = rp[3].Trim().ToLower();
                //var dieSex = rp[4].Trim().ToLower();
                //var dieIDCode = rp[5].Trim().ToLower();
                //var dieBirthDay = rp[6].Trim().ToLower();
                //var dieProfImg = rp[7].Trim().ToLower();
                var dieTelegramNo = rp[0].Trim().ToLower();
                var dieGmail = rp[0].Trim().ToLower();
                //var dieBankName = rp[10].Trim().ToLower();
                //var dieCartNo = rp[11].Trim().ToLower();
                //var dieHesabName = rp[12].Trim().ToLower();
                //var dieHesabNo = rp[13].Trim().ToLower();
                //var dieSheba = rp[14].Trim().ToLower();
                //var dieCountry = rp[15].Trim().ToLower();
                //var dieCity = rp[16].Trim().ToLower();
                //var dieAddress = rp[17].Trim().ToLower();
                //var dieAgree = rp[18].Trim().ToLower();

                //if ((pf.IsValidEmail(dieGmail) == true) && (diePass.Length > 0))
                if ((diePass.Length > 0))
                {
                    //var dieSite = (MaxReseller.Models.site)Session["dieSite"];
                    nc = new Dictionary<string, string>();
                    nc.Add("cmd", "SelectTable");
                    var q0 = "select * from  wp_fprt_Users where ((sid=" + sid + ") and ((dieUser=#sq#" + dieUsName + "#sq#) or (dieEmail=#sq#" + dieGmail + "#sq#) or (dieMobile=#sq#" + dieTelegramNo + "#sq#)))";

                    if (String.IsNullOrWhiteSpace(dieGmail) || String.IsNullOrWhiteSpace(dieTelegramNo))
                    {
                        q0 = "select * from  wp_fprt_Users where ((sid=" + sid + ") and ((dieUser=#sq#" + dieUsName + "#sq#))";// or (dieEmail=#sq#" + dieGmail + "#sq#) or (dieMobile=#sq#" + dieTelegramNo + "#sq#)))";
                    }

                    ////pf.SaveLog("q0:: " + q0);
                    nc.Add("query", q0);

                    try
                    {
                        // ////pf.SaveLog("login:: try");
                        var outp = aph.sendForm(nc);
                        ////pf.SaveLog("outp:: " + outp);
                        var unL = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
                        ////pf.SaveLog("unL:: " + unL.Count());
                        if (unL.Count() > 0)
                        {
                            ViewBag.outp = "enterUsAccExist";
                        }
                        else
                        {


                            //var tblN = "fprt_Users";
                            var nc = new Dictionary<string, string>();
                            nc.Add("cmd", "RunQuery");
                            var query = "";// "insert into wp_" + tblN + " (sid,dieUsName,dieDate,dieMobile,dieEmail,dieFamily,dieName,diePass,inNews) values(";

                            //var q0 = "select count(*) as lvl from wp_fprt_Users where sid=" + sid;
                            //var nc0 = new Dictionary<string, string>();
                            //nc0.Add("cmd", "SelectTable");
                            //nc0.Add("query", q0);
                            //var outp0 = aph.sendForm(nc0);
                            //var usc = aph.get_sigleResult(outp0);

                            //var countstr = (Convert.ToInt32(usc) + 1).ToString();
                            //var ttik = DateTime.Now.Ticks.ToString().Substring(0, (6 - countstr.Length));

                            //var usident = "Arna" + ttik + countstr;

                            query = "insert into wp_fprt_Users (sid,dieScore, dieAgree, dieUser, dieEmail, dieBank, dieCardNumber, inDieName, dieAccountNum, dieSheba, dieCountry, dieCity, dieAddress, dieRegDate, diePass, dieName, dieFamily, dieSex, dieICod, dieBirthDate, dieImg, dieMobile, ownerTbl, ownerRec, isSingle, isExist, isNew) values(";
                            //query += "dieEmail,newIdentity,diePass,dieFullName,dieTel,dieMobile,diePostAdr,dieFax,dieImage,dieBanner,";
                            //query += "dieLike,dieScore,dieCreditPrice,dieGiftPrice,dieScont1,dieScont2,dieScont3,dieScont4,dieScont5,dieScont6,dieScont7,";
                            //query += "dieFreeAdsLimit,dieScontCode,ownerTbl,ownerRec,isSingle,isExist,isNew) ";
                            //query += "values(#sid,#sq##oldid#sq#,#sq##oldad#sq#,#sq##lastLogin#sq#,#sq##newad#sq#,#sq##regdate#sq#,";
                            //query += "#sq##email#sq#,#sq##identity#sq#,#sq##pass#sq#,#sq##fullname#sq#,#sq##sq#,#sq##sq#,#sq##sq#,#sq##sq#,";
                            //query += "#sq##sq#,#sq##sq#,0,0,0,0,0,0,0,0,0,0,0,0,#sq##porsantcod#sq#,0,0,1,0,0)";

                            query += sid + ",2000,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + dieUsName + "#sq#,";
                            query += "#sq#" + dieGmail + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + DateTime.Now.ToString() + "#sq#,";
                            query += "#sq#" + diePass + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + "" + "#sq#,";
                            query += "#sq#" + dieTelegramNo + "#sq#,";
                            query += "0,0,1,0,0)";


                            nc.Add("query", query);
                            try
                            {
                                var qret = aph.sendForm(nc);
                                ViewBag.outp = "enterUsAccOK";
                                Session["user"] = dieUsName;

                                //
                                var ngid = aph.getTableLastRecordId("fprt_Users", "19");
                                Session["userId"] = ngid;

                                ViewBag.cuscor = 2000;

                                //Session["pmInWait"] = "FirstLogin";
                            }
                            catch (Exception ex)
                            {
                                ViewBag.outp = "enterUsAccWrong";
                                pf.SaveErr(ex, "insert user");
                            }
                        }

                    }
                    catch
                    {
                        ViewBag.outp = "enterUsAccExist";

                        ////pf.SaveLog("login:: catch-1");
                    }
                }
                else
                {
                    ViewBag.outp = "enterUsAccWrong";
                }

                //}
                //else
                //{
                //    ViewBag.outp = "userExist";
                //}
            }

        }

        void startGetGameStat(string[] rp)
        {
            ViewBag.outp = "enterUsAccOK";
            //////pf.cleanLog();
            //startLogin(rp);
            //if (ViewBag.outp == "LoginNotOk")
            //{
            var gid = rp[0].Trim().ToLower();

            var waitStr = "ثبت نام کمتر از 2 نفر بوده، 20 دقیقه صبر کنید";
            var repStr = "تا این لحظه 1 نفر در بازی ثبت نام کرده";
            var helpStr = "ثبت نام کمتر از 2 نفر ،شروع بازی با 20 دقیقه تاخیر";
            var cango = "n";

            System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();


            nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            query = "select * from wp_Play_Game where id=" + gid;// true#sq#)";
            nc.Add("query", query);

            var outp = aph.sendForm(nc);

            var cuGame = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp).First();

            var dtar = pf.vbsplit(cuGame.props["startDateTime"], " ");
            var dtar2 = pf.vbsplit(dtar[0], "/");
            var dtar3 = pf.vbsplit(dtar[1], ":");
            //System.Globalization.PersianCalendar pc = new System.Globalization.PersianCalendar();
            pf.SaveLog("dtar[1]: " + dtar[1]);
            DateTime dtGam = new DateTime(Convert.ToInt32(dtar2[0]), Convert.ToInt32(dtar2[1]), Convert.ToInt32(dtar2[2]), Convert.ToInt32(dtar3[0]), Convert.ToInt32(dtar3[1]), 0, pc);
            DateTime dtNow = new DateTime(pc.GetYear(DateTime.Now), pc.GetMonth(DateTime.Now), pc.GetDayOfMonth(DateTime.Now), pc.GetHour(DateTime.Now), pc.GetMinute(DateTime.Now), 0, pc);

            pf.SaveLog(dtGam + " - " + dtNow);


            var daydif = (dtGam - dtNow).Days;

            var datedif = (dtGam - dtNow).TotalMinutes;//.Seconds;

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            query = "";
            query = "select * from wp_Play_GameUsers where (GID=" + cuGame.id + ")";
            nc.Add("query", query);
            qret = aph.sendForm(nc);
            var cugRegCont = (new MaxReseller.Funcs.jsonify()).getUnknownList(qret).Count;

            //datedif
            //cugRegCont
            if (cugRegCont <= 1)
            {
                waitStr = "ثبت نام کمتر از 2 نفر بوده، "+ datedif + " دقیقه صبر کنید";
                repStr = "تا این لحظه 1 نفر در بازی ثبت نام کرده";
                helpStr = "ثبت نام کمتر از 2 نفر ،شروع بازی با 20 دقیقه تاخیر";
                cango = "n";
            }
            else
            {
                waitStr = "بازی تا کمتر از " + datedif + " دقیقه دیگر شروع می شود";// "ثبت نام کمتر از 2 نفر بوده، 20 دقیقه صبر کنید";
                repStr = "تا این لحظه " + cugRegCont + " نفر در بازی ثبت نام کرده";
                helpStr = "بعد از اتمام ثانیه شمار لینک ورود به بازی نمایان می شود";
                cango = "n";
            }

            if (datedif < 2)
            {
                cango = "y";
            }

            ViewBag.waitStr = waitStr;
            ViewBag.repStr = repStr;
            ViewBag.helpStr = helpStr;
            ViewBag.cango = cango;


           
        }
        void createPlayerRecord(string[] rp)
        {
            ViewBag.outp = "enterUsAccOK";
            ViewBag.idStr = "0";
            pf.SaveLog("++++++++++ recore create 1");
            //////pf.cleanLog();
            //startLogin(rp);
            //if (ViewBag.outp == "LoginNotOk")
            //{
            var gid = rp[0].Trim().ToLower();

            pf.SaveLog("++++++++++ recore create 2");
            var dieUsName = Session["user"].ToString();

            nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            query = "";
            query = "select * from wp_Play_GameUsers where (GID=" + gid + ")";
            nc.Add("query", query);
            var qret = aph.sendForm(nc);
            var cugRegCont = (new MaxReseller.Funcs.jsonify()).getUnknownList(qret).Count;

            pf.SaveLog("++++++++++ recore create 3");

            var ussid = 1;
            var usnnumber = 1;

            if (cugRegCont == 1)
            {
                ussid = 2;
            }
            if (cugRegCont > 1)
            {
                ussid = pf.GetRandomNumber(1, 2);
            }
            if (cugRegCont > 2)
            {
                usnnumber = 1 + Convert.ToInt32(cugRegCont / 2);
            }


            pf.SaveLog("++++++++++ recore create 4");

            var usid = Session["userId"].ToString();
            var insQ1 = "insert into wp_Play_GameUsers (sid,GID,dieUsn,dieUsSide,dieUsNumber,dieUserID,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,"+gid+",#sq#"+dieUsName+"#sq#,"+ussid+","+usnnumber+","+usid+",0,0,1,0,0)";// "insert into wp_Play_Game (sid,entryPrice,winPercent,sysPercent,funPercent,titr,startDateTime,BGID,ColorA,ColorB,isFinished,ScoreA,ScoreB,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + entryPrice + "," + winPercent + "," + sysPercent + "," + funPercent + ",#sq#";
            //insQ1 += titr + "#sq#,#sq#" + startDateTime + "#sq#," + BGID + "," + ColorA + "," + ColorB + ",#sq#" + isFinished + "#sq#," + ScoreA + "," + ScoreB + ",0,0,1,0,0)";
            nc = new Dictionary<string, string>();
            nc.Add("cmd", "RunQuery");
            nc.Add("query", insQ1);
            qret = aph.sendForm(nc);

            pf.SaveLog("++++++++++ recore create 5");
            var ngid = aph.getTableLastRecordId("Play_GameUsers", "19");

            pf.cleanLog();
            pf.SaveLog(insQ1);
            pf.SaveLog("++++++++++++++" + ngid);

            ViewBag.idStr = ngid;
        }

        void saveNewGame(string[] rp)
        {
            ////pf.cleanLog();
            Session["goAfterLogin"] = "";
            //////pf.SaveLog(rp[0]);
            var dieUsName = Session["user"].ToString();
            var gameType = rp[1];
            if (rp[1].Length < 2)
            {
                if (((rp[2].Length) < 1) && ((rp[2].Length) < 1) && ((rp[2].Length) < 1) && ((rp[2].Length) < 1))
                {
                    gameType = "free";
                }
                else { gameType = "money"; }
            }
            var priceIn = rp[2];
            var priceOut = rp[3];
            var priceSys = rp[4];
            var priceHelp = rp[5];
            var date_time = rp[6];
            var dateHour = rp[7];
            var gameStatus = rp[8];
            var gamerName = rp[9];
            var group_a = rp[10];
            var group_b = rp[11];

            var dieStragA = rp[12];
            var dieStragB = rp[13];

            //var dieSite = (MaxReseller.Models.site)Session["dieSite"];
            if (dieUsName != "ns") { 
            try
            {
                var nc = new Dictionary<string, string>();
                nc.Add("cmd", "RunQuery");
                var query = "";
                query = "insert into wp_fprt_NewGame (sid,addDate,doCheck,dieStragA,dieStragB,dieUserId,dieColordressGroupB,dieColordressGroupA,dieGamer,dieGameStatus,dieStartHour,dieStartDate,diePercentHelp,diePercentSystem,diePercentWinner,dieStartPrice,dieGameType,dieTitle,ownerTbl,ownerRec,isSingle,isExist,isNew) values(";
                
                query += sid + ",";

                    query += "#sq#" + DateTime.Now.ToString() + "#sq#,";
                    query += "#sq#" + "false" + "#sq#,";

                    query += "#sq#" + dieStragA + "#sq#,";
                    query += "#sq#" + dieStragB + "#sq#,";

                    query += "#sq#" + dieUsName + "#sq#,";
                query += "#sq#" + group_b + "#sq#,";
                query += "#sq#" + group_a + "#sq#,";
                query += "#sq#" + gamerName + "#sq#,";
                query += "#sq#" + gameStatus + "#sq#,";
                query += "#sq#" + dateHour + "#sq#,";
                query += "#sq#" + date_time + "#sq#,";
                query += "#sq#" + priceHelp + "#sq#,";
                query += "#sq#" + priceSys + "#sq#,";
                query += "#sq#" + priceOut + "#sq#,";
                query += "#sq#" + priceIn + "#sq#,";
                query += "#sq#" + gameType + "#sq#,";
                    query += "#sq#" + "درخواست " + DateTime.Now.Ticks + "#sq#,";
                query += "0,0,1,0,0)";
                //////pf.SaveLog("query: " + query);
                nc.Add("query", query);
                try
                {
                    var qret = aph.sendForm(nc);
                    //////pf.SaveLog("qret: " + qret);
                    ViewBag.outp = "regNewGameOK";
                }
                catch (Exception ex)
                {
                    ViewBag.outp = "badInfo_NewGame";
                    ////pf.SaveLog("badInfo_NewGame");
                    pf.SaveErr(ex, "saveNewGame");
                }


            }
            catch
            {
                ViewBag.outp = "saveNewGame_Error";
                ////pf.SaveLog("saveNewGame:: catch-1");
            }


            }
            else
            {
                ViewBag.outp = "dologin";
            }


        }


        void acceptInvite(string[] rp)
        {
            //////pf.cleanLog();
            //Session["goAfterLogin"] = "";
            ////////pf.SaveLog(rp[0]);
            var dieUsName = Session["user"].ToString();
            var id = rp[0];

            var irecs = aph.getTableRecordsSimple("fpr_GameInvites");
            var di = irecs.Where(a => a.id == id).First();

            var ncx = new Dictionary<string, string>();
            ncx.Add("cmd", "RunQuery");
            var queryx = "";
            queryx = "update wp_fpr_GameInvites set dieStat=#sq#قبول#sq# where id=" + di.id;// (usn,pss,mail,fname,lname,mob,cdate) values(#sq#" + usn + "#sq#,#sq#" + pss + "#sq#,#sq#" + mail + "#sq#,#sq#" + fname + "#sq#,#sq#" + lname + "#sq#,#sq#" + mob + "#sq#,#sq#" + cdate + "#sq#)";

            ncx.Add("query", queryx);
            var qretx = aph.sendForm(ncx);

            Session["cgid"] = di.props["dieGame"];



        }
        void viewGame(string[] rp)
        {
            var dieUsName = Session["user"].ToString();
            var id = rp[0];

            //var irecs = aph.getTableRecordsSimple("fpr_GameInvites");
            //var di = irecs.Where(a => a.id == id).First();

            //var ncx = new Dictionary<string, string>();
            //ncx.Add("cmd", "RunQuery");
            //var queryx = "";
            //queryx = "update wp_fpr_GameInvites set dieStat=#sq#قبول#sq# where id=" + di.id;// (usn,pss,mail,fname,lname,mob,cdate) values(#sq#" + usn + "#sq#,#sq#" + pss + "#sq#,#sq#" + mail + "#sq#,#sq#" + fname + "#sq#,#sq#" + lname + "#sq#,#sq#" + mob + "#sq#,#sq#" + cdate + "#sq#)";

            //ncx.Add("query", queryx);
            //var qretx = aph.sendForm(ncx);

            Session["cgid"] = id;// di.props["dieGame"];

        }
        void denyInvite(string[] rp)
        {
            var dieUsName = Session["user"].ToString();
            var id = rp[0];

            var irecs = aph.getTableRecordsSimple("fpr_GameInvites");
            var di = irecs.Where(a => a.id == id).First();

            var ncx = new Dictionary<string, string>();
            ncx.Add("cmd", "RunQuery");
            var queryx = "";
            queryx = "update wp_fpr_GameInvites set dieStat=#sq#رد#sq# where id=" + di.id;// (usn,pss,mail,fname,lname,mob,cdate) values(#sq#" + usn + "#sq#,#sq#" + pss + "#sq#,#sq#" + mail + "#sq#,#sq#" + fname + "#sq#,#sq#" + lname + "#sq#,#sq#" + mob + "#sq#,#sq#" + cdate + "#sq#)";

            ncx.Add("query", queryx);
            var qretx = aph.sendForm(ncx);

            Session["cgid"] = di.props["dieGame"];
        }

        void continuToGame(string[] rp)
        {
            var dieUsName = Session["user"].ToString();
            var gid = Session["cgid"].ToString();
            var anums = rp[0];
            var bnums = rp[1];


            var myposCol = new Dictionary<string, string>();
            //var cont
            if (!String.IsNullOrWhiteSpace(anums))
            {
                var aAr = pf.vbsplit(anums, ",");
                foreach(var n in aAr)
                {
                    if (!String.IsNullOrWhiteSpace(n))
                    {
                        try
                        {
                            myposCol.Add("A-" + (DateTime.Now.Ticks* myposCol.Count()), n.Trim());
                        }
                        catch {
                            //myposCol.Add("A-" + DateTime.Now.Ticks*2, n.Trim());
                        }
                    }
                }
            }
            if (!String.IsNullOrWhiteSpace(bnums))
            {
                var aAr = pf.vbsplit(bnums, ",");
                foreach (var n in aAr)
                {
                    if (!String.IsNullOrWhiteSpace(n))
                    {
                        myposCol.Add("B-" + (DateTime.Now.Ticks * myposCol.Count()), n.Trim());
                    }
                }
            }

            var gamesReal = aph.getTableRecordsSimple("Play_Game");
            var gamesFake = aph.getTableRecordsSimple("fprt_NewGame");
            var grc = gamesReal.Where(a => a.id == gid).First();
            var grc_fake = gamesFake.Where(a => a.id == grc.props["BGID"]).First();

            var bic = new List<MaxFotBal.Models.basketItm>();
            foreach (var pz in myposCol)
            {
                //var ncx = new Dictionary<string, string>();
                //ncx.Add("cmd", "RunQuery");
                //var queryx = "";
                //queryx = "update wp_fpr_GameInvites set dieStat=#sq#رد#sq# where id=" + di.id;// (usn,pss,mail,fname,lname,mob,cdate) values(#sq#" + usn + "#sq#,#sq#" + pss + "#sq#,#sq#" + mail + "#sq#,#sq#" + fname + "#sq#,#sq#" + lname + "#sq#,#sq#" + mob + "#sq#,#sq#" + cdate + "#sq#)";

                //ncx.Add("query", queryx);
                //var qretx = aph.sendForm(ncx);

                //Session["cgid"] = di.props["dieGame"];
                var ni = new MaxFotBal.Models.basketItm();
                ni.dieSide = pf.vbsplit(pz.Key, "-")[0];
                ni.dieNumber = pz.Value;

                bic.Add(ni);
            }
            Session["BasketItms"] = bic;
        }
        void saveBasket(string[] rp)
        {
            ////pf.cleanLog();
            var dieUsName = Session["user"].ToString();
            var gid = Session["cgid"].ToString();
            ////pf.SaveLog("+++++++++++++++ bsk 1");

            var gamesReal = aph.getTableRecordsSimple("Play_Game");
            var gamesFake = aph.getTableRecordsSimple("fprt_NewGame");
            var grc = gamesReal.Where(a => a.id == gid).First();
            var grc_fake = gamesFake.Where(a => a.id == grc.props["BGID"]).First();

            ////pf.SaveLog("+++++++++++++++ bsk 2");

            var iCol = (List<MaxFotBal.Models.basketItm>)Session["BasketItms"];
            var entryPrice = grc.props["entryPrice"];

            ////pf.SaveLog("+++++++++++++++ bsk 3");

            var allColors = aph.getTableRecordsSimple("fpr_color");
            var allSides = aph.getTableRecordsSimple("fpr_silde");

            ////pf.SaveLog("+++++++++++++++ bsk 4");

            var color1 = allColors.Where(a => a.id == grc.props["ColorA"]).First().props["titr"];//titr, dieHex, dieName
            var color2 = allColors.Where(a => a.id == grc.props["ColorB"]).First().props["titr"];//titr, dieHex

            ////pf.SaveLog("+++++++++++++++ bsk 5");

            var playerCount = iCol.Count();
            var finalPrc = Convert.ToInt32(entryPrice) * playerCount;

            ////pf.SaveLog("+++++++++++++++ bsk 6");
            /*
             insert into wp_fpr_basket (sid,dieDate,dieUsname,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,#sq#3/20/2018 1:03:59 PM#sq#,#sq#usname#sq#,0,0,1,0,0)
insert into wp_fpr_basketItem (sid,bskid,dieSide,dieNumber,dieDate,dieBasePrc,dieFinalPrc,dieConfig,gid,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,1,#sq#a#sq#,16,#sq#3/20/2018 1:06:21 PM#sq#,100,100,#sq#config#sq#,123,0,0,1,0,0)
insert into wp_fpr_factor (sid,lastUpdate,dieReport,dieStat,usn,dieDate,priceFinal,bskid,geo,mob,adr,fullname,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,#sq#3/20/2018 1:08:42 PM#sq#,#sq#123%2C1#sq#,#sq#Ù¾Ø±Ø¯Ø§Ø®Øª Ù†Ø´Ø¯Ù‡#sq#,#sq#usname#sq#,#sq#datenow#sq#,600,123,#sq#geo#sq#,0912,#sq#address#sq#,#sq#fullname#sq#,0,0,1,0,0)
 
             */

            var ncx = new Dictionary<string, string>();
            ncx.Add("cmd", "RunQuery");
            var queryx = "";
            queryx = "insert into wp_fpr_basket (sid,dieDate,dieUsname,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,#sq#" + DateTime.Now.ToString() + "#sq#,#sq#" + dieUsName + "#sq#,0,0,1,0,0)";

            ////pf.SaveLog("+++++++++++++++ bsk 7");

            ncx.Add("query", queryx);
            var qretx = aph.sendForm(ncx);

            var llbid = aph.getTableLastRecordId("fpr_basket", sid);
            Session["lastbskid"] = llbid;

            ////pf.SaveLog("+++++++++++++++ bsk 8");

            foreach (var i in iCol)
            {
                var cc = color1;
                if (i.dieSide == "B")
                {
                    cc = color2;
                }

                //i.dieNumber
                //cc
                //entryPrice

                ncx = new Dictionary<string, string>();
                ncx.Add("cmd", "RunQuery");
                queryx = "";
                queryx = "insert into wp_fpr_basketItem (sid,bskid,dieSide,dieNumber,dieDate,dieBasePrc,dieFinalPrc,dieConfig,gid,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + llbid + ",#sq#" + i.dieSide + "#sq#," + i.dieNumber + ",#sq#" + DateTime.Now.ToString() + "#sq#," + entryPrice + "," + entryPrice + ",#sq#config#sq#," + gid + ",0,0,1,0,0)";

                ncx.Add("query", queryx);
                qretx = aph.sendForm(ncx);

            }

            ////pf.SaveLog("+++++++++++++++ bsk91");

        }

        void createFinalPlayers(string[] rp)
        {
            ////pf.cleanLog();
            var dieUsName = Session["user"].ToString();
            var gid = Session["cgid"].ToString();
            //////pf.SaveLog("+++++++++++++++ bsk 1");

            /*
             insert query : insert into wp_Play_GameUsers (sid,GID,dieUsn,dieUsSide,dieUsNumber,dieUserID,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,6,#sq#usname#sq#,2,11,3,0,0,1,0,0)
insert query : insert into wp_otherPlayers (sid,parentPlayer,dieSide,dieNumber,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,7,2,13,0,0,1,0,0)
 //fprt_Users
             */
            var allus = aph.getTableRecordsSimple("fprt_Users");
            var usrec = allus.Where(a => a.props["dieUser"] == dieUsName).First().id;

            var iCol = (List<MaxFotBal.Models.basketItm>)Session["BasketItms"];
            

            var ncx = new Dictionary<string, string>();
            ncx.Add("cmd", "RunQuery");
            var queryx = "";
            var usid = "1";
            if (iCol[0].dieSide == "B")
            {
                usid = "2";
            }
            queryx = "insert into wp_Play_GameUsers (sid,GID,dieUsn,dieUsSide,dieUsNumber,dieUserID,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + gid + ",#sq#" + dieUsName + "#sq#," + usid + "," + iCol[0].dieNumber + "," + usrec + ",0,0,1,0,0)";
            ncx.Add("query", queryx);

            ////pf.SaveLog("queryx:: " + queryx);

            var qretx = aph.sendForm(ncx);

            if (iCol.Count() > 1)
            {
                var fplayerid = aph.getTableLastRecordId("Play_GameUsers", sid);

                for(var i = 1; i <= iCol.Count() - 1; i++)
                {
                    ncx = new Dictionary<string, string>();
                    ncx.Add("cmd", "RunQuery");
                    queryx = "";
                    usid = "1";
                    if (iCol[i].dieSide == "B")
                    {
                        usid = "2";
                    }
                    //queryx = "insert into wp_Play_GameUsers (sid,GID,dieUsn,dieUsSide,dieUsNumber,dieUserID,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + gid + ",#sq#" + dieUsName + "#sq#," + usid + "," + iCol[i].dieNumber + "," + usrec + ",0,0,1,0,0)";
                    queryx = "insert into wp_otherPlayers (sid,parentPlayer,dieSide,dieNumber,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + fplayerid + "," + usid + "," + iCol[i].dieNumber + ",0,0,1,0,0)";

                    ////pf.SaveLog("queryx2:: " + queryx);

                    ncx.Add("query", queryx);
                    qretx = aph.sendForm(ncx);
                }
            }



        }
        //setMyPlayer
        void setMyPlayer(string[] rp)
        {
            ViewBag.nwp = "";
            var newpos = rp[0];
            
            //////pf.SaveLog("********************** getMyPlayers - 1");
            var users = aph.getTableRecords("158");
            var otherusers = aph.getTableRecords("188");
            var colors = aph.getTableRecords("157");
            var id = Session["myGamerId"].ToString();
            //////pf.SaveLog("********************** getMyPlayers - 2");
            var usr = users.Where(a => a.id == id).First();
            var otherusr = otherusers.Where(a => a.props["parentPlayer"] == usr.id).ToList();//.First();
            //////pf.SaveLog("********************** getMyPlayers - 3");
            var colorsList = new List<string>();
            var numbsList = new List<string>();
            var games = aph.getTableRecords("156");
            var dieGame = games.Where(a => a.id == usr.props["GID"]).First();
            //////pf.SaveLog("********************** getMyPlayers - 4");
            var ColorA = colors.Where(a => a.id == dieGame.props["ColorA"]).First().props["dieName"];
            var ColorB = colors.Where(a => a.id == dieGame.props["ColorB"]).First().props["dieName"];//dieName
            var myConf_color = Session["myConf_color"].ToString();
            var mycolortit = colors.Where(a => a.props["dieName"] == myConf_color).First().props["titr"];
            var myStartData = mycolortit + "," + Session["myConf_number"].ToString();

            var nsid = 1;
            if (newpos.StartsWith("B") == true)
            {
                nsid = 2;
            }
            var newnum = newpos.Replace("A", "").Replace("B", "");

            var posib = 0;
            posib += users.Where(a => (a.id==id)&&(a.props["dieUsSide"] == nsid.ToString()) && (a.props["dieUsNumber"] == newnum)).Count();
            posib += otherusers.Where(a => (a.props["parentPlayer"] == id) && (a.props["dieSide"] == nsid.ToString()) && (a.props["dieNumber"] == newnum)).Count();

            if (posib > 0)
            {

                if (nsid == 1)
                {
                    Session["myConf_color"] = ColorA;
                }
                if (nsid == 2)
                {
                    Session["myConf_color"] = ColorB;
                }

                Session["myConf_number"] = newnum;
            }

            ////////pf.SaveLog("********************** getMyPlayers - 5");
            //var sidN = usr.props["dieUsSide"];
            //if (sidN == "1")
            //{
            //    colorsList.Add(ColorA);
            //}
            //if (sidN == "2")
            //{
            //    colorsList.Add(ColorB);
            //}
            //numbsList.Add(usr.props["dieUsNumber"]);
            ////////pf.SaveLog("********************** getMyPlayers - 6");

            //foreach (var f in otherusr)
            //{
            //    var dieSide = f.props["dieSide"];
            //    if (dieSide == "1")
            //    {
            //        colorsList.Add(ColorA);
            //    }
            //    if (dieSide == "2")
            //    {
            //        colorsList.Add(ColorB);
            //    }
            //    numbsList.Add(f.props["dieNumber"]);
            //}
            ////////pf.SaveLog("********************** getMyPlayers - 7");
            //ViewBag.myplst = colorsList.Aggregate((a, b) => a + "," + b) + "nnpp" + numbsList.Aggregate((a, b) => a + "," + b) + "nnpp" + myStartData;
            ////ViewBag.myplst = colorsList.Count() + "-" + numbsList.Count();
            ////////pf.SaveLog("********************** getMyPlayers - 8");
        }

        public string getColorEN(string pn)
        {
            switch (pn)
            {
                case "سفید":
                    return "white";
                    break;
                case "قرمز":
                    return "red";
                    break;
                case "آبی":
                    return "blue";
                    break;
                case "نارنجی":
                    return "orange";
                    break;
                case "زرد":
                    return "yellow";
                    break;
                case "سبز":
                    return "green";
                    break;
            }
            return pn;
        }
        void updatePerson(string[] rp)
        {
            ViewBag.nwp = "";
            ViewBag.myres = "";
            //نارنجی#newitem#4#newitem#2136#newitem#1520#newitem#run-down#newitem#44

            var diecolor = rp[0];
            var dienum = rp[1];
            var x = rp[2];
            var y = rp[3];
            var showMod = rp[4];
            var dieMyNeuF = rp[5];
            //var person = rp[0];

            var comandor = (List<string>)HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_Commandor"];// = new List<string>();
            comandor.Add("newpos" + "," + getColorEN(diecolor) + "," + dienum + "," + x + "," + y + "," + showMod + "," + dieMyNeuF);
            try
            {
                HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_Commandor"] = comandor;
            }
            catch { }

            pf.SaveLog("************* update person:: " + diecolor + " - " + dienum);

            var cupls = (List<MaxFotBal.Models.playerConfig>)HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];
            //foreach (var i in cupls)
            //{

                
            //    if ((i.color == diecolor) && (i.number == dienum))
            //    {
                    ViewBag.myres = "person updated...";
                    pf.SaveLog("+++++++++++++++++++++++person updated..." + x + "," + y);
                    cupls.Where(a=> (a.color == diecolor) && (a.number == dienum)).ToList().ForEach(u =>
                    {
                        u.showMod = showMod;
                        u.speedPowwer = dieMyNeuF;
                        u.pos.x = x;
                        u.pos.y = y;
                        u.pos.f = dieMyNeuF;
                    });
            //    }

            //}
            try
            {
                HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"] = cupls;
            }
            catch { }

            
        }

        void saveMSG(string[] rp)
        {
            
            foreach(var m in rp)
            {
                var dieq = "";
                var tt2 = DateTime.Now.ToString();
                dieq = "insert into wp_fpr_gameChatRecorder (sid,diePlayerId,dieTT,dieType,dieGame,dieCapture,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,#sq#" + Session["myGamerId"].ToString() + "#sq#,#sq#" + tt2 + "#sq#,#sq#recorder#sq#," + Session["myConf_GID"].ToString() + ",#sq#" + m + "#sq#,0,0,1,0,0)";

                var ncx = new Dictionary<string, string>();
                ncx.Add("cmd", "RunQuery");
                ncx.Add("query", dieq);
                var qret = aph.sendForm(ncx);

            }

        }
        void saveGole(string[] rp)
        {
            pf.SaveLog("*******************8 savegole");

            var msg = rp[0];

            pf.SaveLog("*******************8 savegole 2 - " + msg);

            var car = pf.vbsplit(msg, "CMD");
            var CMD = car[1];

            pf.SaveLog("*******************8 savegole 3 - " + CMD);

            if (CMD.Contains("gole"))
            {
                pf.SaveLog("*******************8 savegole 4 - " + CMD);
                var golar = pf.vbsplit(CMD, "gole")[1];

                var golby = pf.vbsplit(pf.vbsplit(golar, "BY")[1], "TO")[0];
                pf.SaveLog("*******************8 savegole 5 - " + golby);
                var golside = pf.vbsplit(pf.vbsplit(golar, "BY")[1], "TO")[1];
                pf.SaveLog("*******************8 savegole 6 - " + golside);
                //doAlert("گل به  " + golside + " توسط " + golby);
                //Play_Game
                //ScoreA, ScoreB
                var gid = Session["myConf_GID"].ToString();
                pf.SaveLog("*******************8 savegole 7 - " + gid);
                var dieq = "insert into wp_fpr_gole (sid,gid,side,player,datet,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + gid + ",#sq#" + golside + "#sq#,#sq#" + golby + "#sq#,#sq#" + DateTime.Now.ToString() + "#sq#,0,0,1,0,0)";

                pf.SaveLog("*******************8 savegole 8 - " + dieq);

                var ncx = new Dictionary<string, string>();
                ncx.Add("cmd", "RunQuery");
                ncx.Add("query", dieq);
                var qret = aph.sendForm(ncx);


                var cures = HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_result"].ToString();// = Session["myConf_result"].ToString();
                var scorA = Convert.ToInt32(pf.vbsplit(cures, "-")[0]);
                var scorB = Convert.ToInt32(pf.vbsplit(cures, "-")[1]);
                if (golside.Trim() == "A")
                {
                    scorA++;
                }
                if (golside.Trim() == "B")
                {
                    scorB++;
                }
                cures = scorA + "-" + scorB;


                dieq = "update wp_Play_Game set ScoreA=" + scorA + ",ScoreB=" + scorB + " where id=" + Session["myConf_GID"].ToString();// (sid,gid,side,player,datet,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + gid + ",#sq#" + golside + "#sq#,#sq#" + golby + "#sq#,#sq#" + DateTime.Now.ToString() + "#sq#,0,0,1,0,0)";



                ncx = new Dictionary<string, string>();
                ncx.Add("cmd", "RunQuery");
                ncx.Add("query", dieq);
                qret = aph.sendForm(ncx);


            }

        }

        void logRecFrames(string[] rp)
        {
            ViewBag.myres = "";
            foreach (var d in rp)
            {
                if (!String.IsNullOrWhiteSpace(d))
                {
                    var dar = pf.vbsplit(d, "nnpp");

                    //var newpos = rp[0];
                    /*
                    formdata += RecFrames[i].tt + "#newitem#";
                    formdata += RecFrames[i].ur + "#newitem#";
                    formdata += JSON.stringify(RecFrames[i].scrolInf) + "#newitem#";
                    formdata += JSON.stringify(RecFrames[i].evtInf) + "#newitem#";
                    formdata += JSON.stringify(RecFrames[i].swipInf) + "#newitem#";
                    formdata += JSON.stringify(RecFrames[i].tapInf) + "#newitem#";
                    formdata += JSON.stringify(RecFrames[i].divsInf) + "#newrow#";
                     */

                    var ncx = new Dictionary<string, string>();
                    ncx.Add("cmd", "RunQuery");
                    var queryx = "";
                    //queryx = "insert into wp_otherPlayers (sid,parentPlayer,dieSide,dieNumber,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + fplayerid + "," + usid + "," + iCol[i].dieNumber + ",0,0,1,0,0)";
                    queryx = "insert into wp_SiteRecord (sid,sessId,recJsn,dieDate,isPlay,dieUser,isLogin,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19,#sq#" + Session.SessionID.ToString() + "#sq#,#sq#" + d + "#sq#,#sq#" + DateTime.Now.ToString() + "#sq#,#sq#false#sq#,#sq#" + Session["user"].ToString() + "#sq#,#sq#false#sq#,0,0,1,0,0)";

                    ////pf.SaveLog("queryx2:: " + queryx);

                    ncx.Add("query", queryx);
                    var qretx = aph.sendForm(ncx);
                }
            }
        }
        void getMyPlayers(string[] rp)
        {
            ViewBag.myplst = "";
            //////pf.SaveLog("********************** getMyPlayers - 1");
            var users = aph.getTableRecords("158");
            var otherusers = aph.getTableRecords("188");
            var colors = aph.getTableRecords("157");
            var id = Session["myGamerId"].ToString();
            //////pf.SaveLog("********************** getMyPlayers - 2");
            var usr = users.Where(a => a.id == id).First();
            var otherusr = otherusers.Where(a => a.props["parentPlayer"] == usr.id).ToList();//.First();
            //////pf.SaveLog("********************** getMyPlayers - 3");
            var colorsList = new List<string>();
            var numbsList = new List<string>();
            var games = aph.getTableRecords("156");
            var dieGame = games.Where(a => a.id == usr.props["GID"]).First();
            //////pf.SaveLog("********************** getMyPlayers - 4");
            var ColorA = colors.Where(a => a.id == dieGame.props["ColorA"]).First().props["titr"];
            var ColorB = colors.Where(a => a.id == dieGame.props["ColorB"]).First().props["titr"];//dieName
            var myConf_color = Session["myConf_color"].ToString();
            var mycolortit = colors.Where(a => a.props["dieName"] == myConf_color).First().props["titr"];
            var myStartData = mycolortit + "," + Session["myConf_number"].ToString();

            //////pf.SaveLog("********************** getMyPlayers - 5");
            var sidN = usr.props["dieUsSide"];
            if (sidN == "1")
            {
                colorsList.Add(ColorA);
            }
            if (sidN == "2")
            {
                colorsList.Add(ColorB);
            }
            numbsList.Add(usr.props["dieUsNumber"]);
            //////pf.SaveLog("********************** getMyPlayers - 6");

            foreach (var f in otherusr)
            {
                var dieSide = f.props["dieSide"];
                if (dieSide == "1")
                {
                    colorsList.Add(ColorA);
                }
                if (dieSide == "2")
                {
                    colorsList.Add(ColorB);
                }
                numbsList.Add(f.props["dieNumber"]);
            }
            //////pf.SaveLog("********************** getMyPlayers - 7");
            ViewBag.myplst = colorsList.Aggregate((a, b) => a + "," + b) + "nnpp" + numbsList.Aggregate((a, b) => a + "," + b) + "nnpp" + myStartData;
            //ViewBag.myplst = colorsList.Count() + "-" + numbsList.Count();
            //////pf.SaveLog("********************** getMyPlayers - 8");
        }

        void checkFactorStat(string[] rp)
        {
            ViewBag.outp = "checkFactorStat";

            var fid = Session["lFid"].ToString();
            var res = "report";

            var nc = new Dictionary<string, string>();
            nc.Add("cmd", "SelectTable");
            var query = "select * from " + "wp_fpr_factor" + " where (id=" + fid + ")";
            nc.Add("query", query);

            try
            {
                var outp = aph.sendForm(nc);
                var unL = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
                if (unL.Count() > 0)
                {
                    res = unL[0].props["dieReport"];
                }
            }
            catch { }


            HttpContext.Application["fcid" + Session["lFid"].ToString()] = res;
            //HttpContext.Application


        }

        //-----------------------------------Upload Img---------------------
        //void saveFile(string[] rp)
        //{
        //    ////pf.cleanLog();
        //    ViewBag.outp = "SaveNotOk";
        //    //  var entries = pf.vbsplit(rp[0].Trim().ToLower(), "#np#");
        //    //var adsId = Session["nds_id"].ToString();

        //    ////pf.SaveLog("func saveFile");
        //    var adId = rp[0];
        //    var ur = rp[1];
        //    ////pf.SaveLog("adId = " + rp[0] + " ur = " + rp[1]);
        //    var idar = pf.vbsplit(adId, "-");
        //    var adsId = idar[0];
        //    var adnum = idar[1];
        //    ////pf.SaveLog("adsId = " + idar[0] + " adnum = " + idar[1]);
        //    var adsRec = aph.getTableRecordsFromIds("98", adsId);
        //    //if(adsRec)
        //    var adsMedia = new List<MaxReseller.Models.unknown>();
        //    var nc = new Dictionary<string, string>();
        //    nc.Add("cmd", "SelectTable");
        //    var query = "select * from wp_adsp_adsMedia where (dieAds=" + adsId + ")";
        //    nc.Add("query", query);
        //    try
        //    {
        //        var outp = aph.sendForm(nc);
        //        ////pf.SaveLog("in try: " + outp);
        //        adsMedia = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
        //        //return unL;

        //    }
        //    catch
        //    {
        //        adsMedia = null;
        //        //return null;
        //    }


        //    var dieUs = Session["user"].ToString();

        //    //var dieSite = (MaxReseller.Models.site)Session["dieSite"];

        //    var dieQ = "insert into wp_adsp_adsMedia (sid,dieAds,dieTitle,dieOrder,dieFile,dieSubject,ownerTbl,ownerRec,isSingle,isExist,isNew) values(" + sid + "," + adsId + ",#sq#" + "تصویر شماره " + adnum + "#sq#," + adnum + ",#sq#" + ur + "#sq#,#sq#" + "تصویر پیش نمایش" + "#sq#,0,0,1,0,0)";
        //    if (adnum == "1")
        //    {
        //        dieQ = "update wp_adsp_AdsItems set dieImg=#sq#" + ur + "#sq# where id=" + adsId;
        //    }


        //    nc = new Dictionary<string, string>();
        //    nc.Add("cmd", "RunQuery");
        //    nc.Add("query", dieQ);


        //    ////pf.SaveLog("inja");
        //    try
        //    {
        //        var outp = aph.sendForm(nc);
        //        //dieFac = aph.getTableLastRecordId("adsp_PaymentItems", sid);
        //        ViewBag.outp = "SaveOk";
        //    }
        //    catch (Exception ex)
        //    {
        //        pf.SaveErr(ex, "save file");
        //    }


        //}
        //--------------------------------------------------------------------
        // GET: Shell
        public ActionResult Index()
        {
            //////pf.cleanLog();

            var rp = (string[])Session["request_params"];

            var cmd = Request["CmdName"];
            ViewBag.outp = "";


            switch (cmd)
            {
                case "getuscommandlist":
                    getuscommandlist(rp);
                    break;
                case "getuscommandlistRecord":
                    getuscommandlistRecord(rp);
                    break;
                case "runSetup":
                    runSetup(rp);
                    break;
                case "runSetup2":
                    runSetup2(rp);
                    break;
                case "doAddUser":
                    doAddUser(rp);
                    break;
                case "doAddSite":
                    doAddSite(rp);
                    break;
                case "doLoginResell":
                    doLoginResell(rp);
                    break;
                case "doLoginPanel":
                    doLoginPanel(rp);
                    break;
                case "doAddPak":
                    doAddPak(rp);
                    break;
                case "doRegisterRequest":
                    doRegisterRequest(rp);
                    break;
                case "updateAdsVisit":
                    updateAdsVisit(rp);
                    break;
                case "updateAdsScore":
                    updateAdsScore(rp);
                    break;
                case "saveConfigs":
                    saveConfigs(rp);
                    break;
                case "getConfigs":
                    getConfigs(rp);
                    break;
                //-----------------------------
                case "startLogin":
                    startLogin(rp);
                    break;
                case "startRegister":
                    startRegister(rp);
                    break;
                case "enterUsAcc":
                    enterUsAcc(rp);
                    break;
                case "startGetGameStat":
                    startGetGameStat(rp);
                    break;
                case "createPlayerRecord":
                    createPlayerRecord(rp);
                    break;
                case "startForget":
                    startForget(rp);
                    break;
                case "saveFile":
                    // saveFile(rp);
                    break;
                case "saveNewGame":
                    saveNewGame(rp);
                    break;

                case "acceptInvite":
                    acceptInvite(rp);
                    break;
                case "viewGame":
                    viewGame(rp);
                    break;
                case "denyInvite":
                    denyInvite(rp);
                    break;
                case "continuToGame":
                    continuToGame(rp);
                    break;
                case "saveBasket":
                    saveBasket(rp);
                    break;
                case "checkFactorStat":
                    checkFactorStat(rp);
                    break;

                case "createFinalPlayers":
                    createFinalPlayers(rp);
                    break;
                case "getMyPlayers":
                    getMyPlayers(rp);
                    break;
                case "setMyPlayer":
                    setMyPlayer(rp);
                    break;
                case "logRecFrames":
                    logRecFrames(rp);
                    break;
                case "updatePerson":
                    updatePerson(rp);
                    break;
                case "saveMSG":
                    saveMSG(rp);
                    break;
                case "saveGole":
                    saveGole(rp);
                    break;
            }



            ViewBag.res = "sessionucode=" + Request["sessionucode"] + "&params=" + Request["params"] + "&pid=" + Request["pid"] + "&result1=ok&rsp=";

            return View();
        }
        public ActionResult External()
        {
            ////pf.SaveLog("CmdName= " + Request["CmdName"]);

            //var rqp = getinputarr(filterContext);
            //filterContext.HttpContext.Session["request_params"] = rqp;

            //string out1 = System.Text.UTF8Encoding.UTF8.GetString(Request.BinaryRead(Request.TotalBytes));
            //XmlDocument m_xmld = null;
            //XmlNodeList m_nodelist = null;
            //m_xmld = new XmlDocument();
            //////pf.SaveLog("*********8 EXTERNAL:: " + out1);
            //m_xmld.InnerXml = out1;
            //m_nodelist = m_xmld.SelectNodes("/item");
            //string out2 = "";
            //foreach (XmlNode m_node in m_nodelist)
            //{
            //    out2 = m_node.InnerText;
            //}

            //string[] tmparr = pf.vbsplit(out2, "#newitem#");


            //var rp = tmparr;// (string[])Session["request_params"];

            var cmd = Request["CmdName"];
            //ViewBag.outp = "";


            switch (cmd)
            {

                case "testExternalAjax":
                    testExternalAjax();
                    break;
            }



            ViewBag.res = "sessionucode=" + Request["sessionucode"] + "&params=" + Request["params"] + "&pid=" + Request["pid"] + "&result1=ok&rsp=";

            return View();
        }

        // public 
        // Perform the equivalent of posting a form with a filename and two files, in HTML:
        // <form action="{url}" method="post" enctype="multipart/form-data">
        //     <input type="text" name="filename" />
        //     <input type="file" name="file1" />
        //     <input type="file" name="file2" />
        // </form>
        private System.IO.Stream Upload(string url, string filename, Stream fileStream, byte[] fileBytes)
        {
            // Convert each of the three inputs into HttpContent objects

            HttpContent stringContent = new StringContent(filename);
            // examples of converting both Stream and byte [] to HttpContent objects
            // representing input type file
            HttpContent fileStreamContent = new StreamContent(fileStream);
            HttpContent bytesContent = new ByteArrayContent(fileBytes);

            // Submit the form using HttpClient and 
            // create form data as Multipart (enctype="multipart/form-data")

            using (var client = new HttpClient())
            using (var formData = new MultipartFormDataContent())
            {
                // Add the HttpContent objects to the form data

                // <input type="text" name="filename" />
                formData.Add(stringContent, "filename", "filename");
                // <input type="file" name="file1" />
                formData.Add(fileStreamContent, "file1", "file1");
                // <input type="file" name="file2" />
                formData.Add(bytesContent, "file2", "file2");


                // Actually invoke the request to the server

                // equivalent to (action="{url}" method="post")
                var response = client.PostAsync(url, formData).Result;

                // equivalent of pressing the submit button on the form
                if (!response.IsSuccessStatusCode)
                {
                    return null;
                }
                return response.Content.ReadAsStreamAsync().Result;
            }
        }
    }
}