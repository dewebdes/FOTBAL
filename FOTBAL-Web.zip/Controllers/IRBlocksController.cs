﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MXFootBall.Controllers
{
    public class IRBlocksController : Controller
    {
        // GET: IRBlocks
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult NewGame()
        {
            return View();
        }
        public ActionResult DoneGames()
        {
            return View();
        }
        public ActionResult ReadyGames()
        {
            return View();
        }
        public ActionResult Reg()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Help()
        {
            return View();
        }
        public ActionResult Ruls()
        {
            return View();
        }
        public ActionResult Contact()
        {
            return View();
        }
        public ActionResult copR()
        {
            return View();
        }
    }
}