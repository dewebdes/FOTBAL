﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MXFootBall.Controllers
{
    public class ThemController : Controller
    {
        // GET: Them
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Header()
        {
            return View();
        }
        public ActionResult Top()
        {
            return View();
        }
        public ActionResult Foot()
        {
            return View();
        }

        public ActionResult HiddenMenu()
        {
            return View();
        }
        public ActionResult VisibleMenu()
        {
            return View();
        }
        public ActionResult IRAleftSide()
        {
            return View();
        }
        public ActionResult IRHiddenMenu()
        {
            return View();
        }
        public ActionResult Recorder()
        {
            return View();
        }
        public ActionResult Recorder2()
        {
            return View();
        }
        public ActionResult Recorder2And()
        {
            return View();
        }
    }
}