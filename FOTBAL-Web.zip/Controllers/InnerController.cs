﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MXFootBall.Controllers
{
    public class InnerController : Controller
    {
        // GET: Inner
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult about()
        {
            return View();
        }
        public ActionResult form()
        {
            return View();
        }
        public ActionResult Scripts()
        {
            return View();
        }


        public ActionResult ViewHolder()
        {
            return View();
        }
        public ActionResult IRViewHolder()
        {
            return View();
        }
        public ActionResult IRreg()
        {
            return View();
        }
        public ActionResult IRlimitedSearch()
        {
            return View();
        }
        public ActionResult IRflight()
        {
            return View();
        }
        public ActionResult IRrefund()
        {
            return View();
        }
        public ActionResult IRpayTicket()
        {
            return View();
        }
        public ActionResult IRbooking()
        {
            return View();
        }
        //public ActionResult ViewHolder()
        //{
        //    return View();
        //}

    }
}