﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace MXFootBall.Controllers
{
    public class ExternalController : Controller
    {
        public BST_PublicHelper.PubFuncs pf = new BST_PublicHelper.PubFuncs();
        

        public string saveGole()
        {
            var aph = new AppHelper();
            var dt = Request["dt"];
            pf.SaveLog("*******************ex savegole - " + dt);
            var dtar1 = pf.vbsplit(dt, "x");

            var gid = dtar1[0];// pf.vbsplit(dtar1[0], "x")[0];
            //var msg = dtar1[1];

          //  pf.SaveLog("*******************8 savegole 2 - " + msg);

          //  var car = pf.vbsplit(msg, "CMD");
          //  var CMD = car[1];

           // pf.SaveLog("*******************8 savegole 3 - " + CMD);

           // if (CMD.Contains("gole"))
           /// {
             //   pf.SaveLog("*******************8 savegole 4 - " + CMD);
              //  var golar = pf.vbsplit(CMD, "gole")[1];

                var golby = dtar1[1];// pf.vbsplit(pf.vbsplit(golar, "BY")[1], "TO")[0];
                pf.SaveLog("*******************8 savegole 5 - " + golby);
            var golside = pf.vbsplit(dtar1[2], "&")[0];// pf.vbsplit(pf.vbsplit(golar, "BY")[1], "TO")[1];
                pf.SaveLog("*******************8 savegole 6 - " + golside);
                //doAlert("گل به  " + golside + " توسط " + golby);
                //Play_Game
                //ScoreA, ScoreB
                //var gid = Session["myConf_GID"].ToString();
                pf.SaveLog("*******************8 savegole 7 - " + gid);
                var dieq = "insert into wp_fpr_gole (sid,gid,side,player,datet,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + gid + ",#sq#" + golside + "#sq#,#sq#" + golby + "#sq#,#sq#" + DateTime.Now.ToString() + "#sq#,0,0,1,0,0)";

                pf.SaveLog("*******************8 savegole 8 - " + dieq);

                var ncx = new Dictionary<string, string>();
                ncx.Add("cmd", "RunQuery");
                ncx.Add("query", dieq);
                var qret = aph.sendForm(ncx);

            var cures = "0-0";
            try
            {
                cures = HttpContext.Application["game_" + gid + "_result"].ToString();// = Session["myConf_result"].ToString();
            }
            catch { }

            pf.SaveLog("*******************9 cures 8 - " + cures);
            var scorA = Convert.ToInt32(pf.vbsplit(cures, "-")[0]);
                var scorB = Convert.ToInt32(pf.vbsplit(cures, "-")[1]);
                if (golside.Trim() == "A")
                {
                    scorA++;
                }
                if (golside.Trim() == "B")
                {
                    scorB++;
                }
                cures = scorA + "-" + scorB;

            pf.SaveLog("*******************9 cures2 8 - " + cures);

            dieq = "update wp_Play_Game set ScoreA=" + scorA + ",ScoreB=" + scorB + " where id=" + gid;// (sid,gid,side,player,datet,ownerTbl,ownerRec,isSingle,isExist,isNew) values(19," + gid + ",#sq#" + golside + "#sq#,#sq#" + golby + "#sq#,#sq#" + DateTime.Now.ToString() + "#sq#,0,0,1,0,0)";

            pf.SaveLog("*******************9 dieq 8 - " + dieq);

            ncx = new Dictionary<string, string>();
                ncx.Add("cmd", "RunQuery");
                ncx.Add("query", dieq);
                qret = aph.sendForm(ncx);


            //   }




            var ret0 = System.IO.File.ReadAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrderFix_" + gid + ".txt");
            System.IO.File.WriteAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrderCurrent_" + gid + ".txt", ret0);
            var xxBallParent = "0";
            var xxBallX = "0";
            var xxBallY = "0";

            HttpContext.Application["xxBallParent-" + gid] = xxBallParent;
            HttpContext.Application["xxBallX-" + gid] = xxBallX;
            HttpContext.Application["xxBallY-" + gid] = xxBallY;





            var ViewBagres = "sessionucode=" + Request["sessionucode"] + "&params=" + Request["params"] + "&pid=" + Request["pid"] + "&result1=ok&rsp=";

            return ViewBagres;
        }


        public ActionResult FinishGame()
        {
            return View();
        }
        public ActionResult getGoles()
        {
            return View();
        }


        // GET: External
        public ActionResult Index()
        {
           // ////pf.cleanLog();
            //////pf.SaveLog("EXTERNAL:: hi");
            //////pf.SaveLog("EXTERNAL:: hi 01");
            var cmd = Request["CmdName"];

            //////pf.SaveLog("EXTERNAL:: cmd= "+cmd);
            //////pf.SaveLog(Request.UrlReferrer.AbsolutePath);
            switch (cmd)
            {

                case "testExternalAjax":
                    testExternalAjax();
                    break;
                case "getConf":
                    getConf();
                    break;
            }

            //////pf.SaveLog("EXTERNAL:: hi 2");

            ViewBag.res = "sessionucode=" + Request["sessionucode"] + "&params=" + Request["params"] + "&pid=" + Request["pid"] + "&result1=ok&rsp=";
            //////pf.SaveLog("EXTERNAL:: hi 3");
            return View();
        }
        public string getMyPlayersL()
        {
            try
            {
                var tt = Request["tt"].ToString();

                var aph = new AppHelper();

                var ViewBagmyplst = "";
                //////pf.SaveLog("********************** getMyPlayers - 1");
                var users = aph.getTableRecords("158");
                var otherusers = aph.getTableRecords("188");
                var colors = aph.getTableRecords("157");
                var id = HttpContext.Application["myGamerId" + tt].ToString();
                //////pf.SaveLog("********************** getMyPlayers - 2");
                var usr = users.Where(a => a.id == id).First();
                var otherusr = otherusers.Where(a => a.props["parentPlayer"] == usr.id).ToList();//.First();
                                                                                                 //////pf.SaveLog("********************** getMyPlayers - 3");
                var colorsList = new List<string>();
                var numbsList = new List<string>();
                var games = aph.getTableRecords("156");
                var dieGame = games.Where(a => a.id == usr.props["GID"]).First();
                //////pf.SaveLog("********************** getMyPlayers - 4");
                var ColorA = colors.Where(a => a.id == dieGame.props["ColorA"]).First().props["titr"];
                var ColorB = colors.Where(a => a.id == dieGame.props["ColorB"]).First().props["titr"];//dieName
                var myConf_color = HttpContext.Application["myConf_color" + tt].ToString();
                var mycolortit = colors.Where(a => a.props["dieName"] == myConf_color).First().props["titr"];
                var myStartData = mycolortit + "," + HttpContext.Application["myConf_number" + tt].ToString();

                //////pf.SaveLog("********************** getMyPlayers - 5");
                var sidN = usr.props["dieUsSide"];
                if (sidN == "1")
                {
                    colorsList.Add(ColorA);
                }
                if (sidN == "2")
                {
                    colorsList.Add(ColorB);
                }
                numbsList.Add(usr.props["dieUsNumber"]);
                //////pf.SaveLog("********************** getMyPlayers - 6");

                foreach (var f in otherusr)
                {
                    var dieSide = f.props["dieSide"];
                    if (dieSide == "1")
                    {
                        colorsList.Add(ColorA);
                    }
                    if (dieSide == "2")
                    {
                        colorsList.Add(ColorB);
                    }
                    numbsList.Add(f.props["dieNumber"]);
                }
                //////pf.SaveLog("********************** getMyPlayers - 7");
                ViewBagmyplst = colorsList.Aggregate((a, b) => a + "," + b) + "nnpp" + numbsList.Aggregate((a, b) => a + "," + b) + "nnpp" + myStartData;
                //ViewBag.myplst = colorsList.Count() + "-" + numbsList.Count();
                //////pf.SaveLog("*******************


                //context.Response.ContentType = "text/plain";
                return (Newtonsoft.Json.JsonConvert.SerializeObject(ViewBagmyplst));
            }
            catch
            {
                var tt = pf.vbsplit(Request["tt"].ToString(), "x")[0];
                var ret = System.IO.File.ReadAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrder_" + tt + ".txt");

                return ret;
            }
        }

        public string getPLSBase()
        {
            try
            {
                var gid = Request["gid"].ToString();

                var ret = System.IO.File.ReadAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrderCurrent_" + gid + ".txt");

                var xxBallParent = HttpContext.Application["xxBallParent-" + gid].ToString();// "0";
                var xxBallX = HttpContext.Application["xxBallX-" + gid].ToString();// "0";
                var xxBallY = HttpContext.Application["xxBallY-" + gid].ToString();// "0";

                try
                {
                    var nc = new Dictionary<string, string>();
                    nc.Add("cmd", "SelectTable");
                    //nc.Add("sid", "0");
                    var query = "";
                    query = "select * from wp_Play_Game where (id=" + gid + ")";// and (pss=#sq#" + pss1 + "#sq#)";
                    var aph = new AppHelper();
                    nc.Add("query", query);
                    var qret = aph.sendForm(nc);
                    var unl = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MaxReseller.Models.unknown>>(qret);//.First();
                    if (unl.First().props["isFinished"] == "true")
                    {
                        ret = System.IO.File.ReadAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrderFix_" + gid + ".txt");
                    }
                }
                catch { }

                ret += "#Ball#" + xxBallParent + "," + xxBallX + "," + xxBallY;


                return ret;
            }
            catch
            {
                var gid = Session["myConf_GID"].ToString();// Request["gid"].ToString();

                var ret = System.IO.File.ReadAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrder_" + gid + ".txt");
                return ret;
            }
            

        }

        public string updatePLSBase()
        {
            try
            {
                var gid = Request["gid"].ToString();
                var pcod = Request["pcod"].ToString();
                var dx = Request["dx"].ToString();
                var dy = Request["dy"].ToString();

                //var ballx = Request["ballx"].ToString();
                //var bally = Request["bally"].ToString();
                //var ballparent = Request["ballparent"].ToString();

                //----------------------------------------------------------------------
                var ret = "";
                var cupls = (List<MaxFotBal.Models.playerConfig>)HttpContext.Application["game_" + gid + "_playerList"];
                foreach (var i in cupls)
                {
                    

                    var pcodx = i.side;
                    if (i.side == "1")
                    {
                        pcodx = "A";
                    }
                    if (i.side == "2")
                    {
                        pcodx = "B";
                    }
                    pcodx += i.number;

                    if (pcodx == pcod)
                    {
                        //i.pos.x = dx;
                        //i.pos.y = dy;

                        cupls.Where(a=>(a.number==i.number)&&(a.side==i.side)).ToList().ForEach(b => { b.pos.x = dx; b.pos.y = dy; });

                    }

                }

                HttpContext.Application["game_" + gid + "_playerList"] = cupls;

                foreach (var i in cupls)
                {
                   
                    var pcodx = i.side;
                    if (i.side == "1")
                    {
                        pcodx = "A";
                    }
                    if (i.side == "2")
                    {
                        pcodx = "B";
                    }
                    pcodx += i.number;
                    ret += i.color + "," + i.pos.x + "," + i.pos.y + "," + i.number + "," + i.pos.f + "," + i.speedPowwer + "," + i.showMod + "," + pcodx + "#";


                }

                //return ret;
                System.IO.File.WriteAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrderCurrent_" + gid + ".txt", ret);

                return "ok";
            }
            catch
            {
                
                return "er";
            }


        }

        public string updateBallPos()
        {
            try
            {
                var gid = Request["gid"].ToString();
                //var pcod = Request["pcod"].ToString();
                //var dx = Request["dx"].ToString();
                //var dy = Request["dy"].ToString();

                var ballx = Request["ballx"].ToString();
                var bally = Request["bally"].ToString();
                var ballparent = Request["ballparent"].ToString();

                if (ballparent != "0")
                {
                    HttpContext.Application["xxBallParent-" + gid] = ballparent;
                }
                if (ballx != "0")
                {
                    HttpContext.Application["xxBallX-" + gid] = ballx;
                    HttpContext.Application["xxBallY-" + gid] = bally;
                }
                
                return "";
            }
            catch
            {
                return "";
            }


        }

        public string getConf()
        {
            var ret = "";
            if (true)
            {
                //////pf.SaveLog("get current config at " + DateTime.Now.ToString());
                var cunfb = new MaxFotBal.Models.currentConf();


                cunfb.GID = Session["myConf_GID"].ToString();
                Session["myConf_result"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_result"].ToString();
                cunfb.result = Session["myConf_result"].ToString();
                //cunfb.evt = Session["myConf_tim"].ToString();
                cunfb.evtString = "";

                Session["myConf_playerList"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];
                cunfb.playerList = (List<MaxFotBal.Models.playerConfig>)Session["myConf_playerList"];
                cunfb.playerListString = Newtonsoft.Json.JsonConvert.SerializeObject(cunfb.playerList);
                //////pf.SaveLog("cunfb.playerList : " + cunfb.playerListString);

                Session["myConf_ballPos"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"];
                cunfb.ballPos = (MaxFotBal.Models.posConfig)Session["myConf_ballPos"];
                //Session["myConf_ballParent"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"];
                Session["myConf_ballParent"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"];
                cunfb.ballParent = Session["myConf_ballParent"].ToString();


                var outpbc = Newtonsoft.Json.JsonConvert.SerializeObject(cunfb);
                outpbc = outpbc.Replace(@"\", "");
                // ////pf.SaveLog(outpbc);
                ret = outpbc;



                //var ret2 = "";
                //ret2 += cunfb.result + ",";
                //ret2 += cunfb.evtString + ",";
                //ret2 += cunfb.ballParent + ",";
                //ret2 += cunfb.ballPos.x + "#" + cunfb.ballPos.y + "#" + cunfb.ballPos.f + ",";

                //var plstr = "";
                //foreach (var p in cunfb.playerList)
                //{
                //    plstr += p.color + "#";
                //    plstr += p.number + "#";
                //    plstr += p.side + "#";
                //    plstr += p.pos.x + "#";
                //    plstr += p.pos.y + "#";
                //    plstr += p.pos.f + "_";
                //}
                //ret2 += plstr + ",";

                //ret = ret2;

                //  ////pf.SaveLog("log2::::::" + ret);
            }
            return ret;
            //ViewBag.outp = Request.UrlReferrer.AbsolutePath + " call external ajax Ok";


        }
        public void testExternalAjax()
        {

            ViewBag.outp = Request.UrlReferrer.AbsolutePath + " call external ajax Ok";


        }
        public string testReq()
        {
            //////pf.SaveLog(Request["fsv"]);
            var cnf = new MaxFotBal.Models.config();
            return Request["fsv"]+" - "+ DateTime.Now.ToString();// Newtonsoft.Json.JsonConvert.SerializeObject(cnf);

        }

        public void cleanlog()
        {
           // ////pf.cleanLog();
        }

        private string GetDocumentContents(System.Web.HttpRequestBase Request)
        {
            string documentContents;
            using (Stream receiveStream = Request.InputStream)
            {
                using (StreamReader readStream = new StreamReader(receiveStream, Encoding.UTF8))
                {
                    documentContents = readStream.ReadToEnd();
                }
            }
            return documentContents;
        }

        [OutputCache(Duration = 0)]
        public string direct()
        {
            var ret = "";

            ret = "kevin";
            var cmd = Request["CmdName"];

            //////pf.cleanLog();
            //////pf.SaveLog("cmd in " + DateTime.Now.ToString() + " - " + cmd);

            var forSave = GetDocumentContents(Request);// Request["save"];// +"]";
            try
            {
                //forSave = forSave.Replace("'", "\"");

                //////pf.cleanLog();
                //////pf.SaveLog("forSave:: " + forSave);
                if (!String.IsNullOrEmpty(forSave))
                {
                    var par = pf.vbsplit(forSave, "#np#");
                    var myX = par[0];
                    var myY = par[1];
                    var myF = par[2];
                    var globSett = par[3];



                    var ballprent = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"];
                    var myNumber = Session["myConf_number"].ToString();
                    if (ballprent == myNumber)
                    {
                        var nbf = new MaxFotBal.Models.posConfig();
                        nbf.x = myX;
                        nbf.y = myY;
                        System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"] = nbf;
                        //pf.SaveLog("***************** ball pos is: " + nbf.x + " - " + nbf.y);
                    }


                    if (string.IsNullOrWhiteSpace(globSett) == false)
                    {
                        var gar = pf.vbsplit(globSett, "_");
                        switch (gar[0])
                        {
                            case "setBallParent":
                                if (true)
                                {
                                    //
                                    System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"] = Session["myConf_number"].ToString();

                                    //pf.SaveLog("*****++++++++*********** do set parent:: " + Session["myConf_number"].ToString());
                                    
                                    //var nbf = new MaxFotBal.Models.posConfig();
                                    //nbf.x = gar[1];
                                    //nbf.y = gar[2];
                                    //System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"] = nbf;
                                }
                                break;
                            case "setBallShoot":
                                if (true)
                                {
                                    System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"] = "ns";// Session["myConf_number"].ToString();
                                    var nbf = new MaxFotBal.Models.posConfig();
                                    nbf.x = gar[1];
                                    nbf.y = gar[2];
                                    System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"] = nbf;
                                    //pf.SaveLog("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ nbf.x= " + nbf.x + " , nbf.y=" + nbf.y);
                                }
                                break;
                            case "setEvent":
                                if (true)
                                {
                                    var evt = gar[1];
                                    switch (evt)
                                    {
                                        case "Gol":
                                            var loserSid = gar[2];
                                            var res = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_result"].ToString();
                                            var resAr = pf.vbsplit(res, "-");
                                            if (loserSid == "A")
                                            {
                                                resAr[1] = (Convert.ToInt32(resAr[1]) + 1).ToString();
                                                //resAr[0] = (Convert.ToInt32(resAr[0]) + 1).ToString();
                                            }
                                            if (loserSid == "B")
                                            {
                                                //resAr[1] = (Convert.ToInt32(resAr[1]) + 1).ToString();
                                                resAr[0] = (Convert.ToInt32(resAr[0]) + 1).ToString();
                                            }
                                            res = resAr[0] + "-" + resAr[1];
                                            System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_result"] = res;

                                            System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_inWait"] = true;
                                            System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_inWaitTimStart"] = DateTime.Now;

                                            break;
                                    }
                                    //System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"] = "ns";// Session["myConf_number"].ToString();
                                    //var nbf = new MaxFotBal.Models.posConfig();
                                    //nbf.x = gar[1];
                                    //nbf.y = gar[2];
                                    //System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"] = nbf;
                                }
                                break;
                        }
                    }

                    try
                    {
                        var inWait = (Boolean)System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_inWait"];
                        if (inWait == true)
                        {
                            var waitStart = (DateTime)System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_inWaitTimStart"];
                            var dif = (DateTime.Now - waitStart).Seconds;
                            if (dif >= 15)
                            {
                                System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_inWait"] = false;
                                var nbf = new MaxFotBal.Models.posConfig();
                                nbf.x = "0";
                                nbf.y = "0";
                                System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"] = nbf;

                            }
                        }
                    }
                    catch { }

                    if ((Convert.ToInt32( myX) != 0) && (Convert.ToInt32( myY) != 0))
                    {
                        var myPos = new MaxFotBal.Models.posConfig();
                        myPos.x = myX;
                        myPos.y = myY;
                        myPos.f = myF;

                        Session["myPos"] = myPos;
                        try
                        {
                            ////pf.SaveLog("save pos 1");
                            Session["myConf_playerList"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];
                            ////pf.SaveLog("save pos 2");
                            var playerList = (List<MaxFotBal.Models.playerConfig>)Session["myConf_playerList"];
                            ////pf.SaveLog("save pos 3");
                            var postring = Newtonsoft.Json.JsonConvert.SerializeObject(myPos);
                            ////pf.SaveLog("save pos 4");
                            playerList.Where(a => (a.number == Session["myConf_number"].ToString()) && (a.color == Session["myConf_color"].ToString())).ToList().ForEach(obj => { obj.pos = myPos; obj.posString = postring; });
                            ////pf.SaveLog("save pos 5");
                            System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"] = playerList;
                            ////pf.SaveLog("save pos 6");

                        }
                        catch
                        {
                            //
                        }
                    }

                    //    var nsv = new MaxFotBal.Models.forSave();
                    //    //////pf.SaveLog("test sv:: " + Newtonsoft.Json.JsonConvert.SerializeObject(nsv));
                    //    try
                    //    {
                    //        nsv = Newtonsoft.Json.JsonConvert.DeserializeObject<MaxFotBal.Models.forSave>(forSave);//.First();
                    //        Session["myX"] = nsv.myX;
                    //        Session["myX"] = nsv.myY;
                    //        //////pf.SaveLog("myX=" + nsv.myX);
                    //        //////pf.SaveLog("myY=" + nsv.myY);


                    //        var dieColor= Session["myConf_color"].ToString();
                    //        HttpContext.Application[dieColor + "X"] = nsv.myX;
                    //        HttpContext.Application[dieColor + "Y"] = nsv.myY;
                    //            //////pf.SaveLog("App " + dieColor + "X =" + nsv.myX);
                    //        //////pf.SaveLog("App " + dieColor + "Y =" + nsv.myY);

                    //        var cuballParent = HttpContext.Application["ballParent"].ToString();
                    //        if (cuballParent != nsv.ballParent)
                    //        {
                    //            if (!String.IsNullOrEmpty(nsv.ballParent))
                    //            {
                    //                HttpContext.Application["ballParent"] = nsv.ballParent;
                    //            }
                    //        }

                    //        if ((HttpContext.Application["ballParent"].ToString()== dieColor))
                    //        {
                    //            HttpContext.Application["dieBallX"] = nsv.dieBallX;
                    //            HttpContext.Application["dieBallY"] = nsv.dieBallY;
                    //        }


                    //    }
                    //    catch { }
                }
            }
            catch { }

            switch (cmd)
            {
                case "setBallOn":
                    ////pf.SaveLog("set ball on " + forSave + " at " + DateTime.Now.Ticks);
                    break;
                case "testExternalAjax":
                    ret = "Request.UrlReferrer.AbsolutePath";
                    break;
                case "getBaseConfig":
                    if (true) {
                        //////pf.SaveLog("get base config at " + DateTime.Now.ToString());
                        var cnfb = new MaxFotBal.Models.baseConf();

                        cnfb.myColor = Session["myConf_color"].ToString();
                        cnfb.mySide = Session["myConf_side"].ToString();
                        cnfb.myRole = Session["myConf_role"].ToString();
                        cnfb.myNumber = Session["myConf_number"].ToString();
                        cnfb.GID = Session["myConf_GID"].ToString();
                        cnfb.result = Session["myConf_result"].ToString();
                        cnfb.tim = Session["myConf_tim"].ToString();


                        cnfb.playerList = (List<MaxFotBal.Models.playerConfig>)Session["myConf_playerList"];

                        //tempPlayList = (List<MaxFotBal.Models.playerConfig>)HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];

                        ////pf.cleanLog();
                        //pf.SaveLog("****************************************************");
                        //pf.SaveLog("----play list 3:");
                        foreach (var i in cnfb.playerList)
                        {
                            var str = i.color + " - " + i.number + " : " + i.pos.x + " * " + i.pos.y;
                            //pf.SaveLog(str);
                        }

                        //-------
                        var tempPlayList = (List<MaxFotBal.Models.playerConfig>)HttpContext.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];

                        ////pf.cleanLog();
                        //pf.SaveLog("****************************************************");
                        //pf.SaveLog("----play list 4:");
                        foreach (var i in tempPlayList)
                        {
                            var str = i.color + " - " + i.number + " : " + i.pos.x + " * " + i.pos.y;
                            //pf.SaveLog(str);
                        }
                        //------

                        cnfb.playerListString = Newtonsoft.Json.JsonConvert.SerializeObject(cnfb.playerList);
                        //////pf.SaveLog("cnfb.playerList : " + cnfb.playerListString);

                        cnfb.ballPos = (MaxFotBal.Models.posConfig)Session["myConf_ballPos"];
                        Session["myConf_ballParent"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"];
                        cnfb.ballParent = Session["myConf_ballParent"].ToString();


                        var outpb = Newtonsoft.Json.JsonConvert.SerializeObject(cnfb);
                        ret = outpb;



                        var ret2 = "";
                        ret2 += cnfb.myColor + ",";
                        ret2 += cnfb.mySide + ",";
                        ret2 += cnfb.myRole + ",";
                        ret2 += cnfb.myNumber + ",";
                        ret2 += cnfb.GID + ",";
                        ret2 += cnfb.result + ",";
                        ret2 += cnfb.tim + ",";
                        ret2 += cnfb.ballParent + ",";
                        ret2 += cnfb.ballPos.x + "#" + cnfb.ballPos.y + "#" + cnfb.ballPos.f + ",";

                        var plstr = "";
                        foreach(var p in cnfb.playerList)
                        {
                            plstr += p.color + "#";
                            plstr += p.number + "#";
                            plstr += p.side + "#";
                            plstr += p.pos.x + "#";
                            plstr += p.pos.y + "#";
                            plstr += p.pos.f + "#";
                            plstr += p.speedPowwer + "_";
                        }
                        ret2 += plstr + ",";

                        ret = ret2;

                        pf.SaveLog("************************ base conf: ");
                        pf.SaveLog(ret);
                    }

                    break;
                case "getTestConfig":
                    if (true)
                    {
                        try
                        {
                            //////pf.SaveLog("get current config at " + DateTime.Now.ToString());
                            var cunfb = new MaxFotBal.Models.currentConf();
                            ret = "halooo 1";
                            Session["myConf_GID"] = "1";
                            cunfb.GID = Session["myConf_GID"].ToString();
                            ret = "halooo 2";
                            Session["myConf_result"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_result"].ToString();
                            cunfb.result = Session["myConf_result"].ToString();
                            //cunfb.evt = Session["myConf_tim"].ToString();
                            cunfb.evtString = "";
                            ret = "halooo 3";
                            Session["myConf_playerList"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];
                            ret = "halooo 4";
                            cunfb.playerList = (List<MaxFotBal.Models.playerConfig>)Session["myConf_playerList"];
                            cunfb.playerListString = Newtonsoft.Json.JsonConvert.SerializeObject(cunfb.playerList);
                            ret = "halooo 5";
                            //////pf.SaveLog("cunfb.playerList : " + cunfb.playerListString);

                            Session["myConf_ballPos"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"];
                            ret = "halooo 6";
                            cunfb.ballPos = (MaxFotBal.Models.posConfig)Session["myConf_ballPos"];
                            ret = "halooo 7";
                            cunfb.ballParent = "red";// Session["myConf_ballParent"].ToString();
                            ret = "halooo 8";

                            var outpbc = Newtonsoft.Json.JsonConvert.SerializeObject(cunfb);
                            ret = "halooo 9";
                            outpbc = outpbc.Replace(@"\", "");
                            ////pf.SaveLog(outpbc);
                            ret = "halooo 10";
                            ret = outpbc;
                        }
                        catch
                        {
                           // ret = "pop allo";
                        }
                        
                    }
                    break;
                case "getCurrentConfig":
                    if (true)
                    {
                        //////pf.SaveLog("get current config at " + DateTime.Now.ToString());
                        var cunfb = new MaxFotBal.Models.currentConf();


                        cunfb.GID = Session["myConf_GID"].ToString();
                        Session["myConf_result"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_result"].ToString();
                        cunfb.result = Session["myConf_result"].ToString();
                        //cunfb.evt = Session["myConf_tim"].ToString();
                        cunfb.evtString = "";

                        Session["myConf_playerList"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_playerList"];
                        cunfb.playerList = (List<MaxFotBal.Models.playerConfig>)Session["myConf_playerList"];
                        cunfb.playerListString = Newtonsoft.Json.JsonConvert.SerializeObject(cunfb.playerList);
                        //////pf.SaveLog("cunfb.playerList : " + cunfb.playerListString);

                        Session["myConf_ballPos"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballPos"];
                        cunfb.ballPos = (MaxFotBal.Models.posConfig)Session["myConf_ballPos"];
                        //Session["myConf_ballParent"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"];
                        Session["myConf_ballParent"] = System.Web.HttpContext.Current.Application["game_" + Session["myConf_GID"].ToString() + "_ballParent"];
                        cunfb.ballParent = Session["myConf_ballParent"].ToString();

                        //pf.SaveLog("***************** ball parent is :: " + cunfb.ballParent);

                        var outpbc = Newtonsoft.Json.JsonConvert.SerializeObject(cunfb);
                        outpbc = outpbc.Replace(@"\", "");
                       // ////pf.SaveLog(outpbc);
                        ret = outpbc;



                        var ret2 = "";
                        ret2 += cunfb.result + ",";
                        ret2 += cunfb.evtString + ",";
                        ret2 += cunfb.ballParent + ",";
                        ret2 += cunfb.ballPos.x + "#" + cunfb.ballPos.y + "#" + cunfb.ballPos.f + ",";

                        //pf.SaveLog("ball pos:: " + cunfb.ballPos.x + "#" + cunfb.ballPos.y);


                        var plstr = "";
                        foreach (var p in cunfb.playerList)
                        {
                            plstr += p.color + "#";
                            plstr += p.number + "#";
                            plstr += p.side + "#";
                            plstr += p.pos.x + "#";
                            plstr += p.pos.y + "#";
                            plstr += p.pos.f + "#";
                            plstr += p.speedPowwer + "_";
                        }
                        ret2 += plstr + ",";

                        ret2 += Session["myConf_color"].ToString() + ",";
                        ret2 += Session["myConf_number"].ToString() + ",";

                        ret = ret2;

                        pf.SaveLog("current conf::::::" + ret);
                    }
                    break;
                case "getBaseConfig2":

                    //////pf.SaveLog("get base config 2222 at " + DateTime.Now.ToString());
                    var cnfc = new MaxFotBal.Models.baseConf();
                    var outpc = Newtonsoft.Json.JsonConvert.SerializeObject(cnfc);
                    ret = outpc;
                    break;
                case "getConfig":
                    var cnf = new MaxFotBal.Models.config();
                    try
                    {
                        cnf.color = Session["myConf_color"].ToString();
                        cnf.room = Session["myConf_room"].ToString();



                        //HttpContext.Application[dieColor + "X"] = nsv.myX;
                        //HttpContext.Application[dieColor + "Y"] = nsv.myY;

                        try
                        {
                            cnf.blueX = Convert.ToInt32(HttpContext.Application["blue" + "X"]);
                            cnf.blueY = Convert.ToInt32(HttpContext.Application["blue" + "Y"]);
                        }
                        catch
                        {
                            cnf.blueX = -100;// Convert.ToInt32(HttpContext.Application["blue" + "X"]);
                            cnf.blueY = -100;// Convert.ToInt32(HttpContext.Application["blue" + "Y"]);
                        }

                        try
                        {
                            cnf.redX = Convert.ToInt32(HttpContext.Application["red" + "X"]);
                            cnf.redY = Convert.ToInt32(HttpContext.Application["red" + "Y"]);
                        }
                        catch
                        {
                            cnf.redX = -100;// Convert.ToInt32(HttpContext.Application["blue" + "X"]);
                            cnf.redY = -100;// Convert.ToInt32(HttpContext.Application["blue" + "Y"]);
                        }

                    }
                    catch
                    {
                        cnf.color = "ns";// "ns";
                        cnf.room = "ns";
                    }


                    var cup = HttpContext.Application["ballParent"].ToString();
                    if (!String.IsNullOrEmpty(cup))
                    {
                        cnf.ballParent = cup;
                    }

                    cnf.myCmd = Session["myConf_cmd"].ToString();

                    var outp = Newtonsoft.Json.JsonConvert.SerializeObject(cnf);
                    ret = outp;

                    break;
            
            }


            return ret;
        }

        [OutputCache(Duration = 0)]
        public string getPLS()
        {
            var ret = "";

            var res2 = "";
            var myConf_GID = Request["gid"];
            myConf_GID = myConf_GID.ToLower().Replace("us", "").Trim();

            var cupls = (List<MaxFotBal.Models.playerConfig>)HttpContext.Application["game_" + myConf_GID + "_playerList"];
            foreach (var i in cupls)
            {
                var xpos = Convert.ToInt32(i.pos.x);
                var ypos = Convert.ToInt32(i.pos.y);

                var basX = 4275;
                var basY = 5700;

                var newX = 320;
                var newY = 569;

                var newx = Convert.ToInt32((xpos * 320) / 4275);
                var newy = Convert.ToInt32((ypos * 569) / 5700);

                var newxBall = Convert.ToInt32((Convert.ToInt32(ViewBag.ballX) * 320) / 4275);
                var newyBall = Convert.ToInt32((Convert.ToInt32(ViewBag.ballY) * 569) / 5700);
                //res3 = (newxBall + "," + newyBall);
                var res3 = (ViewBag.ballX + "," + ViewBag.ballY);

                var pcod = i.side;
                if (i.side == "1")
                {
                    pcod = "A";
                }
                if (i.side == "2")
                {
                    pcod = "B";
                }
                pcod += i.number;
                //res2 += i.color + "," + newx + "," + newy + "," + i.number + "-";
                ret += i.color + "," + i.pos.x + "," + i.pos.y + "," + i.number + "," + i.pos.f + "," + i.speedPowwer + "," + i.showMod + "," + pcod + "#";

                //if ((i.color == Session["myConf_color"].ToString()) && (i.number == Session["myConf_number"].ToString()))
                //{
                //    //pf.SaveLog("+++++++++++++++++++++++" + newx + "," + newy);
                //}

            }

            return ret;
        }


        public string getGameBasePlayersPos()
        {
            var myConf_GID = Request["gid"];

            var ret = System.IO.File.ReadAllText(Server.MapPath("../Logs/DB/") + "GameBasePlayerOrder_" + myConf_GID + ".txt");

            return ret;
        }
    }
}