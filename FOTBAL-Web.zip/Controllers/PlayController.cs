﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MXFootBall.Controllers
{
    public class PlayController : Controller
    {
        // GET: Play
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GameList()
        {
            return View();
        }
        public ActionResult UserList()
        {
            return View();
        }
        public ActionResult DieGame()
        {
            return View();
        }
        public ActionResult DieGame2PC()
        {
            return View();
        }
        public ActionResult DieGamePlayBack()
        {
            return View();
        }
        public ActionResult Recorder()
        {
            return View();
        }
        public ActionResult Recorder0()
        {
            return View();
        }
        public ActionResult finish()
        {
            return View();
        }
        public ActionResult PlayBack()
        {
            return View();
        }
        public ActionResult Intro()
        {
            if (HttpContext.Application["checkup"].ToString() == "n")
            {
                var aph = new AppHelper();
                var nc = new Dictionary<string, string>();
                nc.Add("cmd", "SelectTable");
                var query = "select * from wp_Play_Game where (isFinished!=#sq#true#sq#)";
                nc.Add("query", query);

                var outp = aph.sendForm(nc);
                try
                {
                    var unL = (new MaxReseller.Funcs.jsonify()).getUnknownList(outp);
                    foreach (var u in unL)
                    {
                        var q = "update wp_Play_Game set isFinished=#sq#true#sq#";
                        nc = new Dictionary<string, string>();
                        nc.Add("cmd", "RunQuery");
                        //var query = "select * from wp_Play_Game where (isFinished!=#sq#true#sq#)";
                        nc.Add("query", q);

                        outp = aph.sendForm(nc);
                    }
                }
                catch { }
            }
            HttpContext.Application["checkup"] = "y";
            return View();
        }
        public ActionResult IntroLig2()
        {
            return View();
        }
        public ActionResult introAnd()
        {
            return View();
        }
    }
}